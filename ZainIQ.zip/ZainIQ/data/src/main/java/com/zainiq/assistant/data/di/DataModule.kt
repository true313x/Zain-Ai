package com.zainiq.assistant.data.di

import com.zainiq.assistant.core.common.DefaultDispatcherProvider
import com.zainiq.assistant.core.common.DispatcherProvider
import com.zainiq.assistant.data.local.AndroidSecurityRepository
import com.zainiq.assistant.data.mock.MockNotificationRepository
import com.zainiq.assistant.data.mock.MockSupportRepository
import com.zainiq.assistant.data.mock.MockZainCashRepository
import com.zainiq.assistant.data.mock.MockZainRepository
import com.zainiq.assistant.domain.ai.LLMProvider
import com.zainiq.assistant.domain.ai.LocalLLMProvider
import com.zainiq.assistant.domain.repositories.NotificationRepository
import com.zainiq.assistant.domain.repositories.SecurityRepository
import com.zainiq.assistant.domain.repositories.SupportRepository
import com.zainiq.assistant.domain.repositories.ZainCashRepository
import com.zainiq.assistant.domain.repositories.ZainRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Wires domain interfaces to their concrete implementations. As of this
 * build:
 *  - ZainRepository → MockZainRepository (no production Zain API yet — §57)
 *  - ZainCashRepository → MockZainCashRepository (same — §57)
 *  - SecurityRepository → AndroidSecurityRepository — NOT a mock; reads
 *    real on-device signals (Keystore/PackageManager/Settings) and runs
 *    real heuristic URL/SMS analysis, since none of that needs a backend
 *    Zain hasn't given us — see that class's doc comment
 *  - LLMProvider → LocalLLMProvider (on-device only — §7)
 *  - Set&lt;Agent&gt; / Set&lt;Tool&gt; — populated via `@Binds @IntoSet` in
 *    [AgentBindingsModule], one small block per concrete Agent/Tool pair as
 *    each phase adds one (Internet/Telecom/Offers/ZainCash so far).
 *
 * Every repository interface in :domain now has a binding.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class DataModule {

    @Binds
    @Singleton
    abstract fun bindZainRepository(impl: MockZainRepository): ZainRepository

    @Binds
    @Singleton
    abstract fun bindZainCashRepository(impl: MockZainCashRepository): ZainCashRepository

    @Binds
    @Singleton
    abstract fun bindSecurityRepository(impl: AndroidSecurityRepository): SecurityRepository

    @Binds
    @Singleton
    abstract fun bindSupportRepository(impl: MockSupportRepository): SupportRepository

    @Binds
    @Singleton
    abstract fun bindNotificationRepository(impl: MockNotificationRepository): NotificationRepository

    @Binds
    @Singleton
    abstract fun bindDispatcherProvider(impl: DefaultDispatcherProvider): DispatcherProvider

    @Binds
    @Singleton
    abstract fun bindLLMProvider(impl: LocalLLMProvider): LLMProvider
}
