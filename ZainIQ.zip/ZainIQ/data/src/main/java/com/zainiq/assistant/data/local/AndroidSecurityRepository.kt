package com.zainiq.assistant.data.local

import android.Manifest
import android.app.KeyguardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import com.zainiq.assistant.core.common.AppError
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.domain.repositories.AppRiskResult
import com.zainiq.assistant.domain.repositories.DeviceSecurityReport
import com.zainiq.assistant.domain.repositories.SecurityRepository
import com.zainiq.assistant.domain.repositories.SecurityScoreFactor
import com.zainiq.assistant.domain.repositories.SmsAnalysisResult
import com.zainiq.assistant.domain.repositories.UrlScanResult
import com.zainiq.assistant.domain.tools.RiskLevel
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/**
 * build spec §20-§24 — UNLIKE every other repository in this project, this
 * one is NOT a mock: [scanDevice] and [analyzeAppRisk] read real on-device
 * signals through Android's own APIs (KeyguardManager, PackageManager,
 * Settings.Global, Build.VERSION), and [scanUrl]/[analyzeSms] run real
 * structural/heuristic analysis — none of it needs a backend Zain hasn't
 * given us yet, so there's no reason to mock it. What's still missing is
 * explicitly called out inline: live threat-intelligence lookups (build
 * spec §22's "when online" caveat) would need a real API and aren't faked
 * here.
 *
 * Every score/verdict traces to a named, listed factor — build spec §20/§21
 * are explicit that this must say "Potential Risk", never "Malware", and
 * must never claim 100% detection. Nothing here does either.
 */
@Singleton
class AndroidSecurityRepository @Inject constructor(
    @ApplicationContext private val context: Context
) : SecurityRepository {

    override suspend fun scanDevice(): AppResult<DeviceSecurityReport> {
        val factors = mutableListOf<SecurityScoreFactor>()
        var score = 50 // neutral baseline; factors move it up/down

        val hasSecureLock = (context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager)
            ?.isDeviceSecure == true
        factors += factor(hasSecureLock, "قفل شاشة آمن مفعّل", "لا يوجد قفل شاشة آمن", 20, -20)
        score += if (hasSecureLock) 20 else -20

        // API 23+ devices are file-based-encrypted by default by the OS —
        // minSdk here is 26, so this is realistically always true, but it's
        // still reported as a named factor rather than assumed silently.
        factors += SecurityScoreFactor("التخزين مشفّر (افتراضي على أندرويد الحديث)", 15)
        score += 15

        val patchIsRecent = isSecurityPatchRecent()
        factors += factor(patchIsRecent, "تحديث أمني حديث (آخر 6 أشهر)", "تحديث أمني قديم", 15, -10)
        score += if (patchIsRecent) 15 else -10

        val canInstallUnknown = context.packageManager.canRequestPackageInstalls()
        factors += factor(!canInstallUnknown, "تثبيت التطبيقات من مصادر غير معروفة معطّل", "مصادر غير معروفة مفعّلة لهذا التطبيق", 10, -10)
        score += if (canInstallUnknown) -10 else 10

        val devOptionsOn = Settings.Global.getInt(context.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        factors += factor(!devOptionsOn, "خيارات المطورين غير مفعّلة", "خيارات المطورين مفعّلة", 5, -5)
        score += if (devOptionsOn) -5 else 5

        val rootIndicatorsFound = hasRootIndicators()
        factors += factor(!rootIndicatorsFound, "لا توجد مؤشرات root", "مؤشرات احتمالية على root — ليست تأكيداً", 0, -25)
        score += if (rootIndicatorsFound) -25 else 0

        val clampedScore = score.coerceIn(0, 100)
        val riskLevel = when {
            clampedScore >= 80 -> RiskLevel.LOW
            clampedScore >= 60 -> RiskLevel.MEDIUM
            clampedScore >= 40 -> RiskLevel.HIGH
            else -> RiskLevel.CRITICAL
        }

        val recommendations = buildList {
            if (!hasSecureLock) add("فعّل قفل شاشة آمن (نمط، رمز، أو بصمة)")
            if (!patchIsRecent) add("ثبّت آخر تحديث أمني متوفر لجهازك")
            if (canInstallUnknown) add("عطّل تثبيت التطبيقات من مصادر غير معروفة إن لم تكن تستخدمها")
            if (devOptionsOn) add("عطّل خيارات المطورين إذا لم تكن مبرمجاً")
            if (rootIndicatorsFound) add("راجع حالة جهازك — رصدنا مؤشرات قد ترتبط بصلاحيات root")
        }

        return AppResult.Success(
            DeviceSecurityReport(
                score = clampedScore,
                riskLevel = riskLevel,
                factors = factors,
                recommendations = recommendations,
                lastScanEpochMillis = System.currentTimeMillis()
            )
        )
    }

    override suspend fun analyzeAppRisk(packageName: String): AppResult<AppRiskResult> {
        return try {
            val pm = context.packageManager
            @Suppress("DEPRECATION")
            val info = pm.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)

            val installer = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    pm.getInstallSourceInfo(packageName).installingPackageName
                } else {
                    @Suppress("DEPRECATION")
                    pm.getInstallerPackageName(packageName)
                }
            } catch (e: Exception) {
                null
            }

            val reasons = mutableListOf<String>()
            var risk = RiskLevel.LOW

            if (installer != "com.android.vending") {
                reasons += "لم يُثبَّت من متجر Google Play (المصدر: ${installer ?: "غير معروف"})"
                risk = RiskLevel.MEDIUM
            }

            val sensitivePermissions = listOf(
                Manifest.permission.SYSTEM_ALERT_WINDOW,
                Manifest.permission.BIND_ACCESSIBILITY_SERVICE,
                Manifest.permission.BIND_DEVICE_ADMIN,
                Manifest.permission.READ_SMS,
                Manifest.permission.RECEIVE_SMS
            )
            val requested = info.requestedPermissions?.filter { it in sensitivePermissions } ?: emptyList()
            if (requested.isNotEmpty()) {
                reasons += "يطلب صلاحيات حساسة: ${requested.joinToString { it.substringAfterLast('.') }}"
                risk = RiskLevel.HIGH
            }

            if (reasons.isEmpty()) reasons += "لا توجد مؤشرات خطر واضحة من الصلاحيات أو مصدر التثبيت"

            AppResult.Success(AppRiskResult(packageName = packageName, riskLevel = risk, reasons = reasons))
        } catch (e: PackageManager.NameNotFoundException) {
            AppResult.Error(AppError.ValidationError("التطبيق غير مثبّت على الجهاز", field = "packageName"))
        }
    }

    override suspend fun scanUrl(url: String): AppResult<UrlScanResult> {
        if (url.isBlank()) {
            return AppResult.Error(AppError.ValidationError("الرابط مطلوب", field = "url"))
        }
        val reasons = mutableListOf<String>()
        var risk = RiskLevel.LOW
        val lower = url.lowercase()

        if (!lower.startsWith("https://")) {
            reasons += "لا يستخدم HTTPS"
            risk = risk.escalate(RiskLevel.MEDIUM)
        }
        if (URL_SHORTENERS.any { lower.contains(it) }) {
            reasons += "يستخدم خدمة اختصار روابط (يخفي الوجهة الحقيقية)"
            risk = risk.escalate(RiskLevel.MEDIUM)
        }
        if (FINANCIAL_KEYWORDS.any { lower.contains(it) }) {
            reasons += "يحتوي كلمات مرتبطة بحسابات مالية أو تحقق هوية"
            risk = risk.escalate(RiskLevel.MEDIUM)
        }
        if (SUSPICIOUS_PATTERN.containsMatchIn(url)) {
            reasons += "يحتوي أنماط أحرف/أرقام غير معتادة لرابط رسمي"
            risk = risk.escalate(RiskLevel.MEDIUM)
        }
        if (reasons.isEmpty()) reasons += "لا توجد مؤشرات تصيّد من تحليل بنية الرابط"

        // build spec §22 — threat-intel lookups need a live backend we
        // don't have; this result is structural-analysis-only, by design.
        return AppResult.Success(UrlScanResult(url = url, riskLevel = risk, reasons = reasons))
    }

    override suspend fun analyzeSms(sender: String?, body: String): AppResult<SmsAnalysisResult> {
        if (body.isBlank()) {
            return AppResult.Error(AppError.ValidationError("نص الرسالة مطلوب", field = "body"))
        }
        val reasons = mutableListOf<String>()
        var risk = RiskLevel.LOW
        val lower = body.lowercase()

        if (Regex("https?://").containsMatchIn(lower)) {
            reasons += "تحتوي على رابط"
            risk = risk.escalate(RiskLevel.MEDIUM)
        }
        if (OTP_KEYWORDS.any { lower.contains(it) }) {
            reasons += "تطلب رمز تحقق أو كلمة سر"
            risk = risk.escalate(RiskLevel.HIGH)
        }
        if (PRIZE_KEYWORDS.any { lower.contains(it) }) {
            reasons += "تدّعي فوزاً بجائزة"
            risk = risk.escalate(RiskLevel.HIGH)
        }
        if (URGENCY_KEYWORDS.any { lower.contains(it) }) {
            reasons += "تستخدم أسلوب استعجال أو تهديد"
            risk = risk.escalate(RiskLevel.MEDIUM)
        }
        if (lower.contains(".apk") || lower.contains("تحميل التطبيق")) {
            reasons += "تطلب تحميل ملف/تطبيق"
            risk = risk.escalate(RiskLevel.HIGH)
        }
        if (reasons.isEmpty()) reasons += "لا توجد مؤشرات احتيال واضحة"

        val recommendation = when (risk) {
            RiskLevel.LOW -> "لا توجد مؤشرات خطر، لكن ابقَ حذراً مع أي رابط أو طلب مالي"
            RiskLevel.MEDIUM -> "توخَّ الحذر، تأكد من المصدر قبل الضغط على أي رابط"
            RiskLevel.HIGH, RiskLevel.CRITICAL -> "لا تضغط الرابط ولا ترسل أي بيانات أو رمز تحقق"
        }

        return AppResult.Success(SmsAnalysisResult(riskLevel = risk, reasons = reasons, recommendation = recommendation))
    }

    private fun factor(positive: Boolean, positiveLabel: String, negativeLabel: String, positivePoints: Int, negativePoints: Int) =
        SecurityScoreFactor(if (positive) positiveLabel else negativeLabel, if (positive) positivePoints else negativePoints)

    private fun isSecurityPatchRecent(): Boolean = try {
        val patchDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(Build.VERSION.SECURITY_PATCH)
        val sixMonthsMillis = 183L * 24 * 60 * 60 * 1000
        patchDate != null && (System.currentTimeMillis() - patchDate.time) < sixMonthsMillis
    } catch (e: Exception) {
        false
    }

    private fun hasRootIndicators(): Boolean = ROOT_INDICATOR_PATHS.any { File(it).exists() }

    private fun RiskLevel.escalate(to: RiskLevel): RiskLevel = if (to.ordinal > this.ordinal) to else this

    companion object {
        private val ROOT_INDICATOR_PATHS = listOf(
            "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su",
            "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su", "/data/local/su", "/su/bin/su"
        )
        private val URL_SHORTENERS = listOf("bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd")
        private val FINANCIAL_KEYWORDS = listOf("bank", "password", "verify", "otp", "مصرف", "تحقق", "كلمة السر", "زين-كاش", "zaincash")
        private val SUSPICIOUS_PATTERN = Regex("[%@]{2,}|-{2,}|[0-9]{6,}")
        private val OTP_KEYWORDS = listOf("otp", "رمز التحقق", "verification code", "كلمة السر", "password", " pin ")
        private val PRIZE_KEYWORDS = listOf("ربحت", "جائزة", "won", "prize", "congratulations", "مبروك")
        private val URGENCY_KEYWORDS = listOf("فوراً", "urgent", "immediately", "خلال ساعة", "سيتم إيقاف", "آخر فرصة")
    }
}
