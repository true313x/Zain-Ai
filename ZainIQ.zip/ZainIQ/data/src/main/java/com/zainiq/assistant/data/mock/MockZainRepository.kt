package com.zainiq.assistant.data.mock

import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.core.model.Money
import com.zainiq.assistant.domain.entities.AccountStatus
import com.zainiq.assistant.domain.entities.Customer
import com.zainiq.assistant.domain.entities.Offer
import com.zainiq.assistant.domain.entities.SubscriptionPackage
import com.zainiq.assistant.domain.entities.UsageSnapshot
import com.zainiq.assistant.domain.repositories.InternetDiagnosticsReport
import com.zainiq.assistant.domain.repositories.ZainRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import javax.inject.Inject
import javax.inject.Singleton

/**
 * build spec §47/§57 — the ONLY implementation of [ZainRepository] until a
 * real Zain API integration exists (see ProductionZainRepository — not yet
 * created, intentionally: build spec §57 forbids a production class that
 * has nothing real behind it). Every value returned here is invented demo
 * data for UI development and Demo Mode (§55) — never treat any of it as a
 * real customer, price, or balance. [MOCK_LATENCY_MS] exists so loading
 * states are visibly exercised in the UI rather than resolving instantly.
 */
@Singleton
class MockZainRepository @Inject constructor() : ZainRepository {

    private val demoCustomer = Customer(
        customerId = "demo-customer-1",
        msisdn = "07800000000",
        displayName = "مستخدم تجريبي",
        accountStatus = AccountStatus.ACTIVE,
        activePackage = demoPackage()
    )

    override fun observeCustomer(customerId: String): Flow<Customer> = flowOf(demoCustomer)

    override suspend fun getBalance(customerId: String): AppResult<Money> {
        delay(MOCK_LATENCY_MS)
        return AppResult.Success(Money.iqd(15_000))
    }

    override suspend fun getUsage(customerId: String): AppResult<UsageSnapshot> {
        delay(MOCK_LATENCY_MS)
        return AppResult.Success(
            UsageSnapshot(
                dataUsedMb = 3200,
                minutesUsed = 140,
                smsUsed = 12,
                recordedAtEpochMillis = System.currentTimeMillis()
            )
        )
    }

    override suspend fun getActivePackage(customerId: String): AppResult<SubscriptionPackage> {
        delay(MOCK_LATENCY_MS)
        return AppResult.Success(demoPackage())
    }

    override suspend fun getOffers(): AppResult<List<Offer>> {
        delay(MOCK_LATENCY_MS)
        return AppResult.Success(
            listOf(
                Offer(
                    offerId = "offer-net-10gb",
                    title = "باقة إنترنت 10GB",
                    description = "10 جيجابايت صالحة لمدة 30 يوم",
                    price = Money.iqd(10_000),
                    dataAllowanceMb = 10_240,
                    minutesAllowance = 0,
                    durationDays = 30,
                    isDemoData = true
                ),
                Offer(
                    offerId = "offer-combo-20",
                    title = "باقة مدمجة",
                    description = "5GB + 200 دقيقة لمدة 30 يوم",
                    price = Money.iqd(20_000),
                    dataAllowanceMb = 5_120,
                    minutesAllowance = 200,
                    durationDays = 30,
                    isDemoData = true
                )
            )
        )
    }

    override suspend fun subscribeToOffer(customerId: String, offerId: String): AppResult<Unit> {
        delay(MOCK_LATENCY_MS)
        return AppResult.Success(Unit)
    }

    override suspend fun cancelPackage(customerId: String, packageId: String): AppResult<Unit> {
        delay(MOCK_LATENCY_MS)
        return AppResult.Success(Unit)
    }

    override suspend fun runInternetDiagnostics(customerId: String): AppResult<InternetDiagnosticsReport> {
        delay(MOCK_LATENCY_MS)
        // Mirrors the exact example in build spec §10/§31: everything OK
        // except APN configuration, so the "fix" flow has something to do.
        return AppResult.Success(
            InternetDiagnosticsReport(
                simActive = true,
                packageActive = true,
                dataAvailable = true,
                networkAvailable = true,
                apnConfigured = false,
                suggestedFix = "إعدادات الإنترنت (APN) تحتاج تعديل"
            )
        )
    }

    private fun demoPackage() = SubscriptionPackage(
        packageId = "pkg-demo-1",
        name = "باقة إنترنت 10GB",
        dataAllowanceMb = 10_240,
        minutesAllowance = 300,
        smsAllowance = 100,
        expiresAtEpochMillis = System.currentTimeMillis() + 12L * 24 * 60 * 60 * 1000,
        isActive = true
    )

    companion object {
        private const val MOCK_LATENCY_MS = 350L
    }
}
