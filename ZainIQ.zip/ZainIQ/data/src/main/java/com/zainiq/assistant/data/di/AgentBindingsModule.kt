package com.zainiq.assistant.data.di

import com.zainiq.assistant.domain.agents.Agent
import com.zainiq.assistant.domain.agents.InternetAgent
import com.zainiq.assistant.domain.agents.OffersAgent
import com.zainiq.assistant.domain.agents.SecurityAgent
import com.zainiq.assistant.domain.agents.SupportAgent
import com.zainiq.assistant.domain.agents.TelecomAgent
import com.zainiq.assistant.domain.agents.ZainCashAgent
import com.zainiq.assistant.domain.tools.DiagnoseInternetTool
import com.zainiq.assistant.domain.tools.GetBalanceTool
import com.zainiq.assistant.domain.tools.GetOffersTool
import com.zainiq.assistant.domain.tools.GetPackageTool
import com.zainiq.assistant.domain.tools.GetTransactionsTool
import com.zainiq.assistant.domain.tools.GetUsageTool
import com.zainiq.assistant.domain.tools.GetWalletTool
import com.zainiq.assistant.domain.tools.PayBillTool
import com.zainiq.assistant.domain.tools.AnalyzeAppRiskTool
import com.zainiq.assistant.domain.tools.AnalyzeSmsTool
import com.zainiq.assistant.domain.tools.CreateTicketTool
import com.zainiq.assistant.domain.tools.EscalateToHumanTool
import com.zainiq.assistant.domain.tools.GetTicketTool
import com.zainiq.assistant.domain.tools.GetSecurityScoreTool
import com.zainiq.assistant.domain.tools.PurchaseCardTool
import com.zainiq.assistant.domain.tools.ScanDeviceTool
import com.zainiq.assistant.domain.tools.ScanUrlTool
import com.zainiq.assistant.domain.tools.RechargeTool
import com.zainiq.assistant.domain.tools.SubscribePackageTool
import com.zainiq.assistant.domain.tools.Tool
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet

/**
 * build spec §61 — each concrete Agent/Tool pair gets exactly one small
 * `@Binds @IntoSet` block like this one, added as its phase lands.
 * [AgentOrchestrator] and [ToolRegistry] never change when a new one is
 * added — that's the point of the multibinding pattern over a
 * hand-maintained list. Status: Internet ✅ Telecom ✅ Offers ✅ (get_offers
 * only — subscribe_package is reached from the Offers screen directly, not
 * yet from a chat/voice SUBSCRIBE intent) ZainCash ✅ (get_wallet only —
 * recharge is reached from the Zain Cash screen directly, same reasoning).
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class AgentBindingsModule {

    // --- Agents ---

    @Binds
    @IntoSet
    abstract fun bindInternetAgent(impl: InternetAgent): Agent

    @Binds
    @IntoSet
    abstract fun bindTelecomAgent(impl: TelecomAgent): Agent

    @Binds
    @IntoSet
    abstract fun bindOffersAgent(impl: OffersAgent): Agent

    @Binds
    @IntoSet
    abstract fun bindZainCashAgent(impl: ZainCashAgent): Agent

    @Binds
    @IntoSet
    abstract fun bindSecurityAgent(impl: SecurityAgent): Agent

    @Binds
    @IntoSet
    abstract fun bindSupportAgent(impl: SupportAgent): Agent

    // --- Tools ---

    @Binds
    @IntoSet
    abstract fun bindDiagnoseInternetTool(impl: DiagnoseInternetTool): Tool

    @Binds
    @IntoSet
    abstract fun bindGetBalanceTool(impl: GetBalanceTool): Tool

    @Binds
    @IntoSet
    abstract fun bindGetUsageTool(impl: GetUsageTool): Tool

    @Binds
    @IntoSet
    abstract fun bindGetPackageTool(impl: GetPackageTool): Tool

    @Binds
    @IntoSet
    abstract fun bindGetOffersTool(impl: GetOffersTool): Tool

    @Binds
    @IntoSet
    abstract fun bindSubscribePackageTool(impl: SubscribePackageTool): Tool

    @Binds
    @IntoSet
    abstract fun bindGetWalletTool(impl: GetWalletTool): Tool

    @Binds
    @IntoSet
    abstract fun bindGetTransactionsTool(impl: GetTransactionsTool): Tool

    @Binds
    @IntoSet
    abstract fun bindRechargeTool(impl: RechargeTool): Tool

    @Binds
    @IntoSet
    abstract fun bindPayBillTool(impl: PayBillTool): Tool

    @Binds
    @IntoSet
    abstract fun bindPurchaseCardTool(impl: PurchaseCardTool): Tool

    @Binds
    @IntoSet
    abstract fun bindScanUrlTool(impl: ScanUrlTool): Tool

    @Binds
    @IntoSet
    abstract fun bindAnalyzeSmsTool(impl: AnalyzeSmsTool): Tool

    @Binds
    @IntoSet
    abstract fun bindScanDeviceTool(impl: ScanDeviceTool): Tool

    @Binds
    @IntoSet
    abstract fun bindGetSecurityScoreTool(impl: GetSecurityScoreTool): Tool

    @Binds
    @IntoSet
    abstract fun bindAnalyzeAppRiskTool(impl: AnalyzeAppRiskTool): Tool

    @Binds
    @IntoSet
    abstract fun bindCreateTicketTool(impl: CreateTicketTool): Tool

    @Binds
    @IntoSet
    abstract fun bindGetTicketTool(impl: GetTicketTool): Tool

    @Binds
    @IntoSet
    abstract fun bindEscalateToHumanTool(impl: EscalateToHumanTool): Tool
}
