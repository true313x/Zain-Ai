package com.zainiq.assistant.data.mock

import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.core.model.Money
import com.zainiq.assistant.domain.entities.Biller
import com.zainiq.assistant.domain.entities.CardCategory
import com.zainiq.assistant.domain.entities.CardStatus
import com.zainiq.assistant.domain.entities.DigitalCard
import com.zainiq.assistant.domain.entities.Transaction
import com.zainiq.assistant.domain.entities.TransactionStatus
import com.zainiq.assistant.domain.entities.TransactionType
import com.zainiq.assistant.domain.entities.Wallet
import com.zainiq.assistant.domain.repositories.ZainCashRepository
import com.zainiq.assistant.domain.tools.RiskLevel
import kotlinx.coroutines.delay
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * build spec §47/§57 — the ONLY implementation of [ZainCashRepository]
 * until a real Zain Cash API integration exists. Every balance/transaction
 * here is invented demo data. Mirrors [MockZainRepository]'s doc comment —
 * see that file for why this pattern (mock-only until credentials exist,
 * never a hollow "production" class) is deliberate, not a shortcut.
 */
@Singleton
class MockZainCashRepository @Inject constructor() : ZainCashRepository {

    private var demoBalance = Money.iqd(85_000)
    private val demoTransactions = mutableListOf(
        Transaction(
            transactionId = "tx-demo-1",
            type = TransactionType.RECHARGE,
            amount = Money.iqd(10_000),
            status = TransactionStatus.SUCCESS,
            riskLevel = RiskLevel.LOW,
            createdAtEpochMillis = System.currentTimeMillis() - 2L * 24 * 60 * 60 * 1000
        ),
        Transaction(
            transactionId = "tx-demo-2",
            type = TransactionType.BILL_PAYMENT,
            amount = Money.iqd(25_000),
            status = TransactionStatus.SUCCESS,
            riskLevel = RiskLevel.LOW,
            createdAtEpochMillis = System.currentTimeMillis() - 6L * 24 * 60 * 60 * 1000
        )
    )

    // build spec §15 — matches the real app's biller list (see the
    // reference screenshots): electricity is the flagship one asked for.
    private val demoBillers = listOf(
        Biller(billerId = "biller-electricity", name = "فاتورة الكهرباء"),
        Biller(billerId = "biller-zain-deferred", name = "زين الدفع الآجل"),
        Biller(billerId = "biller-housing-fund", name = "صندوق الاسكان"),
        Biller(billerId = "biller-real-estate-bank", name = "المصرف العقاري")
    )

    // Representative catalog across categories — a handful of real,
    // recognizable provider names per category rather than an exhaustive
    // list, same "real architecture, representative data" scoping as the
    // rest of this mock repository.
    private val demoCards = listOf(
        DigitalCard("card-zain-internet-10", "زين انترنيت", CardCategory.INTERNET, Money.iqd(10_000)),
        DigitalCard("card-zain-internet-25", "زين انترنيت", CardCategory.INTERNET, Money.iqd(25_000)),
        DigitalCard("card-asiacell-10", "اسياسيل", CardCategory.TELECOM, Money.iqd(10_000)),
        DigitalCard("card-korek-10", "كورك", CardCategory.TELECOM, Money.iqd(10_000)),
        DigitalCard("card-pubg-60uc", "بوبجي", CardCategory.GAMES, Money.iqd(5_000)),
        DigitalCard("card-pubg-ns", "بوبجي نيو ستيت", CardCategory.GAMES, Money.iqd(5_000)),
        DigitalCard("card-googleplay-25", "Google Play", CardCategory.GAMES, Money.iqd(35_000)),
        DigitalCard("card-steam-10", "ستيم", CardCategory.GAMES, Money.iqd(15_000)),
        DigitalCard("card-itunes-15", "ايتونز", CardCategory.ENTERTAINMENT, Money.iqd(20_000))
    )

    override suspend fun getWallet(customerId: String): AppResult<Wallet> {
        delay(MOCK_LATENCY_MS)
        return AppResult.Success(Wallet(customerId = customerId, balance = demoBalance, cardStatus = CardStatus.ACTIVE))
    }

    override suspend fun getTransactions(customerId: String, limit: Int): AppResult<List<Transaction>> {
        delay(MOCK_LATENCY_MS)
        return AppResult.Success(demoTransactions.sortedByDescending { it.createdAtEpochMillis }.take(limit))
    }

    override suspend fun recharge(customerId: String, msisdn: String, amountMinorUnits: Long): AppResult<Transaction> {
        delay(MOCK_LATENCY_MS)
        if (amountMinorUnits > demoBalance.minorUnits) {
            return AppResult.Error(
                com.zainiq.assistant.core.common.AppError.PaymentError(
                    message = "الرصيد غير كافٍ",
                    code = "insufficient_funds"
                )
            )
        }
        demoBalance = demoBalance - Money(amountMinorUnits, demoBalance.currency)
        val tx = Transaction(
            transactionId = "tx-${UUID.randomUUID()}",
            type = TransactionType.RECHARGE,
            amount = Money(amountMinorUnits, demoBalance.currency),
            status = TransactionStatus.SUCCESS,
            riskLevel = RiskLevel.HIGH,
            createdAtEpochMillis = System.currentTimeMillis()
        )
        demoTransactions.add(0, tx)
        return AppResult.Success(tx)
    }

    override suspend fun payBill(customerId: String, billId: String, amountMinorUnits: Long): AppResult<Transaction> {
        delay(MOCK_LATENCY_MS)
        if (amountMinorUnits > demoBalance.minorUnits) {
            return AppResult.Error(
                com.zainiq.assistant.core.common.AppError.PaymentError("الرصيد غير كافٍ", code = "insufficient_funds")
            )
        }
        demoBalance = demoBalance - Money(amountMinorUnits, demoBalance.currency)
        val tx = Transaction(
            transactionId = "tx-${UUID.randomUUID()}",
            type = TransactionType.BILL_PAYMENT,
            amount = Money(amountMinorUnits, demoBalance.currency),
            status = TransactionStatus.SUCCESS,
            riskLevel = RiskLevel.HIGH,
            createdAtEpochMillis = System.currentTimeMillis()
        )
        demoTransactions.add(0, tx)
        return AppResult.Success(tx)
    }

    override suspend fun getBillers(): AppResult<List<Biller>> {
        delay(MOCK_LATENCY_MS)
        return AppResult.Success(demoBillers)
    }

    override suspend fun getBillAmount(billerId: String, billNumber: String): AppResult<Money> {
        delay(MOCK_LATENCY_MS)
        if (billNumber.isBlank()) {
            return AppResult.Error(com.zainiq.assistant.core.common.AppError.ValidationError("رقم الفاتورة مطلوب", field = "billNumber"))
        }
        // Demo-only: a stable, deterministic "amount due" per bill number so
        // repeated lookups for the same number don't jump around.
        val demoAmount = 5_000L + (billNumber.sumOf { it.code } % 40) * 1_000L
        return AppResult.Success(Money.iqd(demoAmount))
    }

    override suspend fun getCardCatalog(category: CardCategory): AppResult<List<DigitalCard>> {
        delay(MOCK_LATENCY_MS)
        val filtered = if (category == CardCategory.ALL) demoCards else demoCards.filter { it.category == category }
        return AppResult.Success(filtered)
    }

    override suspend fun purchaseCard(customerId: String, cardId: String): AppResult<Transaction> {
        delay(MOCK_LATENCY_MS)
        val card = demoCards.firstOrNull { it.cardId == cardId }
            ?: return AppResult.Error(com.zainiq.assistant.core.common.AppError.ValidationError("البطاقة غير موجودة", field = "cardId"))
        if (card.price.minorUnits > demoBalance.minorUnits) {
            return AppResult.Error(
                com.zainiq.assistant.core.common.AppError.PaymentError("الرصيد غير كافٍ", code = "insufficient_funds")
            )
        }
        demoBalance = demoBalance - card.price
        val tx = Transaction(
            transactionId = "tx-${UUID.randomUUID()}",
            type = TransactionType.CARD_PURCHASE,
            amount = card.price,
            status = TransactionStatus.SUCCESS,
            riskLevel = RiskLevel.HIGH,
            createdAtEpochMillis = System.currentTimeMillis()
        )
        demoTransactions.add(0, tx)
        return AppResult.Success(tx)
    }

    override suspend fun transfer(customerId: String, toMsisdn: String, amountMinorUnits: Long): AppResult<Transaction> {
        delay(MOCK_LATENCY_MS)
        val tx = Transaction(
            transactionId = "tx-${UUID.randomUUID()}",
            type = TransactionType.TRANSFER,
            amount = Money(amountMinorUnits, demoBalance.currency),
            status = TransactionStatus.SUCCESS,
            riskLevel = RiskLevel.HIGH,
            createdAtEpochMillis = System.currentTimeMillis()
        )
        demoTransactions.add(0, tx)
        return AppResult.Success(tx)
    }

    override suspend fun reportFraud(customerId: String, transactionId: String, note: String): AppResult<Unit> {
        delay(MOCK_LATENCY_MS)
        return AppResult.Success(Unit)
    }

    companion object {
        private const val MOCK_LATENCY_MS = 350L
    }
}
