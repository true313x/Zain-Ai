package com.zainiq.assistant.data.mock

import com.zainiq.assistant.domain.entities.AppNotification
import com.zainiq.assistant.domain.entities.NotificationCategory
import com.zainiq.assistant.domain.repositories.NotificationRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/** build spec §36/§47 — demo notifications only; real ones would come from
 *  push/backend events. Deliberately a short list: "Do not spam users". */
@Singleton
class MockNotificationRepository @Inject constructor() : NotificationRepository {

    private val day = 86_400_000L

    private val items = MutableStateFlow(
        listOf(
            AppNotification("n1", NotificationCategory.PACKAGE_EXPIRY, "باقتك تنتهي قريباً", "تنتهي باقة الإنترنت خلال 3 أيام (بيانات تجريبية)", false, System.currentTimeMillis() - 2 * 3_600_000L),
            AppNotification("n2", NotificationCategory.SECURITY_ALERT, "تنبيه أمني", "تم رصد محاولة دخول من جهاز جديد (بيانات تجريبية)", false, System.currentTimeMillis() - day),
            AppNotification("n3", NotificationCategory.TICKET_UPDATE, "تحديث على طلبك ZIQ-1001", "تم تحويل طلبك إلى الفريق الفني (بيانات تجريبية)", true, System.currentTimeMillis() - 2 * day)
        )
    )

    override fun observeNotifications(customerId: String): Flow<List<AppNotification>> =
        items.map { list -> list.sortedByDescending { it.createdAtEpochMillis } }

    override suspend fun markRead(notificationId: String) {
        items.value = items.value.map { if (it.notificationId == notificationId) it.copy(isRead = true) else it }
    }

    override suspend fun markAllRead(customerId: String) {
        items.value = items.value.map { it.copy(isRead = true) }
    }
}
