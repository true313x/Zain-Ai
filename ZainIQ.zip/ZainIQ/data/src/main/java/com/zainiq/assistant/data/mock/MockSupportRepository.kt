package com.zainiq.assistant.data.mock

import com.zainiq.assistant.core.common.AppError
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.domain.entities.EscalationContext
import com.zainiq.assistant.domain.entities.Ticket
import com.zainiq.assistant.domain.entities.TicketAuthor
import com.zainiq.assistant.domain.entities.TicketEvent
import com.zainiq.assistant.domain.entities.TicketPriority
import com.zainiq.assistant.domain.entities.TicketStatus
import com.zainiq.assistant.domain.repositories.SupportRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * build spec §47/§57 — in-memory stand-in until a real Zain ticketing
 * backend exists. Tickets live only for the process lifetime; nothing here
 * is persisted or sent anywhere, so "a human agent received this" is
 * *simulated* — the ticket's timeline says so plainly rather than
 * pretending someone was actually notified.
 */
@Singleton
class MockSupportRepository @Inject constructor() : SupportRepository {

    private val now get() = System.currentTimeMillis()
    private var counter = 1002

    private val tickets = MutableStateFlow(
        listOf(
            Ticket(
                ticketId = "ticket-demo-1",
                ticketNumber = "ZIQ-1001",
                category = "internet",
                status = TicketStatus.IN_PROGRESS,
                priority = TicketPriority.NORMAL,
                summary = "بطء في الإنترنت بعد تجديد الباقة (بيانات تجريبية)",
                timeline = listOf(
                    TicketEvent(TicketAuthor.CUSTOMER, "الإنترنت بطيء منذ يومين", System.currentTimeMillis() - 2L * 86_400_000),
                    TicketEvent(TicketAuthor.SYSTEM, "تم تحويل الطلب إلى الفريق الفني", System.currentTimeMillis() - 86_400_000)
                ),
                createdAtEpochMillis = System.currentTimeMillis() - 2L * 86_400_000,
                updatedAtEpochMillis = System.currentTimeMillis() - 86_400_000
            )
        )
    )

    override fun observeTickets(customerId: String): Flow<List<Ticket>> =
        tickets.map { list -> list.sortedByDescending { it.updatedAtEpochMillis } }

    override suspend fun getTicket(ticketId: String): AppResult<Ticket> {
        delay(MOCK_LATENCY_MS)
        val ticket = tickets.value.firstOrNull { it.ticketId == ticketId }
            ?: return AppResult.Error(AppError.ValidationError("التذكرة غير موجودة", field = "ticketId"))
        return AppResult.Success(ticket)
    }

    override suspend fun createTicket(
        customerId: String,
        category: String,
        summary: String,
        priority: TicketPriority
    ): AppResult<Ticket> {
        delay(MOCK_LATENCY_MS)
        val ticket = newTicket(category, summary, priority, listOf(TicketEvent(TicketAuthor.CUSTOMER, summary, now)))
        tickets.value = listOf(ticket) + tickets.value
        return AppResult.Success(ticket)
    }

    override suspend fun escalateToHuman(context: EscalationContext): AppResult<Ticket> {
        delay(MOCK_LATENCY_MS)
        val events = buildList {
            add(TicketEvent(TicketAuthor.CUSTOMER, context.issueSummary, context.createdAtEpochMillis))
            if (context.diagnosticsPerformed.isNotEmpty()) {
                add(TicketEvent(TicketAuthor.AI, "فحوصات تمت: " + context.diagnosticsPerformed.joinToString("، "), now))
            }
            if (context.actionsAttempted.isNotEmpty()) {
                add(TicketEvent(TicketAuthor.AI, "إجراءات جُرّبت: " + context.actionsAttempted.joinToString("، "), now))
            }
            if (context.errorsEncountered.isNotEmpty()) {
                add(TicketEvent(TicketAuthor.AI, "أخطاء: " + context.errorsEncountered.joinToString("، "), now))
            }
            add(TicketEvent(TicketAuthor.AI, "الإجراء المقترح: ${context.recommendedNextAction}", now))
            add(TicketEvent(TicketAuthor.SYSTEM, "تحويل لموظف (محاكاة — لا يوجد نظام تذاكر حقيقي متصل بعد)", now))
        }
        val ticket = newTicket("human_escalation", context.issueSummary, context.priority, events)
        tickets.value = listOf(ticket) + tickets.value
        return AppResult.Success(ticket)
    }

    private fun newTicket(category: String, summary: String, priority: TicketPriority, timeline: List<TicketEvent>): Ticket {
        val number = "ZIQ-${counter++}"
        return Ticket(
            ticketId = "ticket-${UUID.randomUUID()}",
            ticketNumber = number,
            category = category,
            status = TicketStatus.OPEN,
            priority = priority,
            summary = summary,
            timeline = timeline,
            createdAtEpochMillis = now,
            updatedAtEpochMillis = now
        )
    }

    companion object {
        private const val MOCK_LATENCY_MS = 300L
    }
}
