package com.zainiq.assistant.core.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "security_events")
data class SecurityEventEntity(
    @PrimaryKey val eventId: String,
    val customerId: String,
    val type: String, // NEW_DEVICE, SIM_CHANGE, ESIM_CHANGE, ACCOUNT_RECOVERY, PASSWORD_CHANGE, SUSPICIOUS_TRANSACTION
    val riskLevel: String,
    val reasonSummary: String,
    val createdAtEpochMillis: Long
)

/** One row per device, refreshed on each Security Center scan (build spec §20/§21). */
@Entity(tableName = "device_security_state")
data class DeviceSecurityStateEntity(
    @PrimaryKey val deviceId: String,
    val securityScore: Int,
    val hasSecureLock: Boolean,
    val isEncrypted: Boolean,
    val hasRecentPatch: Boolean,
    val hasUnknownSourcesEnabled: Boolean,
    val riskyPermissionCount: Int,
    val lastScanAtEpochMillis: Long
)
