package com.zainiq.assistant.core.database.di

import android.content.Context
import androidx.room.Room
import com.zainiq.assistant.core.database.ZainDatabase
import com.zainiq.assistant.core.database.dao.CustomerDao
import com.zainiq.assistant.core.database.dao.NotificationDao
import com.zainiq.assistant.core.database.dao.TicketDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    // TODO(Phase 2): open with a Keystore-derived passphrase via
    // core:security.SecureStorage (SupportFactory / SQLCipher) instead of
    // plain Room.databaseBuilder — tracked alongside the security hardening
    // pass in build spec §42/§43. Left as a clear seam, not silently plain.
    @Provides
    @Singleton
    fun provideZainDatabase(@ApplicationContext context: Context): ZainDatabase =
        Room.databaseBuilder(context, ZainDatabase::class.java, ZainDatabase.DATABASE_NAME)
            .fallbackToDestructiveMigrationOnDowngrade(dropAllTables = true)
            .build()

    @Provides
    fun provideCustomerDao(db: ZainDatabase): CustomerDao = db.customerDao()

    @Provides
    fun provideTicketDao(db: ZainDatabase): TicketDao = db.ticketDao()

    @Provides
    fun provideNotificationDao(db: ZainDatabase): NotificationDao = db.notificationDao()
}
