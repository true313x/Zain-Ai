package com.zainiq.assistant.core.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val ticketId: String,
    val customerId: String,
    val category: String,
    val status: String, // OPEN, IN_PROGRESS, WAITING_FOR_CUSTOMER, RESOLVED, CLOSED
    val summary: String,
    val priority: String,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val notificationId: String,
    val customerId: String,
    val category: String, // PACKAGE_EXPIRY, PAYMENT, SECURITY_ALERT, TICKET_UPDATE, SERVICE
    val title: String,
    val body: String,
    val isRead: Boolean = false,
    val createdAtEpochMillis: Long
)
