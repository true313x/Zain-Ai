package com.zainiq.assistant.core.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Build spec §49 — Database. Mirrors the customer's Zain account at a glance. */
@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val customerId: String,
    val msisdn: String, // phone number — never logged in plaintext (see core:logging)
    val displayName: String,
    val accountStatus: String,
    val lastSyncedAtEpochMillis: Long
)

@Entity(tableName = "packages")
data class PackageEntity(
    @PrimaryKey val packageId: String,
    val customerId: String,
    val name: String,
    val dataAllowanceMb: Long,
    val minutesAllowance: Long,
    val smsAllowance: Long,
    val expiresAtEpochMillis: Long,
    val isActive: Boolean
)

@Entity(tableName = "usage")
data class UsageEntity(
    @PrimaryKey val usageId: String,
    val customerId: String,
    val packageId: String,
    val dataUsedMb: Long,
    val minutesUsed: Long,
    val smsUsed: Long,
    val recordedAtEpochMillis: Long
)

@Entity(tableName = "offers")
data class OfferEntity(
    @PrimaryKey val offerId: String,
    val title: String,
    val description: String,
    val priceMinorUnits: Long,
    val currency: String,
    val dataAllowanceMb: Long,
    val minutesAllowance: Long,
    val durationDays: Int,
    val isDemoData: Boolean = true // build spec §12/§58 — mock data must self-identify
)
