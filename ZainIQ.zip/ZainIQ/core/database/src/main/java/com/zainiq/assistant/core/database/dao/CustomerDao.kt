package com.zainiq.assistant.core.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.zainiq.assistant.core.database.entities.CustomerEntity
import com.zainiq.assistant.core.database.entities.OfferEntity
import com.zainiq.assistant.core.database.entities.PackageEntity
import com.zainiq.assistant.core.database.entities.UsageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers WHERE customerId = :customerId LIMIT 1")
    fun observeCustomer(customerId: String): Flow<CustomerEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCustomer(customer: CustomerEntity)

    @Query("SELECT * FROM packages WHERE customerId = :customerId AND isActive = 1")
    fun observeActivePackages(customerId: String): Flow<List<PackageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPackages(packages: List<PackageEntity>)

    @Query("SELECT * FROM usage WHERE customerId = :customerId ORDER BY recordedAtEpochMillis DESC LIMIT 1")
    suspend fun latestUsage(customerId: String): UsageEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertUsage(usage: UsageEntity)

    @Query("SELECT * FROM offers")
    fun observeOffers(): Flow<List<OfferEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOffers(offers: List<OfferEntity>)
}
