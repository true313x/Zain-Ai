package com.zainiq.assistant.core.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.zainiq.assistant.core.database.dao.CustomerDao
import com.zainiq.assistant.core.database.dao.NotificationDao
import com.zainiq.assistant.core.database.dao.TicketDao
import com.zainiq.assistant.core.database.entities.ConversationEntity
import com.zainiq.assistant.core.database.entities.CustomerEntity
import com.zainiq.assistant.core.database.entities.DeviceSecurityStateEntity
import com.zainiq.assistant.core.database.entities.MessageEntity
import com.zainiq.assistant.core.database.entities.NotificationEntity
import com.zainiq.assistant.core.database.entities.OfferEntity
import com.zainiq.assistant.core.database.entities.PackageEntity
import com.zainiq.assistant.core.database.entities.SecurityEventEntity
import com.zainiq.assistant.core.database.entities.TicketEntity
import com.zainiq.assistant.core.database.entities.TransactionEntity
import com.zainiq.assistant.core.database.entities.UsageEntity

/**
 * Single local database for the whole app (build spec §49). Encrypted at
 * rest via SQLCipher/Keystore-backed passphrase — wired in
 * core:security.SecureStorage + the DI provider in di/DatabaseModule.kt —
 * never plain SQLite for anything touching customer or financial data.
 *
 * DAOs are added incrementally as each feature needs them; every entity the
 * spec calls for is declared below now so migrations start from a complete
 * schema rather than needing destructive changes later.
 */
@Database(
    entities = [
        CustomerEntity::class,
        PackageEntity::class,
        UsageEntity::class,
        OfferEntity::class,
        TransactionEntity::class,
        TicketEntity::class,
        NotificationEntity::class,
        SecurityEventEntity::class,
        DeviceSecurityStateEntity::class,
        ConversationEntity::class,
        MessageEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class ZainDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao
    abstract fun ticketDao(): TicketDao
    abstract fun notificationDao(): NotificationDao
    // TODO: TransactionDao, SecurityEventDao, ConversationDao — added
    // alongside their respective features.

    companion object {
        const val DATABASE_NAME = "zainiq_secure.db"
    }
}
