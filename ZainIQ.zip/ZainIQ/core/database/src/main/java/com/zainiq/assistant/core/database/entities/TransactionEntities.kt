package com.zainiq.assistant.core.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val transactionId: String,
    val customerId: String,
    val type: String, // RECHARGE, BILL_PAYMENT, TRANSFER, CARD_PURCHASE, ...
    val amountMinorUnits: Long,
    val currency: String,
    val status: String, // PENDING, SUCCESS, FAILED
    val riskLevel: String, // LOW, MEDIUM, HIGH, CRITICAL — from FraudRiskEngine
    val createdAtEpochMillis: Long
)
