package com.zainiq.assistant.core.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val conversationId: String,
    val customerId: String,
    val startedAtEpochMillis: Long,
    val lastMessageAtEpochMillis: Long
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val messageId: String,
    val conversationId: String,
    val sender: String, // USER, AI, SYSTEM
    val text: String,
    val recognizedIntent: String? = null,
    val createdAtEpochMillis: Long
)
