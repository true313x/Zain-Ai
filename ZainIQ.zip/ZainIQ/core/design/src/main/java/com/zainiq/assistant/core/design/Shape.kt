package com.zainiq.assistant.core.design

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

val ZainShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),   // default card radius
    large = RoundedCornerShape(24.dp),    // bottom sheets, the voice mic button
    extraLarge = RoundedCornerShape(32.dp)
)
