package com.zainiq.assistant.core.design

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val ZainLightColorScheme = lightColorScheme(
    primary = ZainPurple40,
    onPrimary = NeutralLightBackground,
    primaryContainer = ZainPurple90,
    onPrimaryContainer = ZainPurple10,
    secondary = ZainGold40,
    tertiary = ZainTeal40,
    background = NeutralLightBackground,
    surface = NeutralLightSurface,
    error = RiskHigh
)

private val ZainDarkColorScheme = darkColorScheme(
    primary = ZainPurple80,
    onPrimary = ZainPurple10,
    primaryContainer = ZainPurple30,
    onPrimaryContainer = ZainPurple90,
    secondary = ZainGold80,
    tertiary = ZainTeal80,
    background = NeutralDarkBackground,
    surface = NeutralDarkSurface,
    error = RiskHigh
)

/**
 * Root theme for the whole app. [useDarkTheme] defaults to the system
 * setting; Settings (feature:settings, Phase 2+) overrides this with a
 * persisted Light/Dark/System choice read from DataStore via
 * core:localization's preferences store.
 */
@Composable
fun ZainIQTheme(
    useDarkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (useDarkTheme) ZainDarkColorScheme else ZainLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = ZainTypography,
        shapes = ZainShapes,
        content = content
    )
}
