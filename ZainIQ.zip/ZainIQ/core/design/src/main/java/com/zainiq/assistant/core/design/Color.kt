package com.zainiq.assistant.core.design

import androidx.compose.ui.graphics.Color

/**
 * ZainIQ palette — a purple-forward telecom identity in the same family as
 * Zain's real-world brand color, expressed here as an original color scheme
 * only (no logos, wordmarks or other Zain-owned assets are used anywhere in
 * this project — see §38/§58 of the build spec).
 */

// Core purple family
val ZainPurple10 = Color(0xFF1A0A2E)
val ZainPurple20 = Color(0xFF2E1152)
val ZainPurple30 = Color(0xFF44197A)
val ZainPurple40 = Color(0xFF5B21A6) // primary (light)
val ZainPurple80 = Color(0xFFCBB2F0) // primary (dark)
val ZainPurple90 = Color(0xFFEADDFF)

// Accent — warm gold for CTAs / the voice mic button
val ZainGold40 = Color(0xFFB8860B)
val ZainGold80 = Color(0xFFE8C468)

// Tertiary — teal, used for security/positive states
val ZainTeal40 = Color(0xFF157F73)
val ZainTeal80 = Color(0xFF8FD9CE)

// Risk / status colors — shared with RiskLevel across Security + Zain Cash
val RiskLow = Color(0xFF2E7D32)
val RiskMedium = Color(0xFFE8A317)
val RiskHigh = Color(0xFFE64A19)
val RiskCritical = Color(0xFFC62828)

// Neutrals
val NeutralLightBackground = Color(0xFFFFFBFE)
val NeutralLightSurface = Color(0xFFF5EFFA)
val NeutralDarkBackground = Color(0xFF141018)
val NeutralDarkSurface = Color(0xFF1F1A26)
