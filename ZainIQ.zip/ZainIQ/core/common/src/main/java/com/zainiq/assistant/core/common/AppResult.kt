package com.zainiq.assistant.core.common

/**
 * Uniform outcome wrapper for repository/tool/use-case calls, so every layer
 * (Agent → Tool → Repository → API) can propagate success/failure/loading
 * without throwing across module boundaries.
 */
sealed interface AppResult<out T> {
    data class Success<T>(val data: T) : AppResult<T>
    data class Error(val error: AppError) : AppResult<Nothing>
    data object Loading : AppResult<Nothing>
}

/**
 * Typed error hierarchy (see build spec §50 — Error Handling). UI layers map
 * these to friendly Arabic copy; nothing here is ever a raw stack trace.
 */
sealed class AppError(open val message: String, open val cause: Throwable? = null) {
    data class NetworkError(override val message: String, override val cause: Throwable? = null) : AppError(message, cause)
    data class AuthenticationError(override val message: String) : AppError(message)
    data class AuthorizationError(override val message: String) : AppError(message)
    data class ValidationError(override val message: String, val field: String? = null) : AppError(message)
    data class TimeoutError(override val message: String) : AppError(message)
    data class ServiceUnavailable(override val message: String) : AppError(message)
    data class PaymentError(override val message: String, val code: String? = null) : AppError(message)
    data class UnknownError(override val message: String, override val cause: Throwable? = null) : AppError(message, cause)
}

inline fun <T, R> AppResult<T>.map(transform: (T) -> R): AppResult<R> = when (this) {
    is AppResult.Success -> AppResult.Success(transform(data))
    is AppResult.Error -> this
    AppResult.Loading -> AppResult.Loading
}

inline fun <T> AppResult<T>.onSuccess(action: (T) -> Unit): AppResult<T> {
    if (this is AppResult.Success) action(data)
    return this
}

inline fun <T> AppResult<T>.onError(action: (AppError) -> Unit): AppResult<T> {
    if (this is AppResult.Error) action(error)
    return this
}
