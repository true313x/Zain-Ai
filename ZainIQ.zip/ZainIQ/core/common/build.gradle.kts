plugins {
    alias(libs.plugins.android.library)
}

android {
    namespace = "com.zainiq.assistant.core.common"
    compileSdk = 37
    defaultConfig { minSdk = 26 }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    api(libs.kotlinx.coroutines.android)
    api(libs.javax.inject)
    testImplementation(libs.junit)
}
