package com.zainiq.assistant.core.analytics

/**
 * No analytics provider is wired up yet — no SDK, no endpoint, nothing
 * leaving the device. [NoOpAnalyticsTracker] is the default (and, for
 * Phase 1, only) binding so every call site can start instrumenting events
 * now without blocking on a provider decision, per build spec §43 (send
 * only what's necessary, and nothing without a deliberate choice to do so).
 *
 * Event names are an enum, not free-form strings, so a typo can't silently
 * create a new event that never gets analyzed.
 */
interface AnalyticsTracker {
    fun track(event: AnalyticsEvent, properties: Map<String, String> = emptyMap())
}

enum class AnalyticsEvent {
    APP_OPENED,
    HOME_SERVICE_TAPPED,
    VOICE_SESSION_STARTED,
    AI_INTENT_RECOGNIZED,
    TOOL_INVOKED,
    CONFIRMATION_SHOWN,
    CONFIRMATION_ACCEPTED,
    CONFIRMATION_DECLINED,
    ESCALATED_TO_HUMAN,
    TICKET_CREATED
}

class NoOpAnalyticsTracker : AnalyticsTracker {
    override fun track(event: AnalyticsEvent, properties: Map<String, String>) {
        // Intentionally empty — see class doc above.
    }
}
