package com.zainiq.assistant.core.analytics.di

import com.zainiq.assistant.core.analytics.AnalyticsTracker
import com.zainiq.assistant.core.analytics.NoOpAnalyticsTracker
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class AnalyticsModule {
    @Binds
    @Singleton
    abstract fun bindAnalyticsTracker(impl: NoOpAnalyticsTracker): AnalyticsTracker
}
