package com.zainiq.assistant.core.model

import kotlinx.serialization.Serializable

/**
 * Every price/balance/transaction amount in the app (packages, offers, Zain
 * Cash balance, digital card prices) should flow through this type rather than a
 * raw Double — floating point has no place in money, and every screen
 * showing an amount must show its currency alongside it. Amounts are stored
 * as minor units (fils) to avoid rounding drift, matching how most telecom
 * and payment backends represent currency.
 */
@Serializable
data class Money(
    val minorUnits: Long,
    val currency: Currency = Currency.IQD
) {
    val majorUnitsValue: Double get() = minorUnits / 1000.0

    operator fun plus(other: Money): Money {
        require(currency == other.currency) { "Cannot add differing currencies" }
        return copy(minorUnits = minorUnits + other.minorUnits)
    }

    operator fun minus(other: Money): Money {
        require(currency == other.currency) { "Cannot subtract differing currencies" }
        return copy(minorUnits = minorUnits - other.minorUnits)
    }

    companion object {
        fun iqd(dinars: Long): Money = Money(minorUnits = dinars * 1000, currency = Currency.IQD)
    }
}

@Serializable
enum class Currency(val isoCode: String, val symbol: String) {
    IQD("IQD", "د.ع"),
    USD("USD", "$")
}
