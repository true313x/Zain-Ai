package com.zainiq.assistant.core.localization

import android.content.Context
import androidx.core.os.LocaleListCompat
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

enum class AppLanguage(val tag: String, val isRtl: Boolean) {
    ARABIC("ar", isRtl = true),
    ENGLISH("en", isRtl = false)
}

private val Context.localeDataStore by preferencesDataStore(name = "zainiq_locale_prefs")
private val LANGUAGE_KEY = stringPreferencesKey("app_language")

/**
 * Build spec §39 — RTL. Arabic is the default on first launch (matches
 * app/res values/strings.xml being the Arabic/default resource set); the
 * user's explicit choice, once made in Settings (Phase 2+), always wins and
 * is applied via [androidx.core.app.AppCompatDelegate.setApplicationLocales]
 * from the composition root so Compose, resources and layout direction all
 * switch together.
 */
@Singleton
class LocaleManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    val currentLanguage: Flow<AppLanguage> = context.localeDataStore.data.map { prefs ->
        AppLanguage.entries.firstOrNull { it.tag == prefs[LANGUAGE_KEY] } ?: AppLanguage.ARABIC
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.localeDataStore.edit { it[LANGUAGE_KEY] = language.tag }
    }

    fun localeListFor(language: AppLanguage): LocaleListCompat =
        LocaleListCompat.forLanguageTags(language.tag)
}
