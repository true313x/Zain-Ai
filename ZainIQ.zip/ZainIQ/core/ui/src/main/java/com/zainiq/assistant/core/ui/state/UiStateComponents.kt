package com.zainiq.assistant.core.ui.state

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Every screen in the app implements these five states (build spec §56).
 * Centralizing them here means a feature screen's `when` block stays a
 * one-line call per branch instead of re-implementing spinners/messages.
 *
 * Default copy is Arabic (the app's primary locale, matching app/res
 * values/strings.xml). Callers in feature modules that need localized text
 * from their own module's resources can override [message] directly —
 * these defaults exist so a screen compiles and reads sensibly even before
 * its own strings are wired up.
 */

@Composable
fun LoadingState(
    message: String = "جارِ التحميل…",
    modifier: Modifier = Modifier
) {
    CenteredState(modifier) {
        CircularProgressIndicator()
        Text(text = message)
    }
}

@Composable
fun ErrorState(
    message: String = "حدث خطأ غير متوقع",
    retryLabel: String = "إعادة المحاولة",
    onRetry: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    CenteredState(modifier) {
        Text(text = message, style = MaterialTheme.typography.bodyLarge)
        if (onRetry != null) {
            Button(onClick = onRetry) { Text(retryLabel) }
        }
    }
}

@Composable
fun EmptyState(
    message: String = "لا توجد بيانات لعرضها",
    modifier: Modifier = Modifier
) {
    CenteredState(modifier) { Text(text = message, style = MaterialTheme.typography.bodyLarge) }
}

@Composable
fun OfflineState(
    message: String = "أنت غير متصل بالإنترنت",
    retryLabel: String = "إعادة المحاولة",
    onRetry: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    CenteredState(modifier) {
        Text(text = message, style = MaterialTheme.typography.bodyLarge)
        if (onRetry != null) {
            Button(onClick = onRetry) { Text(retryLabel) }
        }
    }
}

@Composable
private fun CenteredState(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically)
    ) {
        content()
    }
}
