package com.zainiq.assistant.core.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

/**
 * Used by every feature module whose real screen hasn't been built yet in
 * this phase (see the build spec's phase plan — most feature/* screens land
 * in Phases 2-6). Keeps the navigation graph fully wired end-to-end now,
 * so each screen only needs its placeholder call swapped for a real one
 * later; no navigation or module wiring changes required.
 */
@Composable
fun PlaceholderScreen(
    title: String,
    subtitle: String = "قيد التطوير — سيتم تفعيلها في مرحلة لاحقة",
    onBack: (() -> Unit)? = null,
    backLabel: String = "رجوع"
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically)
    ) {
        Text(text = title, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
        Text(text = subtitle, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        if (onBack != null) {
            TextButton(onClick = onBack) { Text(backLabel) }
        }
    }
}
