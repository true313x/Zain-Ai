package com.zainiq.assistant.core.network.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

/**
 * Provides the shared OkHttp/Retrofit stack. Per-service Retrofit instances
 * (ZainApi, ZainCashApi, SecurityApi — added in :data as each
 * agent is implemented) are built on top of [provideRetrofitBuilder] with
 * their own base URL from [com.zainiq.assistant.core.network.NetworkConfig.endpointsFor].
 *
 * Deliberately NOT providing a concrete `ZainApi` etc. here yet — see build
 * spec §57 (No Fake Integration): a Retrofit interface with no real backend
 * behind it is worse than no interface at all, since it invites accidental
 * calls to a mock host that looks production-shaped. MockZainRepository in
 * :data implements the domain repository contracts directly instead.
 */
@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideJson(): Json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        isLenient = true
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        val logging = HttpLoggingInterceptor().apply {
            // NEVER log bodies in release — PII/financial payloads must not hit logcat
            // (build spec §42/§43). Swap to Level.BODY only in a debug-only variant.
            level = HttpLoggingInterceptor.Level.BASIC
        }
        return OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .addInterceptor(logging)
            // TODO: attach CertificatePinner built from CertificatePinningConfig
            // once production pins exist; attach an auth-token interceptor once
            // the auth/session design lands alongside the Telecom Agent.
            .build()
    }

    @Provides
    @Singleton
    fun provideRetrofitBuilder(okHttpClient: OkHttpClient, json: Json): Retrofit.Builder =
        Retrofit.Builder()
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
}
