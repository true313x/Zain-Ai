package com.zainiq.assistant.core.network

/**
 * Build spec §48 — Production API Boundaries. No real base URL is ever
 * hardcoded here: PRODUCTION intentionally points at a placeholder host so
 * the app cannot accidentally call a real Zain/ZainCash endpoint before
 * official API credentials and specs exist. Swap the constants below once
 * those are available — nothing else in the codebase should need to
 * change, since every caller depends on [NetworkConfig], never on a literal
 * URL.
 */
enum class Environment { DEV, STAGING, PRODUCTION }

data class ApiEndpoints(
    val zainBaseUrl: String,
    val zainCashBaseUrl: String,
    val securityIntelBaseUrl: String
)

object NetworkConfig {

    fun currentEnvironment(environmentField: String): Environment =
        runCatching { Environment.valueOf(environmentField) }.getOrDefault(Environment.DEV)

    fun endpointsFor(environment: Environment): ApiEndpoints = when (environment) {
        Environment.DEV, Environment.STAGING ->
            // Local/mock-server placeholders only — never resolves to a real backend.
            ApiEndpoints(
                zainBaseUrl = "https://mock.local/zain/",
                zainCashBaseUrl = "https://mock.local/zaincash/",
                securityIntelBaseUrl = "https://mock.local/security/"
            )
        Environment.PRODUCTION ->
            // TODO: fill in once official Zain API credentials and
            // hostnames are issued. Until then MockZainRepository and friends
            // (see :data) serve all reads/writes, so production simply has
            // nothing to resolve to yet — never invent a real-looking host here.
            ApiEndpoints(
                zainBaseUrl = "",
                zainCashBaseUrl = "",
                securityIntelBaseUrl = ""
            )
    }
}

/**
 * Certificate pinning is required in production (build spec §42) but pins
 * are endpoint-specific secrets that don't exist yet for an unreleased
 * production host. This keeps the *shape* of the requirement in the
 * codebase — [CertificatePinner] wiring in NetworkModule reads from here —
 * without hardcoding a pin that would immediately be wrong.
 */
data class CertificatePinningConfig(
    val enabled: Boolean,
    val pins: Map<String, List<String>> = emptyMap() // hostname -> sha256/... pins
)
