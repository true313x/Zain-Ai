package com.zainiq.assistant.core.logging.di

import android.content.Context
import android.content.pm.ApplicationInfo
import com.zainiq.assistant.core.logging.AndroidZainLogger
import com.zainiq.assistant.core.logging.ZainLogger
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object LoggingModule {

    @Provides
    @Singleton
    fun provideZainLogger(@ApplicationContext context: Context): ZainLogger {
        val isDebugBuild = (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        return AndroidZainLogger(isDebugBuild)
    }
}
