package com.zainiq.assistant.core.logging

import android.util.Log

/**
 * Build spec §43 — every log call in the app goes through this, never
 * android.util.Log directly, so PII redaction is enforced in one place
 * instead of trusted to every call site. [redact] is intentionally crude in
 * Phase 1 (masking obvious phone-number and long-digit patterns); the real
 * PII Redaction Layer described in the spec — aware of MSISDN formats,
 * card-like digit runs, etc. — lands alongside the Zain Cash agent in
 * Phase 4, where the actual shapes of sensitive fields are known.
 */
interface ZainLogger {
    fun d(tag: String, message: String)
    fun i(tag: String, message: String)
    fun w(tag: String, message: String, throwable: Throwable? = null)
    fun e(tag: String, message: String, throwable: Throwable? = null)
}

class AndroidZainLogger(private val isDebugBuild: Boolean) : ZainLogger {

    override fun d(tag: String, message: String) {
        if (isDebugBuild) Log.d(tag, redact(message))
    }

    override fun i(tag: String, message: String) {
        Log.i(tag, redact(message))
    }

    override fun w(tag: String, message: String, throwable: Throwable?) {
        Log.w(tag, redact(message), throwable)
    }

    override fun e(tag: String, message: String, throwable: Throwable?) {
        // Never pass a raw stack trace to the UI (build spec §50) — this is
        // for logcat/crash-reporting only.
        Log.e(tag, redact(message), throwable)
    }

    private fun redact(message: String): String =
        message
            .replace(Regex("\\b\\d{10,}\\b"), "[REDACTED]") // MSISDN / card-like digit runs
            .replace(Regex("(?i)\\b(pin|otp|password|cvv)\\b\\s*[:=]\\s*\\S+"), "$1=[REDACTED]")
}
