package com.zainiq.assistant.core.security

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import javax.inject.Inject
import javax.inject.Singleton

sealed interface BiometricOutcome {
    data object Success : BiometricOutcome
    data object NoBiometricEnrolled : BiometricOutcome
    data class Failed(val message: String) : BiometricOutcome
    data object Cancelled : BiometricOutcome
}

/**
 * Gate for every HIGH/CRITICAL-risk tool call (build spec §46/§15 — Zain
 * Cash payments, SIM changes, account-security changes). [PolicyEngine] in
 * :domain decides *whether* biometric confirmation is required; this class
 * only knows *how* to ask for it. The LLM never sees or handles the result
 * directly — it only receives the resulting [BiometricOutcome] via the
 * agent/tool flow, same as any other tool output.
 */
@Singleton
class BiometricAuthManager @Inject constructor() {

    fun canAuthenticate(activity: FragmentActivity): Boolean {
        val manager = BiometricManager.from(activity)
        return manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
            BiometricManager.BIOMETRIC_SUCCESS
    }

    fun authenticate(
        activity: FragmentActivity,
        title: String,
        subtitle: String
    ): Flow<BiometricOutcome> = callbackFlow {
        val executor = androidx.core.content.ContextCompat.getMainExecutor(activity)
        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                trySend(BiometricOutcome.Success)
                close()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                val outcome = if (errorCode == BiometricPrompt.ERROR_USER_CANCELED ||
                    errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON
                ) {
                    BiometricOutcome.Cancelled
                } else {
                    BiometricOutcome.Failed(errString.toString())
                }
                trySend(outcome)
                close()
            }

            override fun onAuthenticationFailed() {
                // A single failed attempt (e.g. fingerprint mismatch) — the
                // prompt stays open for another try, so don't close here.
            }
        }

        val prompt = BiometricPrompt(activity, executor, callback)
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButtonText("إلغاء")
            .build()

        if (!canAuthenticate(activity)) {
            trySend(BiometricOutcome.NoBiometricEnrolled)
            close()
        } else {
            prompt.authenticate(promptInfo)
        }

        awaitClose { }
    }
}
