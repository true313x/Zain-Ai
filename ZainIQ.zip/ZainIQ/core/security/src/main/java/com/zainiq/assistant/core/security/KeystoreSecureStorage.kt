package com.zainiq.assistant.core.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.zainiq.assistant.core.common.DispatcherProvider
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.withContext
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.inject.Inject
import javax.inject.Singleton

private const val ANDROID_KEYSTORE = "AndroidKeyStore"
private const val KEY_ALIAS = "zainiq_secure_storage_key"
private const val TRANSFORMATION = "AES/GCM/NoPadding"
private const val GCM_TAG_LENGTH_BITS = 128
private const val PREFS_NAME = "zainiq_secure_prefs"

/**
 * AES-256/GCM encryption with a hardware-backed (where available) Android
 * Keystore key that never leaves the secure element/TEE. Ciphertext + IV are
 * persisted in a plain-named SharedPreferences file — safe, because without
 * the Keystore key the bytes are unreadable even with root/file access.
 *
 * Every operation is `suspend` and dispatched on [DispatcherProvider.io] —
 * Keystore/Cipher calls can block, and this must never run on the main
 * thread from a Compose call site.
 */
@Singleton
class KeystoreSecureStorage @Inject constructor(
    @ApplicationContext private val context: Context,
    private val dispatchers: DispatcherProvider
) : SecureStorage {

    private val prefs by lazy {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    override suspend fun putString(key: String, value: String) = withContext(dispatchers.io) {
        val cipher = Cipher.getInstance(TRANSFORMATION).apply {
            init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
        }
        val ciphertext = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        prefs.edit()
            .putString("$key.iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString("$key.data", Base64.encodeToString(ciphertext, Base64.NO_WRAP))
            .apply()
    }

    override suspend fun getString(key: String): String? = withContext(dispatchers.io) {
        val ivB64 = prefs.getString("$key.iv", null) ?: return@withContext null
        val dataB64 = prefs.getString("$key.data", null) ?: return@withContext null
        val cipher = Cipher.getInstance(TRANSFORMATION).apply {
            init(
                Cipher.DECRYPT_MODE,
                getOrCreateSecretKey(),
                GCMParameterSpec(GCM_TAG_LENGTH_BITS, Base64.decode(ivB64, Base64.NO_WRAP))
            )
        }
        val plaintext = cipher.doFinal(Base64.decode(dataB64, Base64.NO_WRAP))
        String(plaintext, Charsets.UTF_8)
    }

    override suspend fun remove(key: String) = withContext(dispatchers.io) {
        prefs.edit().remove("$key.iv").remove("$key.data").apply()
    }

    override suspend fun clear() = withContext(dispatchers.io) {
        prefs.edit().clear().apply()
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }
}
