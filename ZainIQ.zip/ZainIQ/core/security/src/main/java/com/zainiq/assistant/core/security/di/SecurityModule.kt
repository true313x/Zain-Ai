package com.zainiq.assistant.core.security.di

import com.zainiq.assistant.core.security.KeystoreSecureStorage
import com.zainiq.assistant.core.security.SecureStorage
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class SecurityModule {
    @Binds
    @Singleton
    abstract fun bindSecureStorage(impl: KeystoreSecureStorage): SecureStorage
}
