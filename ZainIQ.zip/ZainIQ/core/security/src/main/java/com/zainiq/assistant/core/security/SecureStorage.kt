package com.zainiq.assistant.core.security

/**
 * Build spec §42 — Security Architecture. Anything sensitive (session
 * tokens, the Room database passphrase, cached-but-sensitive fields) goes
 * through this, never SharedPreferences/files directly. Backed by the
 * Android Keystore (AndroidKeyStore provider, hardware-backed where the
 * device supports it) — see [KeystoreSecureStorage] for the implementation.
 *
 * Deliberately keyed by string rather than typed getters/setters: callers
 * (SecureStorageKeys below) declare their own keys so it's obvious at a
 * glance what's stored, without this module needing to know about every
 * feature that uses it.
 */
interface SecureStorage {
    suspend fun putString(key: String, value: String)
    suspend fun getString(key: String): String?
    suspend fun remove(key: String)
    suspend fun clear()
}

/** Central registry of keys so features don't collide or hand-roll strings. */
object SecureStorageKeys {
    const val SESSION_TOKEN = "session_token"
    const val DATABASE_PASSPHRASE = "database_passphrase"
    const val LAST_AUTHENTICATED_MSISDN = "last_authenticated_msisdn"
}
