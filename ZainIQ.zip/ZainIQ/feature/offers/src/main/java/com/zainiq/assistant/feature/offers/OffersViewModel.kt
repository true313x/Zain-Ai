package com.zainiq.assistant.feature.offers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.domain.agents.AgentContext
import com.zainiq.assistant.domain.entities.Offer
import com.zainiq.assistant.domain.policies.PolicyEngine
import com.zainiq.assistant.domain.repositories.ZainRepository
import com.zainiq.assistant.domain.tools.ToolRegistry
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

sealed interface OffersUiState {
    data object Loading : OffersUiState
    data object Error : OffersUiState
    data class Success(
        val offers: List<Offer> = emptyList(),
        val pendingConfirmation: Offer? = null,
        val confirmationMessage: String? = null,
        val subscribedOfferId: String? = null
    ) : OffersUiState
}

/**
 * build spec §13 — same subscribe flow AI Chat's `OffersAgent` would reach
 * for a confirmed choice, run directly here since the user explicitly
 * opened this screen and picked an offer (no intent classification
 * needed — see AccountViewModel's doc comment for the general reasoning).
 * Crucially, "directly" still means through [PolicyEngine], not around it:
 * `subscribe_package` is MEDIUM risk, so the confirmation step below isn't
 * optional UI polish, it's the same authorization [AgentOrchestrator] would
 * enforce for the exact same tool call coming from chat.
 */
@HiltViewModel
class OffersViewModel @Inject constructor(
    private val zainRepository: ZainRepository,
    private val toolRegistry: ToolRegistry,
    private val policyEngine: PolicyEngine
) : ViewModel() {

    private val demoCustomerId = "demo-customer-1"
    private val agentContext = AgentContext(
        conversationId = UUID.randomUUID().toString(),
        customerId = demoCustomerId,
        isAuthenticated = true,
        locale = "ar"
    )

    private val _uiState = MutableStateFlow<OffersUiState>(OffersUiState.Loading)
    val uiState: StateFlow<OffersUiState> = _uiState.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _uiState.value = OffersUiState.Loading
            when (val result = zainRepository.getOffers()) {
                is AppResult.Success -> _uiState.value = OffersUiState.Success(offers = result.data)
                else -> _uiState.value = OffersUiState.Error
            }
        }
    }

    /** Step 1: user taps an offer — check policy before promising anything. */
    fun selectOffer(offer: Offer) {
        val current = _uiState.value as? OffersUiState.Success ?: return
        val tool = toolRegistry.get("subscribe_package") ?: return
        val decision = policyEngine.evaluate(tool, agentContext)

        _uiState.value = current.copy(
            pendingConfirmation = if (decision.requiresConfirmation) offer else null,
            confirmationMessage = decision.confirmationPrompt
        )
        if (!decision.requiresConfirmation) confirmSubscribe(offer)
    }

    /** Step 2: user taps "confirm" in the dialog. */
    fun confirmSubscribe(offer: Offer = (_uiState.value as OffersUiState.Success).pendingConfirmation!!) {
        val tool = toolRegistry.get("subscribe_package") ?: return
        viewModelScope.launch {
            val outcome = tool.execute(mapOf("customerId" to demoCustomerId, "offerId" to offer.offerId))
            val current = _uiState.value as? OffersUiState.Success ?: return@launch
            _uiState.value = when (outcome) {
                is AppResult.Success -> current.copy(pendingConfirmation = null, subscribedOfferId = offer.offerId)
                else -> current.copy(pendingConfirmation = null)
            }
        }
    }

    fun declineConfirmation() {
        _uiState.update { s -> (s as? OffersUiState.Success)?.copy(pendingConfirmation = null) ?: s }
    }
}
