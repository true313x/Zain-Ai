@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.zainiq.assistant.feature.offers

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zainiq.assistant.core.ui.state.ErrorState
import com.zainiq.assistant.core.ui.state.LoadingState
import com.zainiq.assistant.domain.entities.Offer

@Composable
fun OffersScreen(
    onBack: (() -> Unit)? = null,
    viewModel: OffersViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text("العروض") }) }) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            when (val s = state) {
                OffersUiState.Loading -> LoadingState()
                OffersUiState.Error -> ErrorState(message = "تعذّر تحميل العروض", onRetry = viewModel::load)
                is OffersUiState.Success -> OffersList(s, viewModel)
            }
        }
    }
}

@Composable
private fun OffersList(state: OffersUiState.Success, viewModel: OffersViewModel) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(state.offers, key = { it.offerId }) { offer ->
            OfferCard(
                offer = offer,
                isSubscribed = state.subscribedOfferId == offer.offerId,
                onSubscribe = { viewModel.selectOffer(offer) }
            )
        }
    }

    val pending = state.pendingConfirmation
    if (pending != null) {
        AlertDialog(
            onDismissRequest = viewModel::declineConfirmation,
            title = { Text("تأكيد الاشتراك") },
            text = { Text(state.confirmationMessage ?: "هل تريد الاشتراك بـ${pending.title}؟") },
            confirmButton = {
                TextButton(onClick = { viewModel.confirmSubscribe(pending) }) { Text("تأكيد") }
            },
            dismissButton = { TextButton(onClick = viewModel::declineConfirmation) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun OfferCard(offer: Offer, isSubscribed: Boolean, onSubscribe: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(offer.title, style = MaterialTheme.typography.titleMedium)
            Text(offer.description, style = MaterialTheme.typography.bodyMedium)
            Text(
                "${offer.price.majorUnitsValue.toInt()} ${offer.price.currency.symbol} · ${offer.durationDays} يوم",
                style = MaterialTheme.typography.labelLarge
            )
            if (offer.isDemoData) {
                Text("بيانات تجريبية", style = MaterialTheme.typography.labelSmall)
            }
            Button(onClick = onSubscribe, enabled = !isSubscribed) {
                Text(if (isSubscribed) "تم الاشتراك ✓" else "اشترك")
            }
        }
    }
}
