package com.zainiq.assistant.feature.tickets

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zainiq.assistant.domain.entities.Ticket
import com.zainiq.assistant.domain.repositories.SupportRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class TicketsViewModel @Inject constructor(
    supportRepository: SupportRepository
) : ViewModel() {
    // null = still loading the first emission; empty list = genuinely no tickets.
    val tickets: StateFlow<List<Ticket>?> = supportRepository
        .observeTickets("demo-customer-1") // TODO: real session
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
}
