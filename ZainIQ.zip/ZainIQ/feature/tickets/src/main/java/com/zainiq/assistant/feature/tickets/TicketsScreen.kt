@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.zainiq.assistant.feature.tickets

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zainiq.assistant.core.ui.state.EmptyState
import com.zainiq.assistant.core.ui.state.LoadingState
import com.zainiq.assistant.domain.entities.Ticket
import com.zainiq.assistant.domain.entities.TicketAuthor
import com.zainiq.assistant.domain.entities.TicketStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TicketsScreen(
    onBack: (() -> Unit)? = null,
    viewModel: TicketsViewModel = hiltViewModel()
) {
    val tickets by viewModel.tickets.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text("طلباتي") }) }) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            val list = tickets
            when {
                list == null -> LoadingState()
                list.isEmpty() -> EmptyState(message = "ما عندك طلبات حالياً")
                else -> LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(list, key = { it.ticketId }) { TicketCard(it) }
                }
            }
        }
    }
}

@Composable
private fun TicketCard(ticket: Ticket) {
    var expanded by rememberSaveable(ticket.ticketId) { mutableStateOf(false) }
    Card(onClick = { expanded = !expanded }, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("${ticket.ticketNumber} · ${statusLabel(ticket.status)}", style = MaterialTheme.typography.titleMedium)
            Text(ticket.summary, style = MaterialTheme.typography.bodyMedium)
            if (expanded) {
                ticket.timeline.forEach { event ->
                    Text(
                        "• ${authorLabel(event.author)} (${formatTime(event.atEpochMillis)}): ${event.text}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            } else {
                Text("اضغط لعرض التفاصيل", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

private fun statusLabel(status: TicketStatus) = when (status) {
    TicketStatus.OPEN -> "مفتوحة"
    TicketStatus.IN_PROGRESS -> "قيد المعالجة"
    TicketStatus.WAITING_FOR_CUSTOMER -> "بانتظار ردّك"
    TicketStatus.RESOLVED -> "تم الحل"
    TicketStatus.CLOSED -> "مغلقة"
}

private fun authorLabel(author: TicketAuthor) = when (author) {
    TicketAuthor.CUSTOMER -> "أنت"
    TicketAuthor.AI -> "المساعد"
    TicketAuthor.HUMAN_AGENT -> "الموظف"
    TicketAuthor.SYSTEM -> "النظام"
}

private fun formatTime(epochMillis: Long): String =
    SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(epochMillis))
