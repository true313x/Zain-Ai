package com.zainiq.assistant.feature.internet

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.domain.repositories.InternetDiagnosticsReport
import com.zainiq.assistant.domain.repositories.ZainRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface InternetUiState {
    data object Loading : InternetUiState
    data object Error : InternetUiState
    data class Report(val report: InternetDiagnosticsReport, val isFixing: Boolean = false, val fixed: Boolean = false) : InternetUiState
}

/**
 * build spec §10/§31 — same repository call the `diagnose_internet` Tool
 * makes (see domain.tools.DiagnoseInternetTool), used directly here since
 * this is a dedicated screen the user opened on purpose, not a natural-
 * language request that needs intent classification first (build spec §32
 * applies the same reasoning to Account — see AccountViewModel's doc
 * comment). AI Chat/Voice reach the exact same diagnostics data through the
 * Agent/Tool path instead, for requests phrased in natural language.
 */
@HiltViewModel
class InternetViewModel @Inject constructor(
    private val zainRepository: ZainRepository
) : ViewModel() {

    private val demoCustomerId = "demo-customer-1"

    private val _uiState = MutableStateFlow<InternetUiState>(InternetUiState.Loading)
    val uiState: StateFlow<InternetUiState> = _uiState.asStateFlow()

    init { runDiagnostics() }

    fun runDiagnostics() {
        viewModelScope.launch {
            _uiState.value = InternetUiState.Loading
            when (val result = zainRepository.runInternetDiagnostics(demoCustomerId)) {
                is AppResult.Success -> _uiState.value = InternetUiState.Report(result.data)
                else -> _uiState.value = InternetUiState.Error
            }
        }
    }

    /** build spec §10 step 12 — "Attempt safe remediation". Only the APN
     *  flag is fixable without leaving the app (build spec §11 — Android
     *  doesn't allow programmatically changing every network setting), so
     *  this simulates exactly that one remediation. */
    fun applyFix() {
        val current = _uiState.value as? InternetUiState.Report ?: return
        viewModelScope.launch {
            _uiState.value = current.copy(isFixing = true)
            kotlinx.coroutines.delay(700)
            _uiState.value = current.copy(
                report = current.report.copy(apnConfigured = true, suggestedFix = null),
                isFixing = false,
                fixed = true
            )
        }
    }
}
