@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.zainiq.assistant.feature.internet

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zainiq.assistant.core.ui.state.ErrorState
import com.zainiq.assistant.core.ui.state.LoadingState

@Composable
fun InternetScreen(
    onBack: (() -> Unit)? = null,
    viewModel: InternetViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text("تشخيص الإنترنت") }) }) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp)) {
            when (val s = state) {
                InternetUiState.Loading -> LoadingState(message = "جارِ فحص خطك…")
                InternetUiState.Error -> ErrorState(message = "تعذّر إجراء الفحص", onRetry = viewModel::runDiagnostics)
                is InternetUiState.Report -> DiagnosticsCard(s, onFix = viewModel::applyFix)
            }
        }
    }
}

@Composable
private fun DiagnosticsCard(state: InternetUiState.Report, onFix: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("التشخيص", style = MaterialTheme.typography.titleLarge)

            DiagnosticRow("الشريحة (SIM)", state.report.simActive)
            DiagnosticRow("الباقة", state.report.packageActive)
            DiagnosticRow("البيانات متوفرة", state.report.dataAvailable)
            DiagnosticRow("الشبكة متوفرة", state.report.networkAvailable)
            DiagnosticRow("إعدادات APN", state.report.apnConfigured)

            val suggestedFix = state.report.suggestedFix

            if (state.fixed) {
                Text(
                    "تم الإصلاح. جرّب الاتصال الآن.",
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.bodyLarge
                )
            } else if (suggestedFix != null) {
                Text(suggestedFix, style = MaterialTheme.typography.bodyMedium)
                Button(onClick = onFix, enabled = !state.isFixing) {
                    if (state.isFixing) {
                        CircularProgressIndicator(modifier = Modifier.padding(end = 8.dp))
                    }
                    Text("إصلاح المشكلة")
                }
            }
        }
    }
}

@Composable
private fun DiagnosticRow(label: String, ok: Boolean) {
    Row {
        Text(if (ok) "✓" else "⚠", color = if (ok) Color(0xFF2E7D32) else Color(0xFFE8A317))
        Text(" $label", modifier = Modifier.padding(start = 4.dp))
    }
}
