package com.zainiq.assistant.feature.ai

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.domain.agents.AgentContext
import com.zainiq.assistant.domain.agents.AgentResult
import com.zainiq.assistant.domain.tools.ToolRegistry
import com.zainiq.assistant.domain.usecases.ProcessUserMessageUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

enum class ChatSender { USER, AI, SYSTEM }

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: ChatSender,
    val text: String,
    /** Non-null when this AI message is asking the user to confirm a pending
     *  tool call (build spec §31 — "Confirmation dialogs"). */
    val pendingConfirmation: AgentResult.RequiresConfirmation? = null
)

data class AiChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isThinking: Boolean = false,
    val inputText: String = ""
)

/**
 * build spec §31 — AI Chat Screen. Every reply the user sees came from
 * [ProcessUserMessageUseCase] → real [AgentResult] → mapped to a message
 * here; nothing is a hardcoded canned response. With no concrete `Agent`
 * registered yet (see :data's `DataModule` doc comment), every message
 * currently resolves to an honest "no agent available yet" Escalate —
 * that's expected, not a bug, until Phase 3 adds real agents.
 */
@HiltViewModel
class AiChatViewModel @Inject constructor(
    private val processUserMessage: ProcessUserMessageUseCase,
    private val toolRegistry: ToolRegistry
) : ViewModel() {

    private val _uiState = MutableStateFlow(AiChatUiState())
    val uiState: StateFlow<AiChatUiState> = _uiState.asStateFlow()

    private val conversationId = UUID.randomUUID().toString()

    fun onInputChanged(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun send() {
        val text = _uiState.value.inputText.trim()
        if (text.isEmpty()) return

        _uiState.update {
            it.copy(
                messages = it.messages + ChatMessage(sender = ChatSender.USER, text = text),
                inputText = "",
                isThinking = true
            )
        }

        viewModelScope.launch {
            val context = AgentContext(
                conversationId = conversationId,
                customerId = "demo-customer-1", // TODO(Phase 3+): real session
                isAuthenticated = true,
                locale = "ar"
            )
            val result = processUserMessage(text, context)
            handleResult(result)
        }
    }

    /** Called when the user taps "confirm" on a [ChatMessage.pendingConfirmation]. */
    fun confirm(pending: AgentResult.RequiresConfirmation) {
        // HIGH/CRITICAL risk tools additionally require biometric — the
        // screen is responsible for calling BiometricAuthManager before
        // invoking this when [AgentResult.RequiresConfirmation.requiresBiometric]
        // is true (core:security is a UI-layer concern, not wired into this
        // ViewModel, to keep :domain/:feature:ai free of the biometric
        // Activity dependency).
        viewModelScope.launch {
            _uiState.update { it.copy(isThinking = true) }
            executeTool(pending.pendingTool)
        }
    }

    fun declineConfirmation() {
        _uiState.update {
            it.copy(messages = it.messages + ChatMessage(sender = ChatSender.SYSTEM, text = "تم إلغاء العملية."))
        }
    }

    private suspend fun handleResult(result: AgentResult) {
        when (result) {
            is AgentResult.Reply -> addAiMessage(result.text)

            is AgentResult.Escalate -> addAiMessage(
                "ما عندي معلومات كافية، أقدر أحولك إلى موظف. (${result.reason})"
            )

            is AgentResult.RequiresConfirmation -> _uiState.update {
                it.copy(
                    isThinking = false,
                    messages = it.messages + ChatMessage(
                        sender = ChatSender.AI,
                        text = result.message,
                        pendingConfirmation = result
                    )
                )
            }

            is AgentResult.ToolInvocation -> executeTool(result)
        }
    }

    private suspend fun executeTool(invocation: AgentResult.ToolInvocation) {
        val tool = toolRegistry.get(invocation.toolName)
        if (tool == null) {
            addAiMessage("تعذّر تنفيذ العملية (الأداة غير متوفرة).")
            return
        }
        when (val outcome = tool.execute(invocation.input)) {
            is AppResult.Success -> addAiMessage(formatToolOutput(invocation.toolName, outcome.data))
            is AppResult.Error -> addAiMessage("حدث خطأ: ${outcome.error.message}")
            AppResult.Loading -> Unit
        }
    }

    private fun formatToolOutput(toolName: String, output: Map<String, Any?>): String =
        "تم تنفيذ ($toolName): " + output.entries.joinToString(", ") { "${it.key}=${it.value}" }

    private fun addAiMessage(text: String) {
        _uiState.update {
            it.copy(isThinking = false, messages = it.messages + ChatMessage(sender = ChatSender.AI, text = text))
        }
    }
}
