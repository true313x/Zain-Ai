@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.zainiq.assistant.feature.zaincash

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.hilt.navigation.compose.hiltViewModel
import com.zainiq.assistant.core.security.BiometricAuthManager
import com.zainiq.assistant.core.ui.state.ErrorState
import com.zainiq.assistant.core.ui.state.LoadingState
import com.zainiq.assistant.domain.entities.CardCategory
import com.zainiq.assistant.domain.entities.DigitalCard
import kotlinx.coroutines.flow.firstOrNull

@Composable
fun CardStoreScreen(
    onBack: (() -> Unit)? = null,
    viewModel: CardStoreViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val activity = LocalContext.current as? FragmentActivity
    val biometricAuthManager = remember { BiometricAuthManager() }

    LaunchedEffect(state) {
        val s = state
        if (s is CardStoreUiState.Success && s.awaitingBiometric && activity != null) {
            val outcome = biometricAuthManager
                .authenticate(activity, title = "تأكيد الشراء", subtitle = "استخدم بصمتك للمتابعة")
                .firstOrNull()
            if (outcome != null) viewModel.onBiometricResult(outcome)
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("بطاقات الكترونية") }) }) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            when (val s = state) {
                CardStoreUiState.Loading -> LoadingState()
                CardStoreUiState.Error -> ErrorState(message = "تعذّر تحميل البطاقات", onRetry = { viewModel.load(CardCategory.ALL) })
                is CardStoreUiState.Success -> CardStoreContent(s, viewModel)
            }
        }
    }
}

@Composable
private fun CardStoreContent(state: CardStoreUiState.Success, viewModel: CardStoreViewModel) {
    Column {
        LazyRow(
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(CardCategory.entries) { category ->
                FilterChip(
                    selected = state.category == category,
                    onClick = { viewModel.load(category) },
                    label = { Text(categoryLabel(category)) }
                )
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.cards, key = { it.cardId }) { card ->
                CardTile(
                    card = card,
                    isPurchased = card.cardId in state.purchasedCardIds,
                    onClick = { viewModel.selectCard(card) }
                )
            }
        }
    }

    if (state.confirmationMessage != null && state.pendingCard != null) {
        AlertDialog(
            onDismissRequest = viewModel::onConfirmationDeclined,
            title = { Text("تأكيد الشراء") },
            text = { Text("${state.confirmationMessage}\n${state.pendingCard.providerName} — ${state.pendingCard.price.majorUnitsValue.toInt()} ${state.pendingCard.price.currency.symbol}") },
            confirmButton = { TextButton(onClick = viewModel::onConfirmationAccepted) { Text("تأكيد") } },
            dismissButton = { TextButton(onClick = viewModel::onConfirmationDeclined) { Text("إلغاء") } }
        )
    }

    if (state.resultMessage != null) {
        AlertDialog(
            onDismissRequest = viewModel::dismissResult,
            title = { Text("النتيجة") },
            text = { Text(state.resultMessage) },
            confirmButton = { TextButton(onClick = viewModel::dismissResult) { Text("حسناً") } }
        )
    }
}

@Composable
private fun CardTile(card: DigitalCard, isPurchased: Boolean, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(card.providerName, style = MaterialTheme.typography.titleMedium)
            Text(
                "${card.price.majorUnitsValue.toInt()} ${card.price.currency.symbol}",
                style = MaterialTheme.typography.bodyMedium
            )
            if (isPurchased) Text("تم الشراء ✓", style = MaterialTheme.typography.labelSmall)
        }
    }
}

private fun categoryLabel(category: CardCategory): String = when (category) {
    CardCategory.ALL -> "الجميع"
    CardCategory.INTERNET -> "انترنت"
    CardCategory.TELECOM -> "اتصالات"
    CardCategory.GAMES -> "ألعاب"
    CardCategory.ENTERTAINMENT -> "ترفيه"
}
