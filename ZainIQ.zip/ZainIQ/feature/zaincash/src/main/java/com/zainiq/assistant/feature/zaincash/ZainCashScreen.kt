@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.zainiq.assistant.feature.zaincash

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.hilt.navigation.compose.hiltViewModel
import com.zainiq.assistant.core.security.BiometricAuthManager
import com.zainiq.assistant.core.ui.state.ErrorState
import com.zainiq.assistant.core.ui.state.LoadingState
import com.zainiq.assistant.domain.entities.Transaction
import kotlinx.coroutines.flow.firstOrNull

@Composable
fun ZainCashScreen(
    onBack: (() -> Unit)? = null,
    onNavigateToBillPayment: () -> Unit = {},
    onNavigateToCardStore: () -> Unit = {},
    viewModel: ZainCashViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val activity = LocalContext.current as? FragmentActivity
    // BiometricAuthManager has no dependencies of its own (see its
    // constructor) — no need to route it through Hilt/ViewModel just to
    // get an instance into this Composable.
    val biometricAuthManager = remember { BiometricAuthManager() }

    // Fires the real BiometricPrompt exactly when the ViewModel says the
    // user has accepted the confirmation step — see ZainCashViewModel's
    // doc comment for why this lives here and not in the ViewModel.
    LaunchedEffect(state) {
        val s = state
        if (s is ZainCashUiState.Success && s.awaitingBiometric && activity != null) {
            val outcome = biometricAuthManager
                .authenticate(activity, title = "تأكيد إعادة الشحن", subtitle = "استخدم بصمتك للمتابعة")
                .firstOrNull()
            if (outcome != null) viewModel.onBiometricResult(outcome)
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("زين كاش") }) }) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            when (val s = state) {
                ZainCashUiState.Loading -> LoadingState()
                ZainCashUiState.Error -> ErrorState(message = "تعذّر تحميل بيانات زين كاش", onRetry = viewModel::load)
                is ZainCashUiState.Success -> ZainCashContent(s, viewModel, onNavigateToBillPayment, onNavigateToCardStore)
            }
        }
    }
}

@Composable
private fun ZainCashContent(
    state: ZainCashUiState.Success,
    viewModel: ZainCashViewModel,
    onNavigateToBillPayment: () -> Unit,
    onNavigateToCardStore: () -> Unit
) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("الرصيد", style = MaterialTheme.typography.labelLarge)
                    Text(
                        "${state.wallet.balance.majorUnitsValue.toInt()} ${state.wallet.balance.currency.symbol}",
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Text("حالة البطاقة: ${state.wallet.cardStatus.name}", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = onNavigateToBillPayment, modifier = Modifier.weight(1f)) { Text("دفع الفواتير") }
                Button(onClick = onNavigateToCardStore, modifier = Modifier.weight(1f)) { Text("شراء بطاقات") }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("إعادة شحن الخط", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = state.amountInput,
                        onValueChange = viewModel::onAmountChanged,
                        label = { Text("المبلغ (د.ع)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = viewModel::requestRecharge,
                        enabled = !state.isProcessing && state.amountInput.toLongOrNull()?.let { it > 0 } == true
                    ) {
                        Text(if (state.isProcessing) "جارِ التنفيذ…" else "إعادة شحن")
                    }
                }
            }
        }

        item { Text("آخر العمليات", style = MaterialTheme.typography.titleMedium) }
        items(state.transactions, key = { it.transactionId }) { tx -> TransactionRow(tx) }
    }

    if (state.confirmationMessage != null) {
        AlertDialog(
            onDismissRequest = viewModel::onConfirmationDeclined,
            title = { Text("تأكيد العملية") },
            text = { Text(state.confirmationMessage) },
            confirmButton = { TextButton(onClick = viewModel::onConfirmationAccepted) { Text("تأكيد") } },
            dismissButton = { TextButton(onClick = viewModel::onConfirmationDeclined) { Text("إلغاء") } }
        )
    }

    if (state.resultMessage != null) {
        AlertDialog(
            onDismissRequest = viewModel::dismissResult,
            title = { Text("النتيجة") },
            text = { Text(state.resultMessage) },
            confirmButton = { TextButton(onClick = viewModel::dismissResult) { Text("حسناً") } }
        )
    }
}

@Composable
private fun TransactionRow(tx: Transaction) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(tx.type.name)
        Text("${tx.amount.majorUnitsValue.toInt()} ${tx.amount.currency.symbol} · ${tx.status.name}")
    }
}
