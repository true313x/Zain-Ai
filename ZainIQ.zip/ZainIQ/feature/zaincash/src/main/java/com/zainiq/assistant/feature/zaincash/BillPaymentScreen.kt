package com.zainiq.assistant.feature.zaincash

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.hilt.navigation.compose.hiltViewModel
import com.zainiq.assistant.core.security.BiometricAuthManager
import com.zainiq.assistant.core.ui.state.ErrorState
import com.zainiq.assistant.core.ui.state.LoadingState
import com.zainiq.assistant.domain.entities.Biller
import kotlinx.coroutines.flow.firstOrNull

@Composable
fun BillPaymentScreen(
    onBack: (() -> Unit)? = null,
    viewModel: BillPaymentViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val activity = LocalContext.current as? FragmentActivity
    val biometricAuthManager = remember { BiometricAuthManager() }

    LaunchedEffect(state) {
        val s = state
        if (s is BillPaymentUiState.Success && s.awaitingBiometric && activity != null) {
            val outcome = biometricAuthManager
                .authenticate(activity, title = "تأكيد الدفع", subtitle = "استخدم بصمتك للمتابعة")
                .firstOrNull()
            if (outcome != null) viewModel.onBiometricResult(outcome)
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("دفع الفواتير") }) }) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            when (val s = state) {
                BillPaymentUiState.Loading -> LoadingState()
                BillPaymentUiState.Error -> ErrorState(message = "تعذّر تحميل قائمة الفواتير", onRetry = viewModel::load)
                is BillPaymentUiState.Success -> BillPaymentContent(s, viewModel)
            }
        }
    }
}

@Composable
private fun BillPaymentContent(state: BillPaymentUiState.Success, viewModel: BillPaymentViewModel) {
    if (state.selectedBiller == null) {
        Column {
            Text(
                "ما هي الفاتورة التي تريد دفعها؟",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(16.dp)
            )
            LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.billers, key = { it.billerId }) { biller ->
                    BillerRow(biller) { viewModel.selectBiller(biller) }
                }
            }
        }
    }

    val biller = state.selectedBiller
    if (biller != null) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(biller.name, style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(
                value = state.billNumber,
                onValueChange = viewModel::onBillNumberChanged,
                label = { Text("رقم الفاتورة") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = viewModel::lookupAmount, enabled = state.billNumber.isNotBlank() && !state.isLookingUp) {
                Text(if (state.isLookingUp) "جارِ التحقق…" else "تحقق من المبلغ")
            }

            if (state.billAmount != null) {
                Text(
                    "المبلغ المطلوب: ${state.billAmount.majorUnitsValue.toInt()} ${state.billAmount.currency.symbol}",
                    style = MaterialTheme.typography.headlineSmall
                )
                Button(onClick = viewModel::requestPayment, enabled = !state.isProcessing) {
                    Text(if (state.isProcessing) "جارِ الدفع…" else "دفع")
                }
            }
        }
    }

    if (state.confirmationMessage != null) {
        AlertDialog(
            onDismissRequest = viewModel::onConfirmationDeclined,
            title = { Text("تأكيد الدفع") },
            text = { Text(state.confirmationMessage) },
            confirmButton = { TextButton(onClick = viewModel::onConfirmationAccepted) { Text("تأكيد") } },
            dismissButton = { TextButton(onClick = viewModel::onConfirmationDeclined) { Text("إلغاء") } }
        )
    }

    if (state.resultMessage != null) {
        AlertDialog(
            onDismissRequest = viewModel::dismissResult,
            title = { Text("النتيجة") },
            text = { Text(state.resultMessage) },
            confirmButton = { TextButton(onClick = viewModel::dismissResult) { Text("حسناً") } }
        )
    }
}

@Composable
private fun BillerRow(biller: Biller, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Text(biller.name, modifier = Modifier.padding(16.dp))
    }
}
