package com.zainiq.assistant.feature.zaincash

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.core.model.Money
import com.zainiq.assistant.core.security.BiometricOutcome
import com.zainiq.assistant.domain.agents.AgentContext
import com.zainiq.assistant.domain.entities.Transaction
import com.zainiq.assistant.domain.entities.Wallet
import com.zainiq.assistant.domain.policies.PolicyEngine
import com.zainiq.assistant.domain.repositories.ZainCashRepository
import com.zainiq.assistant.domain.risk.FraudRiskEngine
import com.zainiq.assistant.domain.risk.TransactionRiskInput
import com.zainiq.assistant.domain.tools.RiskLevel
import com.zainiq.assistant.domain.tools.ToolRegistry
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

sealed interface ZainCashUiState {
    data object Loading : ZainCashUiState
    data object Error : ZainCashUiState
    data class Success(
        val wallet: Wallet,
        val transactions: List<Transaction>,
        val amountInput: String = "",
        val confirmationMessage: String? = null,
        val awaitingBiometric: Boolean = false,
        val isProcessing: Boolean = false,
        val resultMessage: String? = null
    ) : ZainCashUiState
}

/**
 * build spec §15 flow, run for real:
 *
 *   User → AI intent → Tool → Risk Engine → Authorization → User confirmation
 *        → Biometric → Transaction → Verification
 *
 * `requestRecharge()` gets the [PolicyEngine] decision (HIGH risk ⇒
 * confirm+biometric) and shows the confirmation text. Once the user taps
 * confirm, the *Composable* — not this ViewModel — drives the actual
 * [androidx.biometric.BiometricPrompt] (it needs a `FragmentActivity`,
 * which has no business being referenced from a ViewModel) and reports
 * back via [onBiometricResult]. Only on biometric success does
 * [FraudRiskEngine] get consulted for the specific transaction before
 * [RechargeTool][com.zainiq.assistant.domain.tools.RechargeTool] actually
 * runs — the same layered check a chat-originated recharge would go
 * through, since both call the identical Tool.
 */
@HiltViewModel
class ZainCashViewModel @Inject constructor(
    private val zainCashRepository: ZainCashRepository,
    private val toolRegistry: ToolRegistry,
    private val policyEngine: PolicyEngine,
    private val fraudRiskEngine: FraudRiskEngine
) : ViewModel() {

    private val demoCustomerId = "demo-customer-1"
    private val demoMsisdn = "07800000000"
    private val agentContext = AgentContext(
        conversationId = UUID.randomUUID().toString(),
        customerId = demoCustomerId,
        isAuthenticated = true,
        locale = "ar"
    )

    private val _uiState = MutableStateFlow<ZainCashUiState>(ZainCashUiState.Loading)
    val uiState: StateFlow<ZainCashUiState> = _uiState.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _uiState.value = ZainCashUiState.Loading
            val walletResult = zainCashRepository.getWallet(demoCustomerId)
            val txResult = zainCashRepository.getTransactions(demoCustomerId)
            if (walletResult is AppResult.Success && txResult is AppResult.Success) {
                _uiState.value = ZainCashUiState.Success(wallet = walletResult.data, transactions = txResult.data)
            } else {
                _uiState.value = ZainCashUiState.Error
            }
        }
    }

    fun onAmountChanged(text: String) {
        val current = _uiState.value as? ZainCashUiState.Success ?: return
        _uiState.value = current.copy(amountInput = text.filter { it.isDigit() })
    }

    /** Step 1: user taps "إعادة شحن". */
    fun requestRecharge() {
        val current = _uiState.value as? ZainCashUiState.Success ?: return
        val tool = toolRegistry.get("recharge") ?: return
        val decision = policyEngine.evaluate(tool, agentContext)

        _uiState.value = current.copy(
            confirmationMessage = decision.confirmationPrompt,
            awaitingBiometric = false
        )
    }

    /** Step 2: user taps "تأكيد" in the dialog — this is what actually
     *  triggers the biometric prompt from the Composable. */
    fun onConfirmationAccepted() {
        val current = _uiState.value as? ZainCashUiState.Success ?: return
        _uiState.value = current.copy(confirmationMessage = null, awaitingBiometric = true)
    }

    fun onConfirmationDeclined() {
        val current = _uiState.value as? ZainCashUiState.Success ?: return
        _uiState.value = current.copy(confirmationMessage = null, awaitingBiometric = false)
    }

    /** Step 3: Composable reports what [androidx.biometric.BiometricPrompt] returned. */
    fun onBiometricResult(outcome: BiometricOutcome) {
        val current = _uiState.value as? ZainCashUiState.Success ?: return
        _uiState.value = current.copy(awaitingBiometric = false)

        when (outcome) {
            BiometricOutcome.Success -> proceedAfterBiometric(current)
            BiometricOutcome.NoBiometricEnrolled -> showResult("لا توجد بصمة مسجّلة على الجهاز — أضِف واحدة من إعدادات النظام أولاً.")
            BiometricOutcome.Cancelled -> Unit // user backed out — no message needed
            is BiometricOutcome.Failed -> showResult("تعذّر التحقق من البصمة: ${outcome.message}")
        }
    }

    private fun proceedAfterBiometric(state: ZainCashUiState.Success) {
        val amount = state.amountInput.toLongOrNull()
        if (amount == null || amount <= 0) {
            showResult("أدخل مبلغاً صحيحاً أولاً")
            return
        }

        viewModelScope.launch {
            _uiState.value = state.copy(isProcessing = true)

            // build spec §27 — FraudRiskEngine gets the final say even after
            // biometric succeeds; a CRITICAL read here still stops the
            // transaction rather than trusting biometric success alone.
            val assessment = fraudRiskEngine.assess(
                TransactionRiskInput(
                    amount = Money.iqd(amount),
                    isNewPayee = false, // recharging the customer's own line
                    isNewDevice = false,
                    recentFailedAttempts = 0,
                    customerAuthenticatedRecently = true
                )
            )

            if (assessment.level == RiskLevel.CRITICAL) {
                _uiState.value = (_uiState.value as ZainCashUiState.Success).copy(
                    isProcessing = false,
                    resultMessage = "تم إيقاف العملية لأسباب أمنية: ${assessment.reasons.joinToString("، ")}"
                )
                return@launch
            }

            val tool = toolRegistry.get("recharge")
            val outcome = tool?.execute(
                mapOf(
                    "customerId" to demoCustomerId,
                    "msisdn" to demoMsisdn,
                    "amountMinorUnits" to amount * 1000
                )
            )

            when (outcome) {
                is AppResult.Success -> {
                    load() // refresh wallet + transactions with the new state
                    showResult("تم الشحن بنجاح ✓")
                }
                is AppResult.Error -> showResult("فشلت العملية: ${outcome.error.message}")
                else -> showResult("تعذّر تنفيذ العملية")
            }
        }
    }

    private fun showResult(message: String) {
        val current = _uiState.value as? ZainCashUiState.Success ?: return
        _uiState.value = current.copy(isProcessing = false, resultMessage = message)
    }

    fun dismissResult() {
        val current = _uiState.value as? ZainCashUiState.Success ?: return
        _uiState.value = current.copy(resultMessage = null)
    }
}
