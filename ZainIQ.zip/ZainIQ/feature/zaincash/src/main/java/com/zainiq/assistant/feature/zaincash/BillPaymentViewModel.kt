package com.zainiq.assistant.feature.zaincash

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.core.model.Money
import com.zainiq.assistant.core.security.BiometricOutcome
import com.zainiq.assistant.domain.agents.AgentContext
import com.zainiq.assistant.domain.entities.Biller
import com.zainiq.assistant.domain.policies.PolicyEngine
import com.zainiq.assistant.domain.repositories.ZainCashRepository
import com.zainiq.assistant.domain.tools.ToolRegistry
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

sealed interface BillPaymentUiState {
    data object Loading : BillPaymentUiState
    data object Error : BillPaymentUiState
    data class Success(
        val billers: List<Biller> = emptyList(),
        val selectedBiller: Biller? = null,
        val billNumber: String = "",
        val billAmount: Money? = null,
        val isLookingUp: Boolean = false,
        val confirmationMessage: String? = null,
        val awaitingBiometric: Boolean = false,
        val isProcessing: Boolean = false,
        val resultMessage: String? = null
    ) : BillPaymentUiState
}

/** build spec §15 "Bill payment" — same PolicyEngine/biometric chain as
 *  ZainCashViewModel's recharge (see that class's doc comment); duplicated
 *  here rather than shared because the two flows collect different input
 *  (biller+bill number vs. a bare amount) before reaching the same
 *  HIGH-risk confirm step. */
@HiltViewModel
class BillPaymentViewModel @Inject constructor(
    private val zainCashRepository: ZainCashRepository,
    private val toolRegistry: ToolRegistry,
    private val policyEngine: PolicyEngine
) : ViewModel() {

    private val demoCustomerId = "demo-customer-1"
    private val agentContext = AgentContext(
        conversationId = UUID.randomUUID().toString(),
        customerId = demoCustomerId,
        isAuthenticated = true,
        locale = "ar"
    )

    private val _uiState = MutableStateFlow<BillPaymentUiState>(BillPaymentUiState.Loading)
    val uiState: StateFlow<BillPaymentUiState> = _uiState.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _uiState.value = BillPaymentUiState.Loading
            when (val result = zainCashRepository.getBillers()) {
                is AppResult.Success -> _uiState.value = BillPaymentUiState.Success(billers = result.data)
                else -> _uiState.value = BillPaymentUiState.Error
            }
        }
    }

    fun selectBiller(biller: Biller) {
        val current = _uiState.value as? BillPaymentUiState.Success ?: return
        _uiState.value = current.copy(selectedBiller = biller, billNumber = "", billAmount = null)
    }

    fun onBillNumberChanged(text: String) {
        val current = _uiState.value as? BillPaymentUiState.Success ?: return
        _uiState.value = current.copy(billNumber = text, billAmount = null)
    }

    fun lookupAmount() {
        val current = _uiState.value as? BillPaymentUiState.Success ?: return
        val biller = current.selectedBiller ?: return
        if (current.billNumber.isBlank()) return

        viewModelScope.launch {
            _uiState.value = current.copy(isLookingUp = true)
            val result = zainCashRepository.getBillAmount(biller.billerId, current.billNumber)
            val latest = _uiState.value as? BillPaymentUiState.Success ?: return@launch
            _uiState.value = when (result) {
                is AppResult.Success -> latest.copy(isLookingUp = false, billAmount = result.data)
                else -> latest.copy(isLookingUp = false, resultMessage = "تعذّر جلب مبلغ الفاتورة")
            }
        }
    }

    fun requestPayment() {
        val current = _uiState.value as? BillPaymentUiState.Success ?: return
        val tool = toolRegistry.get("pay_bill") ?: return
        val decision = policyEngine.evaluate(tool, agentContext)
        _uiState.value = current.copy(confirmationMessage = decision.confirmationPrompt)
    }

    fun onConfirmationAccepted() {
        val current = _uiState.value as? BillPaymentUiState.Success ?: return
        _uiState.value = current.copy(confirmationMessage = null, awaitingBiometric = true)
    }

    fun onConfirmationDeclined() {
        val current = _uiState.value as? BillPaymentUiState.Success ?: return
        _uiState.value = current.copy(confirmationMessage = null, awaitingBiometric = false)
    }

    fun onBiometricResult(outcome: BiometricOutcome) {
        val current = _uiState.value as? BillPaymentUiState.Success ?: return
        _uiState.value = current.copy(awaitingBiometric = false)

        when (outcome) {
            BiometricOutcome.Success -> pay(current)
            BiometricOutcome.NoBiometricEnrolled -> showResult("لا توجد بصمة مسجّلة على الجهاز.")
            BiometricOutcome.Cancelled -> Unit
            is BiometricOutcome.Failed -> showResult("تعذّر التحقق من البصمة: ${outcome.message}")
        }
    }

    private fun pay(state: BillPaymentUiState.Success) {
        val biller = state.selectedBiller ?: return
        val amount = state.billAmount ?: return

        viewModelScope.launch {
            _uiState.value = state.copy(isProcessing = true)
            val tool = toolRegistry.get("pay_bill")
            val outcome = tool?.execute(
                mapOf(
                    "customerId" to demoCustomerId,
                    "billerId" to biller.billerId,
                    "amountMinorUnits" to amount.minorUnits
                )
            )
            when (outcome) {
                is AppResult.Success -> showResult("تم تسديد ${biller.name} بنجاح ✓")
                is AppResult.Error -> showResult("فشلت العملية: ${outcome.error.message}")
                else -> showResult("تعذّر تنفيذ العملية")
            }
        }
    }

    private fun showResult(message: String) {
        val current = _uiState.value as? BillPaymentUiState.Success ?: return
        _uiState.value = current.copy(isProcessing = false, resultMessage = message)
    }

    fun dismissResult() {
        val current = _uiState.value as? BillPaymentUiState.Success ?: return
        _uiState.value = current.copy(
            isProcessing = false,
            resultMessage = null,
            selectedBiller = null,
            billNumber = "",
            billAmount = null
        )
    }
}
