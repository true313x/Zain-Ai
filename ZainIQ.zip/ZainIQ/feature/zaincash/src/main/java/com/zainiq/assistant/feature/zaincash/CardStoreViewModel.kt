package com.zainiq.assistant.feature.zaincash

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.core.security.BiometricOutcome
import com.zainiq.assistant.domain.agents.AgentContext
import com.zainiq.assistant.domain.entities.CardCategory
import com.zainiq.assistant.domain.entities.DigitalCard
import com.zainiq.assistant.domain.policies.PolicyEngine
import com.zainiq.assistant.domain.repositories.ZainCashRepository
import com.zainiq.assistant.domain.tools.ToolRegistry
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

sealed interface CardStoreUiState {
    data object Loading : CardStoreUiState
    data object Error : CardStoreUiState
    data class Success(
        val category: CardCategory = CardCategory.ALL,
        val cards: List<DigitalCard> = emptyList(),
        val pendingCard: DigitalCard? = null,
        val confirmationMessage: String? = null,
        val awaitingBiometric: Boolean = false,
        val isProcessing: Boolean = false,
        val purchasedCardIds: Set<String> = emptySet(),
        val resultMessage: String? = null
    ) : CardStoreUiState
}

/** build spec §15, matching the real app's "بطاقات الكترونية" store —
 *  same PolicyEngine/biometric chain as every other money-moving action in
 *  Zain Cash (see ZainCashViewModel's doc comment). */
@HiltViewModel
class CardStoreViewModel @Inject constructor(
    private val zainCashRepository: ZainCashRepository,
    private val toolRegistry: ToolRegistry,
    private val policyEngine: PolicyEngine
) : ViewModel() {

    private val demoCustomerId = "demo-customer-1"
    private val agentContext = AgentContext(
        conversationId = UUID.randomUUID().toString(),
        customerId = demoCustomerId,
        isAuthenticated = true,
        locale = "ar"
    )

    private val _uiState = MutableStateFlow<CardStoreUiState>(CardStoreUiState.Loading)
    val uiState: StateFlow<CardStoreUiState> = _uiState.asStateFlow()

    init { load(CardCategory.ALL) }

    fun load(category: CardCategory) {
        viewModelScope.launch {
            _uiState.value = CardStoreUiState.Loading
            when (val result = zainCashRepository.getCardCatalog(category)) {
                is AppResult.Success -> _uiState.value = CardStoreUiState.Success(category = category, cards = result.data)
                else -> _uiState.value = CardStoreUiState.Error
            }
        }
    }

    fun selectCard(card: DigitalCard) {
        val current = _uiState.value as? CardStoreUiState.Success ?: return
        val tool = toolRegistry.get("purchase_card") ?: return
        val decision = policyEngine.evaluate(tool, agentContext)
        _uiState.value = current.copy(pendingCard = card, confirmationMessage = decision.confirmationPrompt)
    }

    fun onConfirmationAccepted() {
        val current = _uiState.value as? CardStoreUiState.Success ?: return
        _uiState.value = current.copy(confirmationMessage = null, awaitingBiometric = true)
    }

    fun onConfirmationDeclined() {
        val current = _uiState.value as? CardStoreUiState.Success ?: return
        _uiState.value = current.copy(confirmationMessage = null, awaitingBiometric = false, pendingCard = null)
    }

    fun onBiometricResult(outcome: BiometricOutcome) {
        val current = _uiState.value as? CardStoreUiState.Success ?: return
        _uiState.value = current.copy(awaitingBiometric = false)
        when (outcome) {
            BiometricOutcome.Success -> purchase(current)
            BiometricOutcome.NoBiometricEnrolled -> showResult("لا توجد بصمة مسجّلة على الجهاز.")
            BiometricOutcome.Cancelled -> Unit
            is BiometricOutcome.Failed -> showResult("تعذّر التحقق من البصمة: ${outcome.message}")
        }
    }

    private fun purchase(state: CardStoreUiState.Success) {
        val card = state.pendingCard ?: return
        viewModelScope.launch {
            _uiState.value = state.copy(isProcessing = true)
            val tool = toolRegistry.get("purchase_card")
            val outcome = tool?.execute(mapOf("customerId" to demoCustomerId, "cardId" to card.cardId))
            val latest = _uiState.value as? CardStoreUiState.Success ?: return@launch
            _uiState.value = when (outcome) {
                is AppResult.Success -> latest.copy(
                    isProcessing = false,
                    pendingCard = null,
                    purchasedCardIds = latest.purchasedCardIds + card.cardId,
                    resultMessage = "تم شراء بطاقة ${card.providerName} بنجاح ✓"
                )
                is AppResult.Error -> latest.copy(isProcessing = false, pendingCard = null, resultMessage = "فشلت العملية: ${outcome.error.message}")
                else -> latest.copy(isProcessing = false, pendingCard = null, resultMessage = "تعذّر تنفيذ العملية")
            }
        }
    }

    private fun showResult(message: String) {
        val current = _uiState.value as? CardStoreUiState.Success ?: return
        _uiState.value = current.copy(isProcessing = false, resultMessage = message)
    }

    fun dismissResult() {
        val current = _uiState.value as? CardStoreUiState.Success ?: return
        _uiState.value = current.copy(resultMessage = null)
    }
}
