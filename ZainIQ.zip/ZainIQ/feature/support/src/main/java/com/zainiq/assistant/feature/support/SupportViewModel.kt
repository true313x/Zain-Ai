package com.zainiq.assistant.feature.support

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.domain.entities.EscalationContext
import com.zainiq.assistant.domain.entities.TicketPriority
import com.zainiq.assistant.domain.repositories.SupportRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SupportUiState(
    val category: String = "general",
    val summary: String = "",
    val isSubmitting: Boolean = false,
    val resultMessage: String? = null
)

/** build spec §33/§34 — create a ticket, or hand off to a human with
 *  whatever context the screen actually has (here: just the user's own
 *  description — see EscalationContext's doc comment on why nothing more
 *  is invented). */
@HiltViewModel
class SupportViewModel @Inject constructor(
    private val supportRepository: SupportRepository
) : ViewModel() {

    private val demoCustomerId = "demo-customer-1"

    private val _uiState = MutableStateFlow(SupportUiState())
    val uiState: StateFlow<SupportUiState> = _uiState.asStateFlow()

    fun onCategoryChanged(category: String) = _uiState.update { it.copy(category = category) }
    fun onSummaryChanged(text: String) = _uiState.update { it.copy(summary = text) }
    fun dismissResult() = _uiState.update { it.copy(resultMessage = null) }

    fun createTicket() {
        val state = _uiState.value
        if (state.summary.isBlank() || state.isSubmitting) return
        viewModelScope.launch {
            _uiState.update { it.copy(isSubmitting = true) }
            val result = supportRepository.createTicket(demoCustomerId, state.category, state.summary.trim())
            _uiState.update {
                when (result) {
                    is AppResult.Success -> it.copy(
                        isSubmitting = false, summary = "",
                        resultMessage = "تم فتح التذكرة ${result.data.ticketNumber}"
                    )
                    else -> it.copy(isSubmitting = false, resultMessage = "تعذّر فتح التذكرة، حاول مرة أخرى")
                }
            }
        }
    }

    fun escalateToHuman() {
        val state = _uiState.value
        if (state.isSubmitting) return
        viewModelScope.launch {
            _uiState.update { it.copy(isSubmitting = true) }
            val result = supportRepository.escalateToHuman(
                EscalationContext(
                    customerId = demoCustomerId,
                    issueSummary = state.summary.ifBlank { "طلب تحويل لموظف" },
                    diagnosticsPerformed = emptyList(),
                    actionsAttempted = emptyList(),
                    errorsEncountered = emptyList(),
                    recommendedNextAction = "التواصل مع العميل ومتابعة الطلب",
                    priority = TicketPriority.NORMAL,
                    createdAtEpochMillis = System.currentTimeMillis()
                )
            )
            _uiState.update {
                when (result) {
                    is AppResult.Success -> it.copy(
                        isSubmitting = false, summary = "",
                        resultMessage = "تم تحويلك لموظف — رقم الطلب ${result.data.ticketNumber}"
                    )
                    else -> it.copy(isSubmitting = false, resultMessage = "تعذّر التحويل، حاول مرة أخرى")
                }
            }
        }
    }
}
