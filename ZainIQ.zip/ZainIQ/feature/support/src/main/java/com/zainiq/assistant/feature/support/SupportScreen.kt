package com.zainiq.assistant.feature.support

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

private val categories = listOf(
    "internet" to "الإنترنت", "billing" to "الفواتير والرصيد", "zaincash" to "زين كاش",
    "security" to "الأمان", "general" to "أخرى"
)

@Composable
fun SupportScreen(
    onBack: (() -> Unit)? = null,
    viewModel: SupportViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text("خدمة العملاء") }) }) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("شنو المشكلة؟", style = MaterialTheme.typography.titleMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories, key = { it.first }) { (key, label) ->
                    FilterChip(
                        selected = state.category == key,
                        onClick = { viewModel.onCategoryChanged(key) },
                        label = { Text(label) }
                    )
                }
            }
            OutlinedTextField(
                value = state.summary,
                onValueChange = viewModel::onSummaryChanged,
                label = { Text("اشرح المشكلة") },
                minLines = 4,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = viewModel::createTicket,
                enabled = state.summary.isNotBlank() && !state.isSubmitting,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (state.isSubmitting) "جارِ الإرسال…" else "فتح تذكرة") }
            OutlinedButton(
                onClick = viewModel::escalateToHuman,
                enabled = !state.isSubmitting,
                modifier = Modifier.fillMaxWidth()
            ) { Text("أريد التحدث مع موظف") }
        }
    }

    if (state.resultMessage != null) {
        AlertDialog(
            onDismissRequest = viewModel::dismissResult,
            title = { Text("تم") },
            text = { Text(state.resultMessage!!) },
            confirmButton = { TextButton(onClick = viewModel::dismissResult) { Text("حسناً") } }
        )
    }
}
