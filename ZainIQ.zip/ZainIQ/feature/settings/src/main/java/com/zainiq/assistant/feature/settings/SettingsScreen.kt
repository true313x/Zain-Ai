@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.zainiq.assistant.feature.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zainiq.assistant.core.localization.AppLanguage
import com.zainiq.assistant.core.localization.ThemeMode

/** build spec §39/§40 — language (drives RTL) and theme, both persisted via
 *  DataStore (core:localization) and read back by [com.zainiq.assistant.core.design.ZainIQTheme]
 *  / the composition root, so a change here takes effect app-wide. */
@Composable
fun SettingsScreen(
    onBack: (() -> Unit)? = null,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val language by viewModel.language.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text("الإعدادات") }) }) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp)) {
            Text("اللغة", style = MaterialTheme.typography.titleMedium)
            SettingsOption(
                label = "العربية",
                selected = language == AppLanguage.ARABIC,
                onSelect = { viewModel.setLanguage(AppLanguage.ARABIC) }
            )
            SettingsOption(
                label = "English",
                selected = language == AppLanguage.ENGLISH,
                onSelect = { viewModel.setLanguage(AppLanguage.ENGLISH) }
            )

            Text("المظهر", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 16.dp))
            SettingsOption(
                label = "فاتح",
                selected = themeMode == ThemeMode.LIGHT,
                onSelect = { viewModel.setThemeMode(ThemeMode.LIGHT) }
            )
            SettingsOption(
                label = "داكن",
                selected = themeMode == ThemeMode.DARK,
                onSelect = { viewModel.setThemeMode(ThemeMode.DARK) }
            )
            SettingsOption(
                label = "حسب النظام",
                selected = themeMode == ThemeMode.SYSTEM,
                onSelect = { viewModel.setThemeMode(ThemeMode.SYSTEM) }
            )
        }
    }
}

@Composable
private fun SettingsOption(label: String, selected: Boolean, onSelect: () -> Unit) {
    Column(modifier = Modifier.selectable(selected = selected, onClick = onSelect)) {
        Row {
            RadioButton(selected = selected, onClick = onSelect)
            Text(label, modifier = Modifier.padding(top = 12.dp))
        }
    }
}
