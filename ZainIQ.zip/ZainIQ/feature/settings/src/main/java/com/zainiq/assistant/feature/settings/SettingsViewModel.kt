package com.zainiq.assistant.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zainiq.assistant.core.localization.AppLanguage
import com.zainiq.assistant.core.localization.LocaleManager
import com.zainiq.assistant.core.localization.ThemeManager
import com.zainiq.assistant.core.localization.ThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val localeManager: LocaleManager,
    private val themeManager: ThemeManager
) : ViewModel() {

    val language: StateFlow<AppLanguage> = localeManager.currentLanguage
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppLanguage.ARABIC)

    val themeMode: StateFlow<ThemeMode> = themeManager.themeMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeMode.SYSTEM)

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch { localeManager.setLanguage(language) }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { themeManager.setThemeMode(mode) }
    }
}
