package com.zainiq.assistant.feature.security

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.domain.repositories.DeviceSecurityReport
import com.zainiq.assistant.domain.repositories.SecurityRepository
import com.zainiq.assistant.domain.repositories.SmsAnalysisResult
import com.zainiq.assistant.domain.repositories.UrlScanResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SecurityUiState(
    val deviceReport: DeviceSecurityReport? = null,
    val isDeviceScanLoading: Boolean = true,
    val urlInput: String = "",
    val urlScanResult: UrlScanResult? = null,
    val isUrlScanning: Boolean = false,
    val smsInput: String = "",
    val smsScanResult: SmsAnalysisResult? = null,
    val isSmsScanning: Boolean = false
)

/** build spec §20-§23 — Security Center. All three analyses run through
 *  [SecurityRepository] — see [com.zainiq.assistant.data.local.AndroidSecurityRepository]
 *  for why none of this needs to be mocked. */
@HiltViewModel
class SecurityViewModel @Inject constructor(
    private val securityRepository: SecurityRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SecurityUiState())
    val uiState: StateFlow<SecurityUiState> = _uiState.asStateFlow()

    init { scanDevice() }

    fun scanDevice() {
        viewModelScope.launch {
            _uiState.update { it.copy(isDeviceScanLoading = true) }
            val result = securityRepository.scanDevice()
            _uiState.update {
                it.copy(
                    isDeviceScanLoading = false,
                    deviceReport = (result as? AppResult.Success)?.data
                )
            }
        }
    }

    fun onUrlInputChanged(text: String) {
        _uiState.update { it.copy(urlInput = text, urlScanResult = null) }
    }

    fun scanUrl() {
        val url = _uiState.value.urlInput.trim()
        if (url.isEmpty()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isUrlScanning = true) }
            val result = securityRepository.scanUrl(url)
            _uiState.update {
                it.copy(isUrlScanning = false, urlScanResult = (result as? AppResult.Success)?.data)
            }
        }
    }

    fun onSmsInputChanged(text: String) {
        _uiState.update { it.copy(smsInput = text, smsScanResult = null) }
    }

    fun analyzeSms() {
        val body = _uiState.value.smsInput.trim()
        if (body.isEmpty()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isSmsScanning = true) }
            val result = securityRepository.analyzeSms(sender = null, body = body)
            _uiState.update {
                it.copy(isSmsScanning = false, smsScanResult = (result as? AppResult.Success)?.data)
            }
        }
    }
}
