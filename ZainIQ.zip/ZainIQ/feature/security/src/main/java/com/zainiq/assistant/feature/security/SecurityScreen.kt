@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.zainiq.assistant.feature.security

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zainiq.assistant.domain.repositories.DeviceSecurityReport
import com.zainiq.assistant.domain.repositories.SmsAnalysisResult
import com.zainiq.assistant.domain.repositories.UrlScanResult
import com.zainiq.assistant.domain.tools.RiskLevel

@Composable
fun SecurityScreen(
    onBack: (() -> Unit)? = null,
    viewModel: SecurityViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text("مركز الأمان") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { DeviceScoreCard(state, viewModel) }
            item { UrlScannerCard(state, viewModel) }
            item { SmsScannerCard(state, viewModel) }
        }
    }
}

@Composable
private fun DeviceScoreCard(state: SecurityUiState, viewModel: SecurityViewModel) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("درجة الأمان", style = MaterialTheme.typography.titleLarge)

            if (state.isDeviceScanLoading) {
                CircularProgressIndicator()
            } else {
                val report = state.deviceReport
                if (report == null) {
                    Text("تعذّر إجراء الفحص")
                } else {
                    Text(
                        "${report.score}/100",
                        style = MaterialTheme.typography.headlineLarge,
                        color = riskColor(report.riskLevel)
                    )
                    Text("مستوى الخطورة: ${riskLabel(report.riskLevel)}", style = MaterialTheme.typography.bodyMedium)

                    report.factors.forEach { factor ->
                        Text(
                            "${if (factor.points >= 0) "+" else ""}${factor.points}  ${factor.label}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    if (report.recommendations.isNotEmpty()) {
                        Text("التوصيات", style = MaterialTheme.typography.titleMedium)
                        report.recommendations.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
            Button(onClick = viewModel::scanDevice, enabled = !state.isDeviceScanLoading) { Text("إعادة الفحص") }
        }
    }
}

@Composable
private fun UrlScannerCard(state: SecurityUiState, viewModel: SecurityViewModel) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("فحص رابط", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(
                value = state.urlInput,
                onValueChange = viewModel::onUrlInputChanged,
                label = { Text("الصق الرابط هنا") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = viewModel::scanUrl, enabled = state.urlInput.isNotBlank() && !state.isUrlScanning) {
                Text(if (state.isUrlScanning) "جارِ الفحص…" else "فحص")
            }
            state.urlScanResult?.let { result -> RiskResultSection(result.riskLevel, result.reasons) }
        }
    }
}

@Composable
private fun SmsScannerCard(state: SecurityUiState, viewModel: SecurityViewModel) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("فحص رسالة مشبوهة", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(
                value = state.smsInput,
                onValueChange = viewModel::onSmsInputChanged,
                label = { Text("الصق نص الرسالة هنا") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = viewModel::analyzeSms, enabled = state.smsInput.isNotBlank() && !state.isSmsScanning) {
                Text(if (state.isSmsScanning) "جارِ التحليل…" else "تحليل")
            }
            state.smsScanResult?.let { result ->
                RiskResultSection(result.riskLevel, result.reasons)
                Text(result.recommendation, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun RiskResultSection(riskLevel: RiskLevel, reasons: List<String>) {
    Column {
        Text("النتيجة: ${riskLabel(riskLevel)}", color = riskColor(riskLevel), style = MaterialTheme.typography.titleMedium)
        reasons.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
    }
}

private fun riskLabel(level: RiskLevel): String = when (level) {
    RiskLevel.LOW -> "منخفض"
    RiskLevel.MEDIUM -> "متوسط"
    RiskLevel.HIGH -> "مرتفع"
    RiskLevel.CRITICAL -> "حرج"
}

private fun riskColor(level: RiskLevel): Color = when (level) {
    RiskLevel.LOW -> Color(0xFF2E7D32)
    RiskLevel.MEDIUM -> Color(0xFFE8A317)
    RiskLevel.HIGH -> Color(0xFFE64A19)
    RiskLevel.CRITICAL -> Color(0xFFC62828)
}
