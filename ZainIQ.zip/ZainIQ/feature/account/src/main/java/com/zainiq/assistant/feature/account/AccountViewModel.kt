package com.zainiq.assistant.feature.account

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.core.model.Money
import com.zainiq.assistant.domain.entities.SubscriptionPackage
import com.zainiq.assistant.domain.entities.UsageSnapshot
import com.zainiq.assistant.domain.repositories.ZainRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * build spec §32 — reads go straight through [ZainRepository]; there's no
 * need to route a plain data fetch through the Agent/Tool/PolicyEngine
 * pipeline (that pipeline exists for the *AI* surface — Chat/Voice —
 * deciding what the user meant and confirming risky actions; a dedicated
 * screen the user explicitly opened doesn't need an intent classified).
 */
@HiltViewModel
class AccountViewModel @Inject constructor(
    private val zainRepository: ZainRepository
) : ViewModel() {

    // TODO(Phase 3+): replace with the authenticated customer's real ID once
    // a session/auth design exists — see NetworkModule's auth-interceptor TODO.
    private val demoCustomerId = "demo-customer-1"

    private val _uiState = MutableStateFlow<AccountUiState>(AccountUiState.Loading)
    val uiState: StateFlow<AccountUiState> = _uiState.asStateFlow()

    init {
        load()
    }

    fun retry() = load()

    private fun load() {
        viewModelScope.launch {
            _uiState.value = AccountUiState.Loading

            val balanceResult = zainRepository.getBalance(demoCustomerId)
            val packageResult = zainRepository.getActivePackage(demoCustomerId)
            val usageResult = zainRepository.getUsage(demoCustomerId)

            if (balanceResult is AppResult.Success &&
                packageResult is AppResult.Success &&
                usageResult is AppResult.Success
            ) {
                _uiState.value = AccountUiState.Success(
                    balance = balanceResult.data,
                    activePackage = packageResult.data,
                    usage = usageResult.data
                )
            } else {
                _uiState.value = AccountUiState.Error
            }
        }
    }
}

sealed interface AccountUiState {
    data object Loading : AccountUiState
    data object Error : AccountUiState
    data class Success(
        val balance: Money,
        val activePackage: SubscriptionPackage,
        val usage: UsageSnapshot
    ) : AccountUiState
}
