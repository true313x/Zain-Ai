@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.zainiq.assistant.feature.account

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zainiq.assistant.core.ui.state.ErrorState
import com.zainiq.assistant.core.ui.state.LoadingState
import java.text.NumberFormat
import java.util.Locale

/**
 * build spec §32 — Account. Numbers are shown, not hidden behind masking:
 * balance/usage are the customer's own data on their own device, unlike the
 * MSISDN/PIN-adjacent values [core.logging.ZainLogger] redacts from logs —
 * masking here would just make the screen less useful for its one job.
 */
@Composable
fun AccountScreen(
    onBack: (() -> Unit)? = null,
    viewModel: AccountViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text("حسابي") }) }) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            when (val s = state) {
                is AccountUiState.Loading -> LoadingState()
                is AccountUiState.Error -> ErrorState(
                    message = "تعذّر تحميل بيانات الحساب",
                    onRetry = viewModel::retry
                )
                is AccountUiState.Success -> AccountContent(s)
            }
        }
    }
}

@Composable
private fun AccountContent(state: AccountUiState.Success) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        InfoCard(title = "الرصيد", value = "${formatDinars(state.balance.majorUnitsValue)} ${state.balance.currency.symbol}")

        InfoCard(
            title = "الباقة الحالية",
            value = state.activePackage.name,
            subtitle = "تنتهي خلال ${daysUntil(state.activePackage.expiresAtEpochMillis)} يوم"
        )

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الاستهلاك", style = MaterialTheme.typography.titleMedium)

                val dataUsedRatio = (state.usage.dataUsedMb.toFloat() / state.activePackage.dataAllowanceMb.toFloat())
                    .coerceIn(0f, 1f)
                Text("الإنترنت: ${state.usage.dataUsedMb} من ${state.activePackage.dataAllowanceMb} ميجابايت")
                LinearProgressIndicator(progress = { dataUsedRatio }, modifier = Modifier.fillMaxWidth())

                Text("الدقائق: ${state.usage.minutesUsed} من ${state.activePackage.minutesAllowance}")
                Text("الرسائل: ${state.usage.smsUsed} من ${state.activePackage.smsAllowance}")
            }
        }
    }
}

@Composable
private fun InfoCard(title: String, value: String, subtitle: String? = null) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(value, style = MaterialTheme.typography.headlineMedium)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

private fun formatDinars(value: Double): String =
    NumberFormat.getNumberInstance(Locale("ar", "IQ")).format(value)

private fun daysUntil(epochMillis: Long): Long =
    ((epochMillis - System.currentTimeMillis()) / (24 * 60 * 60 * 1000)).coerceAtLeast(0)
