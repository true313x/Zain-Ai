package com.zainiq.assistant.feature.packages

import androidx.compose.runtime.Composable
import com.zainiq.assistant.core.ui.components.PlaceholderScreen

/**
 * Real implementation lands in Phase 3 of the build spec's phase plan.
 * Kept as a real, navigable Composable now (not a TODO comment) so the
 * navigation graph in :app is fully wired end-to-end from Phase 1 —
 * swapping this call for the real screen later requires no graph change.
 */
@Composable
fun PackagesScreen(onBack: (() -> Unit)? = null) {
    PlaceholderScreen(title = "باقاتي", onBack = onBack)
}
