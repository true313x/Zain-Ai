package com.zainiq.assistant.feature.notifications

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zainiq.assistant.domain.entities.AppNotification
import com.zainiq.assistant.domain.repositories.NotificationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NotificationsViewModel @Inject constructor(
    private val notificationRepository: NotificationRepository
) : ViewModel() {

    private val demoCustomerId = "demo-customer-1" // TODO: real session

    val notifications: StateFlow<List<AppNotification>?> = notificationRepository
        .observeNotifications(demoCustomerId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun markRead(id: String) {
        viewModelScope.launch { notificationRepository.markRead(id) }
    }

    fun markAllRead() {
        viewModelScope.launch { notificationRepository.markAllRead(demoCustomerId) }
    }
}
