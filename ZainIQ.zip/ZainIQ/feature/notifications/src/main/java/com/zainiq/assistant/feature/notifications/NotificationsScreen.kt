@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.zainiq.assistant.feature.notifications

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zainiq.assistant.core.ui.state.EmptyState
import com.zainiq.assistant.core.ui.state.LoadingState
import com.zainiq.assistant.domain.entities.AppNotification

@Composable
fun NotificationsScreen(
    onBack: (() -> Unit)? = null,
    viewModel: NotificationsViewModel = hiltViewModel()
) {
    val items by viewModel.notifications.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الإشعارات") },
                actions = { TextButton(onClick = viewModel::markAllRead) { Text("تحديد الكل كمقروء") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            val list = items
            when {
                list == null -> LoadingState()
                list.isEmpty() -> EmptyState(message = "لا توجد إشعارات")
                else -> LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(list, key = { it.notificationId }) { n ->
                        NotificationCard(n, onClick = { viewModel.markRead(n.notificationId) })
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationCard(n: AppNotification, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (n.isRead) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(n.title, style = MaterialTheme.typography.titleMedium)
            Text(n.body, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
