package com.zainiq.assistant.feature.voice

import android.Manifest
import android.content.pm.PackageManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import java.util.Locale

/**
 * build spec §28 — 🎙️ احچي ويا زين. Real STT via [SpeechRecognizer] and
 * real TTS via [TextToSpeech] — both are lifecycle-bound Android objects
 * created/destroyed with this Composable via [DisposableEffect], never
 * held by [VoiceViewModel] (which stays a plain, unit-testable state
 * machine — see its doc comment).
 */
@Composable
fun VoiceScreen(
    onBack: (() -> Unit)? = null,
    viewModel: VoiceViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsState()
    val currentState = rememberUpdatedState(state)

    var hasRecordAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasRecordAudioPermission = granted }

    val speechRecognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else {
            null
        }
    }
    val textToSpeech = remember { arrayOfNulls<TextToSpeech>(1) }

    DisposableEffect(Unit) {
        textToSpeech[0] = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech[0]?.language = Locale("ar")
            }
        }
        onDispose {
            speechRecognizer?.destroy()
            textToSpeech[0]?.shutdown()
        }
    }

    // Speak the AI's reply once it's ready.
    DisposableEffect(state) {
        val s = state
        if (s is VoiceState.Completed) {
            textToSpeech[0]?.speak(s.spokenReply, TextToSpeech.QUEUE_FLUSH, null, "zainiq-reply")
        }
        onDispose { }
    }

    fun startListening() {
        if (!hasRecordAudioPermission) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        val recognizer = speechRecognizer ?: run {
            viewModel.onRecognitionError("التعرّف على الصوت غير متاح على هذا الجهاز")
            return
        }
        viewModel.onListeningStarted()

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onError(error: Int) {
                // Only report while we're still actually listening — a late
                // callback after the user has already moved on shouldn't
                // stomp a newer state.
                if (currentState.value is VoiceState.Listening) {
                    viewModel.onRecognitionError("تعذّر التعرّف على الصوت، حاول مرة أخرى")
                }
            }
            override fun onResults(results: android.os.Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                viewModel.onTranscriptReady(text)
            }
            override fun onPartialResults(partialResults: android.os.Bundle?) = Unit
            override fun onEvent(eventType: Int, params: android.os.Bundle?) = Unit
        })

        val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer.startListening(intent)
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
    ) {
        Text(text = stateLabel(state), style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)

        if (state is VoiceState.Completed) {
            Text(
                text = (state as VoiceState.Completed).spokenReply,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center
            )
        }
        if (state is VoiceState.Error) {
            Text(
                text = (state as VoiceState.Error).message,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
        }

        FloatingActionButton(onClick = {
            viewModel.reset()
            startListening()
        }) {
            Text("🎙️", style = MaterialTheme.typography.headlineLarge)
        }
    }
}

private fun stateLabel(state: VoiceState): String = when (state) {
    VoiceState.Idle -> "احچي ويا زين"
    VoiceState.Listening -> "أسمعك…"
    VoiceState.Thinking -> "خليني أفكر…"
    VoiceState.Checking -> "جارِ الفحص…"
    VoiceState.Executing -> "جارِ التنفيذ…"
    is VoiceState.Completed -> "تم ✅"
    is VoiceState.Error -> "حدث خطأ"
}
