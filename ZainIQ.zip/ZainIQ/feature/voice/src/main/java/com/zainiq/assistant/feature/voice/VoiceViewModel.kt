package com.zainiq.assistant.feature.voice

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zainiq.assistant.domain.agents.AgentContext
import com.zainiq.assistant.domain.agents.AgentResult
import com.zainiq.assistant.domain.usecases.ProcessUserMessageUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

/** build spec §28 — the exact six states the Voice Assistant must show. */
sealed interface VoiceState {
    data object Idle : VoiceState
    data object Listening : VoiceState
    data object Thinking : VoiceState
    data object Checking : VoiceState
    data object Executing : VoiceState
    data class Completed(val spokenReply: String) : VoiceState
    data class Error(val message: String) : VoiceState
}

/**
 * Owns the state machine only — the actual `SpeechRecognizer` /
 * `TextToSpeech` Android objects are lifecycle-bound platform types that
 * must live in the Composable (via `DisposableEffect`), not here. This
 * ViewModel is what a unit test can exercise without touching either.
 */
@HiltViewModel
class VoiceViewModel @Inject constructor(
    private val processUserMessage: ProcessUserMessageUseCase
) : ViewModel() {

    private val _state = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val state: StateFlow<VoiceState> = _state.asStateFlow()

    private val conversationId = UUID.randomUUID().toString()

    fun onListeningStarted() {
        _state.value = VoiceState.Listening
    }

    fun onRecognitionError(message: String) {
        _state.value = VoiceState.Error(message)
    }

    fun onTranscriptReady(text: String) {
        if (text.isBlank()) {
            _state.value = VoiceState.Error("لم أسمع شيئاً، حاول مرة أخرى")
            return
        }
        _state.value = VoiceState.Thinking

        viewModelScope.launch {
            val context = AgentContext(
                conversationId = conversationId,
                customerId = "demo-customer-1",
                isAuthenticated = true,
                locale = "ar"
            )
            _state.value = VoiceState.Checking
            val result = processUserMessage(text, context)
            _state.value = VoiceState.Executing
            _state.value = VoiceState.Completed(spokenReply = replyTextFor(result))
        }
    }

    fun reset() {
        _state.value = VoiceState.Idle
    }

    private fun replyTextFor(result: AgentResult): String = when (result) {
        is AgentResult.Reply -> result.text
        is AgentResult.Escalate -> "ما عندي معلومات كافية، راح أحولك إلى موظف."
        is AgentResult.RequiresConfirmation -> result.message
        is AgentResult.ToolInvocation -> "تم تنفيذ طلبك."
    }
}
