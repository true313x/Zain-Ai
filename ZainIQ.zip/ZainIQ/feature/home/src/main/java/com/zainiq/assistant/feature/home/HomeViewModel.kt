package com.zainiq.assistant.feature.home

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
// HomeRoutes is declared below in this same file/package — no import needed.

/**
 * Home is deliberately data-light per build spec §30 — a greeting, the
 * voice CTA, and navigation into every other section. Anything showing a
 * live balance/package belongs on the Account screen (§32), built in
 * Phase 2. Route strings here match [com.zainiq.assistant.navigation.Routes]
 * in :app — see that file's doc comment for why the string constants are
 * duplicated across the module boundary rather than shared directly.
 */
@HiltViewModel
class HomeViewModel @Inject constructor() : ViewModel() {

    val services: List<HomeServiceItem> = listOf(
        HomeServiceItem(emoji = "📡", labelKey = HomeLabel.INTERNET, route = HomeRoutes.INTERNET),
        HomeServiceItem(emoji = "💰", labelKey = HomeLabel.BALANCE, route = HomeRoutes.ACCOUNT),
        HomeServiceItem(emoji = "🎁", labelKey = HomeLabel.OFFERS, route = HomeRoutes.OFFERS),
        HomeServiceItem(emoji = "📱", labelKey = HomeLabel.SIM, route = HomeRoutes.SIM),
        HomeServiceItem(emoji = "💳", labelKey = HomeLabel.ZAIN_CASH, route = HomeRoutes.ZAIN_CASH),
        HomeServiceItem(emoji = "🛡️", labelKey = HomeLabel.SECURITY, route = HomeRoutes.SECURITY),
        HomeServiceItem(emoji = "🎫", labelKey = HomeLabel.TICKETS, route = HomeRoutes.TICKETS),
        HomeServiceItem(emoji = "👨‍💼", labelKey = HomeLabel.SUPPORT, route = HomeRoutes.SUPPORT)
    )
}

enum class HomeLabel { INTERNET, BALANCE, OFFERS, SIM, ZAIN_CASH, SECURITY, TICKETS, SUPPORT }

data class HomeServiceItem(
    val emoji: String,
    val labelKey: HomeLabel,
    val route: String
)

/** String route constants — kept here (not just in :app) so this module has
 *  no compile-time dependency on :app, matching every other feature module. */
object HomeRoutes {
    const val INTERNET = "internet"
    const val ACCOUNT = "account"
    const val OFFERS = "offers"
    const val SIM = "sim"
    const val ZAIN_CASH = "zain_cash"
    const val SECURITY = "security"
    const val TICKETS = "tickets"
    const val SUPPORT = "support"
    const val VOICE = "voice"
    const val NOTIFICATIONS = "notifications"
}
