package com.zainiq.assistant.feature.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zainiq.assistant.core.ui.components.ServiceCard

/**
 * build spec §30 — Home Screen / §31 — the mic button leads into the Voice
 * Assistant, real in Phase 2. Service cards route into each feature
 * module's placeholder today and their real screen as each phase lands —
 * no navigation-graph change needed when that happens (see :app's
 * ZainNavGraph.kt).
 */
@Composable
fun HomeScreen(
    onNavigate: (String) -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text(text = stringResource(R.string.home_greeting), style = MaterialTheme.typography.headlineMedium)
            Text(text = stringResource(R.string.home_prompt), style = MaterialTheme.typography.bodyLarge)
        }

        Button(
            onClick = { onNavigate(HomeRoutes.VOICE) },
            modifier = Modifier.padding(horizontal = 24.dp)
        ) {
            Text(text = "🎙️ ${stringResource(R.string.home_mic_cta)}")
        }

        TextButton(
            onClick = { onNavigate(HomeRoutes.NOTIFICATIONS) },
            modifier = Modifier.padding(horizontal = 16.dp)
        ) {
            Text(text = "🔔 ${stringResource(R.string.home_notifications)}")
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(24.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(viewModel.services) { service ->
                ServiceCard(
                    emoji = service.emoji,
                    label = service.label(),
                    onClick = { onNavigate(service.route) }
                )
            }
        }
    }
}

@Composable
private fun HomeServiceItem.label(): String = stringResource(
    when (labelKey) {
        HomeLabel.INTERNET -> R.string.service_internet
        HomeLabel.BALANCE -> R.string.service_balance
        HomeLabel.OFFERS -> R.string.service_offers
        HomeLabel.SIM -> R.string.service_sim
        HomeLabel.ZAIN_CASH -> R.string.service_zaincash
        HomeLabel.SECURITY -> R.string.service_security
        HomeLabel.TICKETS -> R.string.service_tickets
        HomeLabel.SUPPORT -> R.string.service_support
    }
)
