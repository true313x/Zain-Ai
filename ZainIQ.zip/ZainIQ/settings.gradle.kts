pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "ZainIQ"

include(":app")

// core modules
include(":core:common")
include(":core:model")
include(":core:design")
include(":core:ui")
include(":core:network")
include(":core:database")
include(":core:security")
include(":core:logging")
include(":core:analytics")
include(":core:localization")

// domain + data
include(":domain")
include(":data")

// feature modules
include(":feature:home")
include(":feature:ai")
include(":feature:voice")
include(":feature:account")
include(":feature:internet")
include(":feature:packages")
include(":feature:offers")
include(":feature:sim")
include(":feature:zaincash")
include(":feature:security")
include(":feature:support")
include(":feature:tickets")
include(":feature:notifications")
include(":feature:settings")
