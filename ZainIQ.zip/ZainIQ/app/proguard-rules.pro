# Release shrinking rules go here.
