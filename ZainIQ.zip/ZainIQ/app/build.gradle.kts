plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
}

android {
    namespace = "com.zainiq.assistant"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.zainiq.assistant"
        minSdk = 26
        targetSdk = 37
        versionCode = 1
        versionName = "0.1.0-phase1"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables { useSupportLibrary = true }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            buildConfigField("String", "ENVIRONMENT", "\"PRODUCTION\"")
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
            buildConfigField("String", "ENVIRONMENT", "\"DEV\"")
        }
        create("staging") {
            initWith(getByName("debug"))
            applicationIdSuffix = ".staging"
            matchingFallbacks += listOf("debug")
            buildConfigField("String", "ENVIRONMENT", "\"STAGING\"")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    }
}

dependencies {
    // core
    implementation(project(":core:common"))
    implementation(project(":core:model"))
    implementation(project(":core:design"))
    implementation(project(":core:ui"))
    implementation(project(":core:network"))
    implementation(project(":core:database"))
    implementation(project(":core:security"))
    implementation(project(":core:logging"))
    implementation(project(":core:analytics"))
    implementation(project(":core:localization"))

    // domain + data (app wires DI; screens themselves depend only on domain)
    implementation(project(":domain"))
    implementation(project(":data"))

    // feature modules — app is the navigation/aggregation layer
    implementation(project(":feature:home"))
    implementation(project(":feature:ai"))
    implementation(project(":feature:voice"))
    implementation(project(":feature:account"))
    implementation(project(":feature:internet"))
    implementation(project(":feature:packages"))
    implementation(project(":feature:offers"))
    implementation(project(":feature:sim"))
    implementation(project(":feature:zaincash"))
    implementation(project(":feature:security"))
    implementation(project(":feature:support"))
    implementation(project(":feature:tickets"))
    implementation(project(":feature:notifications"))
    implementation(project(":feature:settings"))

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.navigation.compose)

    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.androidx.hilt.navigation.compose)

    // MainActivity extends FragmentActivity (see its doc comment) so
    // BiometricPrompt has a host — core:security depends on this too, but
    // only as `implementation`, which doesn't expose it transitively here.
    implementation(libs.androidx.biometric)

    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
    androidTestImplementation(libs.androidx.test.ext.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}
