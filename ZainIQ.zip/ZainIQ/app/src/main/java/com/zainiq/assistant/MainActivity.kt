package com.zainiq.assistant

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import androidx.navigation.compose.rememberNavController
import com.zainiq.assistant.core.design.ZainIQTheme
import com.zainiq.assistant.navigation.ZainNavGraph
import dagger.hilt.android.AndroidEntryPoint

/**
 * Single-activity host. Every screen in the app (Home, AI Chat, Voice,
 * Account, Internet, Offers, Zain Cash, Security, Support…) is a
 * Compose destination reached through [ZainNavGraph] — see that file for the
 * full route map.
 *
 * Extends [FragmentActivity] (not the bare `ComponentActivity` Compose
 * projects default to) because [androidx.biometric.BiometricPrompt] —
 * required for every HIGH/CRITICAL-risk confirmation, starting with Zain
 * Cash's recharge flow — needs one to host its dialog. `setContent {}` and
 * everything else Compose still works identically; `FragmentActivity` is a
 * `ComponentActivity` subclass.
 */
@AndroidEntryPoint
class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ZainIQApp()
        }
    }
}

@Composable
private fun ZainIQApp() {
    ZainIQTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            val navController = rememberNavController()
            ZainNavGraph(navController = navController)
        }
    }
}
