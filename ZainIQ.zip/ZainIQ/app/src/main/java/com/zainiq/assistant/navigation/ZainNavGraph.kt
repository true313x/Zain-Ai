package com.zainiq.assistant.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.zainiq.assistant.feature.account.AccountScreen
import com.zainiq.assistant.feature.ai.AiChatScreen
import com.zainiq.assistant.feature.home.HomeScreen
import com.zainiq.assistant.feature.internet.InternetScreen
import com.zainiq.assistant.feature.notifications.NotificationsScreen
import com.zainiq.assistant.feature.offers.OffersScreen
import com.zainiq.assistant.feature.packages.PackagesScreen
import com.zainiq.assistant.feature.security.SecurityScreen
import com.zainiq.assistant.feature.settings.SettingsScreen
import com.zainiq.assistant.feature.sim.SimScreen
import com.zainiq.assistant.feature.support.SupportScreen
import com.zainiq.assistant.feature.tickets.TicketsScreen
import com.zainiq.assistant.feature.voice.VoiceScreen
import com.zainiq.assistant.feature.zaincash.BillPaymentScreen
import com.zainiq.assistant.feature.zaincash.CardStoreScreen
import com.zainiq.assistant.feature.zaincash.ZainCashScreen

/**
 * build spec §61 — this is the wiring that turns 15 independent feature
 * modules into one app. Every destination exists and is reachable from
 * Home today; only the *content* of most of them is a placeholder until
 * their phase lands (see each feature's own doc comment for which phase).
 */
@Composable
fun ZainNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.HOME) {

        composable(Routes.HOME) {
            HomeScreen(onNavigate = { route -> navController.navigate(route) })
        }

        composable(Routes.AI_CHAT) { AiChatScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.VOICE) { VoiceScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.ACCOUNT) { AccountScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.INTERNET) { InternetScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.PACKAGES) { PackagesScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.OFFERS) { OffersScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.SIM) { SimScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.ZAIN_CASH) {
            ZainCashScreen(
                onBack = { navController.popBackStack() },
                onNavigateToBillPayment = { navController.navigate(Routes.BILL_PAYMENT) },
                onNavigateToCardStore = { navController.navigate(Routes.CARD_STORE) }
            )
        }
        composable(Routes.BILL_PAYMENT) { BillPaymentScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.CARD_STORE) { CardStoreScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.SECURITY) { SecurityScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.SUPPORT) { SupportScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.TICKETS) { TicketsScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.NOTIFICATIONS) { NotificationsScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.SETTINGS) { SettingsScreen(onBack = { navController.popBackStack() }) }
    }
}
