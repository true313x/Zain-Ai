package com.zainiq.assistant.navigation

/**
 * Every destination in the app. Feature modules don't depend on :app, so
 * each one keeps its own small route-string object (e.g.
 * feature.home.HomeRoutes) for the routes *it* navigates to — those values
 * are duplicated here deliberately, not shared via a common module, so that
 * adding a screen never requires touching an unrelated feature's build
 * graph. Keeping the strings identical across both sides is enforced by
 * navigation tests (build spec §54), not by the type system.
 */
object Routes {
    const val HOME = "home"
    const val AI_CHAT = "ai_chat"
    const val VOICE = "voice"
    const val ACCOUNT = "account"
    const val INTERNET = "internet"
    const val PACKAGES = "packages"
    const val OFFERS = "offers"
    const val SIM = "sim"
    const val ZAIN_CASH = "zain_cash"
    const val BILL_PAYMENT = "bill_payment"
    const val CARD_STORE = "card_store"
    const val SECURITY = "security"
    const val SUPPORT = "support"
    const val TICKETS = "tickets"
    const val NOTIFICATIONS = "notifications"
    const val SETTINGS = "settings"
}
