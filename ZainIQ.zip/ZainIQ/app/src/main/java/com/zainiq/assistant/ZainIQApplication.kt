package com.zainiq.assistant

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * ZainIQ AI Agent — application entry point.
 *
 * Kept intentionally thin. Anything that needs to run at process start
 * (on-device model warm-up, WorkManager scheduling for package-expiry /
 * notification checks, etc.) is added here in later phases via Hilt
 * `@Inject`-ed initializers rather than being hand-rolled in [onCreate] —
 * that keeps this class testable and keeps startup work traceable.
 */
@HiltAndroidApp
class ZainIQApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        // Phase 2+: initialize LocalLLMProvider (model load is async/lazy —
        // never block app start on it), register WorkManager workers.
    }
}
