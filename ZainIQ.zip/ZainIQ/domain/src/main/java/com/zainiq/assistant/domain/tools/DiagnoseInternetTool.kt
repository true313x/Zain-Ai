package com.zainiq.assistant.domain.tools

import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.domain.repositories.ZainRepository
import javax.inject.Inject

/**
 * build spec §10/§31/§45 — the exact "Internet Diagnostic" card the spec
 * shows: SIM / Package / Data / Network / APN checks, LOW risk (a read-only
 * diagnostic — build spec §46), no confirmation needed. The *fix* action
 * ("[Fix]" in the spec's mockup) is intentionally a separate, not-yet-built
 * tool — running a diagnostic and changing device/account state are
 * different risk levels and shouldn't share one Tool.
 */
class DiagnoseInternetTool @Inject constructor(
    private val zainRepository: ZainRepository
) : Tool {

    override val name: String = "diagnose_internet"
    override val description: String =
        "Checks SIM/package/data/network/APN status for the customer and returns a diagnostics report."
    override val riskLevel: RiskLevel = RiskLevel.LOW
    override val requiresConfirmation: Boolean = false

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val customerId = input["customerId"] as? String
            ?: return AppResult.Error(
                com.zainiq.assistant.core.common.AppError.ValidationError(
                    message = "customerId is required",
                    field = "customerId"
                )
            )

        return when (val result = zainRepository.runInternetDiagnostics(customerId)) {
            is AppResult.Success -> AppResult.Success(
                mapOf(
                    "simActive" to result.data.simActive,
                    "packageActive" to result.data.packageActive,
                    "dataAvailable" to result.data.dataAvailable,
                    "networkAvailable" to result.data.networkAvailable,
                    "apnConfigured" to result.data.apnConfigured,
                    "suggestedFix" to result.data.suggestedFix
                )
            )
            is AppResult.Error -> result
            AppResult.Loading -> AppResult.Loading
        }
    }
}
