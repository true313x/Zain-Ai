package com.zainiq.assistant.domain.usecases

import com.zainiq.assistant.domain.agents.AgentContext
import com.zainiq.assistant.domain.agents.AgentOrchestrator
import com.zainiq.assistant.domain.agents.AgentResult
import com.zainiq.assistant.domain.ai.LLMProvider
import javax.inject.Inject
import javax.inject.Singleton

/**
 * build spec §6/§28/§31 — both surfaces that turn free-form user input into
 * action (AI Chat's text box and the Voice Assistant's transcript) go
 * through the exact same UNDERSTAND → REASON path, so a phrase produces the
 * same result whether typed or spoken. Neither feature module talks to
 * [LLMProvider] or [AgentOrchestrator] directly — this is the one seam.
 */
@Singleton
class ProcessUserMessageUseCase @Inject constructor(
    private val llmProvider: LLMProvider,
    private val agentOrchestrator: AgentOrchestrator
) {
    suspend operator fun invoke(text: String, context: AgentContext): AgentResult {
        val intent = llmProvider.recognizeIntent(text, context.locale)
        return agentOrchestrator.process(intent, context)
    }
}
