package com.zainiq.assistant.domain.entities

import com.zainiq.assistant.core.model.Money
import com.zainiq.assistant.domain.tools.RiskLevel

enum class TransactionType { RECHARGE, BILL_PAYMENT, TRANSFER, CARD_PURCHASE }
enum class TransactionStatus { PENDING, SUCCESS, FAILED }

data class Transaction(
    val transactionId: String,
    val type: TransactionType,
    val amount: Money,
    val status: TransactionStatus,
    val riskLevel: RiskLevel,
    val createdAtEpochMillis: Long
)

data class Wallet(
    val customerId: String,
    val balance: Money,
    val cardStatus: CardStatus
)

enum class CardStatus { NONE, ACTIVE, BLOCKED, EXPIRED }
