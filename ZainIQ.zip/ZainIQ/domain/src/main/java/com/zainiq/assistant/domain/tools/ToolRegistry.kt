package com.zainiq.assistant.domain.tools

import javax.inject.Inject
import javax.inject.Singleton

/**
 * Populated via Hilt's `Set<Tool>` multibinding — every concrete [Tool]
 * contributes itself with `@Binds @IntoSet` in whichever module owns its
 * dependencies (see :data's `AgentBindingsModule` for the first example,
 * `DiagnoseInternetTool`). An empty set on startup is a legitimate state
 * (no tools registered yet), same as [com.zainiq.assistant.domain.agents.AgentOrchestrator]'s
 * empty `Set<Agent>` — see that class's doc comment.
 */
@Singleton
class ToolRegistry @Inject constructor(
    tools: Set<@JvmSuppressWildcards Tool>
) {
    private val toolsByName: Map<String, Tool> = tools.associateBy { it.name }

    fun get(name: String): Tool? = toolsByName[name]

    fun all(): List<Tool> = toolsByName.values.toList()
}
