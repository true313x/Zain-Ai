package com.zainiq.assistant.domain.agents

/**
 * build spec §52 — the intent set the on-device model is expected to
 * classify user input into. Kept as its own file (rather than folded into
 * Agent.kt) because this enum is also the contract [LocalLLMProvider] and
 * any future benchmark harness (§52 AI Model Performance) test against.
 */
enum class AgentIntentType {
    INTERNET_PROBLEM,
    CHECK_BALANCE,
    CHECK_USAGE,
    CHECK_PACKAGE,
    SUBSCRIBE,
    CANCEL_PACKAGE,
    RECHARGE,
    ZAIN_CASH,
    SECURITY_CHECK,
    PHISHING,
    SMS_SCAM,
    SUPPORT,
    UNKNOWN
}

data class RecognizedIntent(
    val type: AgentIntentType,
    val confidence: Float,
    val rawText: String,
    val locale: String,
    val entities: Map<String, String> = emptyMap()
)
