package com.zainiq.assistant.domain.entities

import com.zainiq.assistant.core.model.Money

data class SubscriptionPackage(
    val packageId: String,
    val name: String,
    val dataAllowanceMb: Long,
    val minutesAllowance: Long,
    val smsAllowance: Long,
    val expiresAtEpochMillis: Long,
    val isActive: Boolean
)

data class UsageSnapshot(
    val dataUsedMb: Long,
    val minutesUsed: Long,
    val smsUsed: Long,
    val recordedAtEpochMillis: Long
) {
    fun dataRemainingMb(of: SubscriptionPackage): Long =
        (of.dataAllowanceMb - dataUsedMb).coerceAtLeast(0)
}

/** build spec §12 — Offers must never be invented; every instance here is
 *  either MockOfferRepository demo data or a real API response, and callers
 *  can always tell which via [isDemoData]. */
data class Offer(
    val offerId: String,
    val title: String,
    val description: String,
    val price: Money,
    val dataAllowanceMb: Long,
    val minutesAllowance: Long,
    val durationDays: Int,
    val isDemoData: Boolean
)
