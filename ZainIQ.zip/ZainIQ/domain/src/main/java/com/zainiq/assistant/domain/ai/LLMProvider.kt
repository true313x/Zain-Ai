package com.zainiq.assistant.domain.ai

import com.zainiq.assistant.domain.agents.RecognizedIntent

/**
 * build spec §6/§7 — nothing above this interface (agents, tools, UI) is
 * allowed to know whether inference happens on-device or not; that's the
 * entire point of the abstraction. [LocalLLMProvider] is the only
 * implementation today (build spec: "NO EXTERNAL LLM REQUIRED FOR BASIC
 * OPERATION"), but a future `RemoteLLMProvider` or a swap to a different
 * on-device runtime plugs in here without touching a single Agent.
 */
interface LLMProvider {
    /** Classifies free-form user text (voice transcript or typed message)
     *  into one of [com.zainiq.assistant.domain.agents.AgentIntentType]. */
    suspend fun recognizeIntent(text: String, locale: String): RecognizedIntent

    /** Generates a natural-language reply given a prompt and short rolling
     *  context — used for AgentResult.Reply content, not for tool decisions. */
    suspend fun generateReply(prompt: String, context: List<String> = emptyList()): String

    /** Whether the current model is loaded and ready for inference. */
    fun isReady(): Boolean
}
