package com.zainiq.assistant.domain.repositories

import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.domain.entities.Customer
import com.zainiq.assistant.domain.entities.Offer
import com.zainiq.assistant.domain.entities.SubscriptionPackage
import com.zainiq.assistant.domain.entities.UsageSnapshot
import kotlinx.coroutines.flow.Flow

/** build spec §9.1/§10/§12/§13 — Telecom, Internet Diagnostic and Offers
 *  agents all read/act through this one contract. */
interface ZainRepository {
    fun observeCustomer(customerId: String): Flow<Customer>
    suspend fun getBalance(customerId: String): AppResult<com.zainiq.assistant.core.model.Money>
    suspend fun getUsage(customerId: String): AppResult<UsageSnapshot>
    suspend fun getActivePackage(customerId: String): AppResult<SubscriptionPackage>
    suspend fun getOffers(): AppResult<List<Offer>>
    suspend fun subscribeToOffer(customerId: String, offerId: String): AppResult<Unit>
    suspend fun cancelPackage(customerId: String, packageId: String): AppResult<Unit>
    suspend fun runInternetDiagnostics(customerId: String): AppResult<InternetDiagnosticsReport>
}

data class InternetDiagnosticsReport(
    val simActive: Boolean,
    val packageActive: Boolean,
    val dataAvailable: Boolean,
    val networkAvailable: Boolean,
    val apnConfigured: Boolean,
    val suggestedFix: String?
)
