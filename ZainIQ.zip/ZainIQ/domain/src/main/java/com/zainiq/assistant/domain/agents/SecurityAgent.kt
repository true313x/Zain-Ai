package com.zainiq.assistant.domain.agents

import javax.inject.Inject

/**
 * build spec §22/§23/§20, §55 Scenarios 4-5 — routes PHISHING/SMS_SCAM/
 * SECURITY_CHECK intents to the matching analysis Tool. Unlike Telecom/
 * Offers/ZainCash, these tools take the URL/SMS text itself as input, and
 * that text is usually sitting right in the same message the user sent
 * ("هذا الرابط آمن؟ https://…", or the pasted SMS body itself) — so unlike
 * SUBSCRIBE/RECHARGE this agent *can* complete the action directly from
 * chat/voice, no dedicated-screen round-trip needed, as long as the text
 * is actually present. When it isn't, it asks for it rather than guessing.
 */
class SecurityAgent @Inject constructor() : Agent {

    override val id: String = "security-agent"
    override val displayName: String = "وكيل الأمان"

    override fun canHandle(intent: RecognizedIntent): Boolean = intent.type in HANDLED_INTENTS

    override suspend fun handle(intent: RecognizedIntent, context: AgentContext): AgentResult {
        return when (intent.type) {
            AgentIntentType.SECURITY_CHECK -> AgentResult.ToolInvocation(toolName = "scan_device", input = emptyMap())

            AgentIntentType.PHISHING -> {
                val url = URL_REGEX.find(intent.rawText)?.value
                if (url != null) {
                    AgentResult.ToolInvocation(toolName = "scan_url", input = mapOf("url" to url))
                } else {
                    AgentResult.Reply("أرسل الرابط نفسه وراح أفحصه إلك.")
                }
            }

            AgentIntentType.SMS_SCAM -> {
                // The keyword that triggered this intent is itself part of
                // rawText — stripping it isn't reliable with a keyword
                // matcher, so this analyzes the full message. A short
                // "وصلتني رسالة مشبوهة" with nothing else still analyzes
                // fine — it just won't find much, and says so honestly.
                AgentResult.ToolInvocation(toolName = "analyze_sms", input = mapOf("body" to intent.rawText))
            }

            else -> AgentResult.Escalate("unsupported_intent", "هذا الطلب خارج نطاق وكيل الأمان.")
        }
    }

    private companion object {
        val HANDLED_INTENTS = setOf(
            AgentIntentType.SECURITY_CHECK,
            AgentIntentType.PHISHING,
            AgentIntentType.SMS_SCAM
        )
        val URL_REGEX = Regex("""https?://\S+""")
    }
}
