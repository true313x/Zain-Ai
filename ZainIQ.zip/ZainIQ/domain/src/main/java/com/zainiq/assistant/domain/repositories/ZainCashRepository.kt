package com.zainiq.assistant.domain.repositories

import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.domain.entities.Biller
import com.zainiq.assistant.domain.entities.CardCategory
import com.zainiq.assistant.domain.entities.DigitalCard
import com.zainiq.assistant.domain.entities.Transaction
import com.zainiq.assistant.domain.entities.Wallet
import com.zainiq.assistant.core.model.Money

/** build spec §15 — Zain Cash. Note what's deliberately absent: no method
 *  here ever takes a PIN/password/OTP/CVV as a parameter — those are
 *  handled entirely by BiometricAuthManager / the OS payment UI, never by
 *  anything the LLM can see or pass through (build spec §44). */
interface ZainCashRepository {
    suspend fun getWallet(customerId: String): AppResult<Wallet>
    suspend fun getTransactions(customerId: String, limit: Int = 20): AppResult<List<Transaction>>
    suspend fun recharge(customerId: String, msisdn: String, amountMinorUnits: Long): AppResult<Transaction>
    suspend fun payBill(customerId: String, billId: String, amountMinorUnits: Long): AppResult<Transaction>

    // --- Store: bills (build spec §15 "Bill payment") ---
    suspend fun getBillers(): AppResult<List<Biller>>
    suspend fun getBillAmount(billerId: String, billNumber: String): AppResult<Money>

    // --- Store: digital cards (build spec §15, matches the real app's
    // "بطاقات الكترونية" section — prepaid codes, not physical goods) ---
    suspend fun getCardCatalog(category: CardCategory = CardCategory.ALL): AppResult<List<DigitalCard>>
    suspend fun purchaseCard(customerId: String, cardId: String): AppResult<Transaction>

    suspend fun transfer(customerId: String, toMsisdn: String, amountMinorUnits: Long): AppResult<Transaction>
    suspend fun reportFraud(customerId: String, transactionId: String, note: String): AppResult<Unit>
}
