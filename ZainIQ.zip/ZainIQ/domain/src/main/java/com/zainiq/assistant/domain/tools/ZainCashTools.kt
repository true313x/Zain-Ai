package com.zainiq.assistant.domain.tools

import com.zainiq.assistant.core.common.AppError
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.core.common.map
import com.zainiq.assistant.domain.repositories.ZainCashRepository
import javax.inject.Inject

/**
 * build spec §15/§46 — reading your own wallet/history is informational
 * (LOW, same reasoning as Telecom's get_balance). Actually moving money is
 * a "financial operation" — the spec's own explicit HIGH example — so
 * [RechargeTool] requires confirmation *and* biometric. None of these ever
 * take a PIN/OTP/CVV parameter — see ZainCashRepository's doc comment for
 * why that's structural, not just a convention followed here.
 */

class GetWalletTool @Inject constructor(
    private val zainCashRepository: ZainCashRepository
) : Tool {
    override val name = "get_wallet"
    override val description = "Returns the customer's Zain Cash balance and card status."
    override val riskLevel = RiskLevel.LOW
    override val requiresConfirmation = false

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val customerId = input["customerId"] as? String
            ?: return AppResult.Error(AppError.ValidationError("customerId is required", field = "customerId"))
        return zainCashRepository.getWallet(customerId).map { wallet ->
            mapOf(
                "balanceMinorUnits" to wallet.balance.minorUnits,
                "currency" to wallet.balance.currency.isoCode,
                "cardStatus" to wallet.cardStatus.name
            )
        }
    }
}

class GetTransactionsTool @Inject constructor(
    private val zainCashRepository: ZainCashRepository
) : Tool {
    override val name = "get_transactions"
    override val description = "Returns the customer's recent Zain Cash transactions."
    override val riskLevel = RiskLevel.LOW
    override val requiresConfirmation = false

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val customerId = input["customerId"] as? String
            ?: return AppResult.Error(AppError.ValidationError("customerId is required", field = "customerId"))
        return zainCashRepository.getTransactions(customerId).map { transactions ->
            mapOf(
                "transactions" to transactions.map { tx ->
                    mapOf(
                        "transactionId" to tx.transactionId,
                        "type" to tx.type.name,
                        "amountMinorUnits" to tx.amount.minorUnits,
                        "status" to tx.status.name
                    )
                }
            )
        }
    }
}

class RechargeTool @Inject constructor(
    private val zainCashRepository: ZainCashRepository
) : Tool {
    override val name = "recharge"
    override val description = "Tops up a line's balance from Zain Cash. Moves real money — confirm + biometric first."
    override val riskLevel = RiskLevel.HIGH
    override val requiresConfirmation = true

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val customerId = input["customerId"] as? String
            ?: return AppResult.Error(AppError.ValidationError("customerId is required", field = "customerId"))
        val msisdn = input["msisdn"] as? String
            ?: return AppResult.Error(AppError.ValidationError("msisdn is required", field = "msisdn"))
        val amountMinorUnits = (input["amountMinorUnits"] as? Number)?.toLong()
            ?: return AppResult.Error(AppError.ValidationError("amountMinorUnits is required", field = "amountMinorUnits"))

        return zainCashRepository.recharge(customerId, msisdn, amountMinorUnits).map { tx ->
            mapOf("transactionId" to tx.transactionId, "status" to tx.status.name)
        }
    }
}
