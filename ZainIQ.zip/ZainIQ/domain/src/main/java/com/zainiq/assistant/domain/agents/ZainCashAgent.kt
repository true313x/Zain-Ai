package com.zainiq.assistant.domain.agents

import javax.inject.Inject

/**
 * build spec §15/§55 Scenario 8 ("زين كاش ما يشتغل" → Diagnose → Transaction
 * status → Support). Same entity-extraction limit as [OffersAgent]: a free-
 * text "أريد أشحن" doesn't reliably carry an amount or target line, so this
 * agent's chat/voice answer is the diagnostic half — show the wallet so the
 * user can see what's actually going on — while the HIGH-risk recharge
 * itself is completed on the dedicated Zain Cash screen, through the exact
 * same `recharge` Tool and [com.zainiq.assistant.domain.policies.PolicyEngine]
 * (confirmation + biometric) a chat-originated call would also have to pass.
 */
class ZainCashAgent @Inject constructor() : Agent {

    override val id: String = "zaincash-agent"
    override val displayName: String = "وكيل زين كاش"

    override fun canHandle(intent: RecognizedIntent): Boolean =
        intent.type == AgentIntentType.ZAIN_CASH || intent.type == AgentIntentType.RECHARGE

    override suspend fun handle(intent: RecognizedIntent, context: AgentContext): AgentResult {
        val customerId = context.customerId
            ?: return AgentResult.Escalate("no_customer_context", "تعذّر تحديد هوية العميل.")

        return AgentResult.ToolInvocation(toolName = "get_wallet", input = mapOf("customerId" to customerId))
    }
}
