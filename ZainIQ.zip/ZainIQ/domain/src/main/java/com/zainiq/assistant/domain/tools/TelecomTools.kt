package com.zainiq.assistant.domain.tools

import com.zainiq.assistant.core.common.AppError
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.core.common.map
import com.zainiq.assistant.domain.repositories.ZainRepository
import javax.inject.Inject

/** build spec §9.1/§45/§46 — all three are read-only, LOW risk, no
 *  confirmation (spec's explicit LOW list: "balance, package, usage"). */

class GetBalanceTool @Inject constructor(
    private val zainRepository: ZainRepository
) : Tool {
    override val name = "get_balance"
    override val description = "Returns the customer's current Zain account balance."
    override val riskLevel = RiskLevel.LOW
    override val requiresConfirmation = false

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val customerId = input.requireCustomerId() ?: return missingCustomerId()
        return zainRepository.getBalance(customerId).map { money ->
            mapOf("minorUnits" to money.minorUnits, "currency" to money.currency.isoCode)
        }
    }
}

class GetUsageTool @Inject constructor(
    private val zainRepository: ZainRepository
) : Tool {
    override val name = "get_usage"
    override val description = "Returns data/minutes/SMS used so far on the active package."
    override val riskLevel = RiskLevel.LOW
    override val requiresConfirmation = false

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val customerId = input.requireCustomerId() ?: return missingCustomerId()
        return zainRepository.getUsage(customerId).map { usage ->
            mapOf(
                "dataUsedMb" to usage.dataUsedMb,
                "minutesUsed" to usage.minutesUsed,
                "smsUsed" to usage.smsUsed
            )
        }
    }
}

class GetPackageTool @Inject constructor(
    private val zainRepository: ZainRepository
) : Tool {
    override val name = "get_package"
    override val description = "Returns the customer's active subscription package."
    override val riskLevel = RiskLevel.LOW
    override val requiresConfirmation = false

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val customerId = input.requireCustomerId() ?: return missingCustomerId()
        return zainRepository.getActivePackage(customerId).map { pkg ->
            mapOf(
                "name" to pkg.name,
                "dataAllowanceMb" to pkg.dataAllowanceMb,
                "minutesAllowance" to pkg.minutesAllowance,
                "expiresAtEpochMillis" to pkg.expiresAtEpochMillis
            )
        }
    }
}

// --- shared helpers for every Tool in this file ---

private fun Map<String, Any?>.requireCustomerId(): String? = this["customerId"] as? String

private fun missingCustomerId(): AppResult<Map<String, Any?>> =
    AppResult.Error(AppError.ValidationError(message = "customerId is required", field = "customerId"))
