package com.zainiq.assistant.domain.entities

enum class TicketStatus { OPEN, IN_PROGRESS, WAITING_FOR_CUSTOMER, RESOLVED, CLOSED }
enum class TicketPriority { LOW, NORMAL, HIGH, URGENT }
enum class TicketAuthor { CUSTOMER, AI, HUMAN_AGENT, SYSTEM }

/** One line in a ticket's timeline — status changes and messages both land
 *  here (build spec §35: "timeline, messages, timestamps"). */
data class TicketEvent(
    val author: TicketAuthor,
    val text: String,
    val atEpochMillis: Long
)

data class Ticket(
    val ticketId: String,
    val ticketNumber: String,
    val category: String,
    val status: TicketStatus,
    val priority: TicketPriority,
    val summary: String,
    val timeline: List<TicketEvent>,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long
)

/** build spec §34 — Human Handoff. What the human agent receives so the
 *  customer never has to repeat themselves. [diagnosticsPerformed] and
 *  [actionsAttempted] are only as complete as what the caller actually
 *  tracked — nothing here invents history that didn't happen. */
data class EscalationContext(
    val customerId: String,
    val issueSummary: String,
    val diagnosticsPerformed: List<String>,
    val actionsAttempted: List<String>,
    val errorsEncountered: List<String>,
    val recommendedNextAction: String,
    val priority: TicketPriority,
    val createdAtEpochMillis: Long
)
