package com.zainiq.assistant.domain.entities

/** build spec §36 — categories the Notification Center supports. */
enum class NotificationCategory { PACKAGE_EXPIRY, RECHARGE, PAYMENT, SECURITY_ALERT, TICKET_UPDATE, SERVICE }

data class AppNotification(
    val notificationId: String,
    val category: NotificationCategory,
    val title: String,
    val body: String,
    val isRead: Boolean,
    val createdAtEpochMillis: Long
)
