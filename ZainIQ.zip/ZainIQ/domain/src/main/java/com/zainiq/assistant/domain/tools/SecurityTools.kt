package com.zainiq.assistant.domain.tools

import com.zainiq.assistant.core.common.AppError
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.core.common.map
import com.zainiq.assistant.domain.repositories.SecurityRepository
import javax.inject.Inject

/** build spec §45 — all five are read-only analysis, LOW risk, no
 *  confirmation: none of them change device or account state. */

class ScanUrlTool @Inject constructor(
    private val securityRepository: SecurityRepository
) : Tool {
    override val name = "scan_url"
    override val description = "Analyzes a URL's structure for phishing indicators."
    override val riskLevel = RiskLevel.LOW
    override val requiresConfirmation = false

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val url = input["url"] as? String
            ?: return AppResult.Error(AppError.ValidationError("url is required", field = "url"))
        return securityRepository.scanUrl(url).map { result ->
            mapOf("riskLevel" to result.riskLevel.name, "reasons" to result.reasons)
        }
    }
}

class AnalyzeSmsTool @Inject constructor(
    private val securityRepository: SecurityRepository
) : Tool {
    override val name = "analyze_sms"
    override val description = "Analyzes SMS text for scam/phishing indicators."
    override val riskLevel = RiskLevel.LOW
    override val requiresConfirmation = false

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val body = input["body"] as? String
            ?: return AppResult.Error(AppError.ValidationError("body is required", field = "body"))
        val sender = input["sender"] as? String
        return securityRepository.analyzeSms(sender, body).map { result ->
            mapOf("riskLevel" to result.riskLevel.name, "reasons" to result.reasons, "recommendation" to result.recommendation)
        }
    }
}

class ScanDeviceTool @Inject constructor(
    private val securityRepository: SecurityRepository
) : Tool {
    override val name = "scan_device"
    override val description = "Runs a full on-device security scan (lock, encryption, patch level, root indicators)."
    override val riskLevel = RiskLevel.LOW
    override val requiresConfirmation = false

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> =
        securityRepository.scanDevice().map { report ->
            mapOf(
                "score" to report.score,
                "riskLevel" to report.riskLevel.name,
                "factors" to report.factors.map { mapOf("label" to it.label, "points" to it.points) },
                "recommendations" to report.recommendations
            )
        }
}

class GetSecurityScoreTool @Inject constructor(
    private val securityRepository: SecurityRepository
) : Tool {
    override val name = "get_security_score"
    override val description = "Returns just the current security score and risk level (subset of scan_device)."
    override val riskLevel = RiskLevel.LOW
    override val requiresConfirmation = false

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> =
        securityRepository.scanDevice().map { report ->
            mapOf("score" to report.score, "riskLevel" to report.riskLevel.name)
        }
}

class AnalyzeAppRiskTool @Inject constructor(
    private val securityRepository: SecurityRepository
) : Tool {
    override val name = "analyze_app_risk"
    override val description = "Analyzes a specific installed app's permissions and install source for risk."
    override val riskLevel = RiskLevel.LOW
    override val requiresConfirmation = false

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val packageName = input["packageName"] as? String
            ?: return AppResult.Error(AppError.ValidationError("packageName is required", field = "packageName"))
        return securityRepository.analyzeAppRisk(packageName).map { result ->
            mapOf("riskLevel" to result.riskLevel.name, "reasons" to result.reasons)
        }
    }
}
