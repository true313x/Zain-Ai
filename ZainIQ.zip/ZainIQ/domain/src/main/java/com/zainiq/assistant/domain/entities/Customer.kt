package com.zainiq.assistant.domain.entities

/** Business-layer representation of a Zain Iraq subscriber — framework-free,
 *  distinct from core:database's CustomerEntity (Room row) by design. */
data class Customer(
    val customerId: String,
    val msisdn: String,
    val displayName: String,
    val accountStatus: AccountStatus,
    val activePackage: SubscriptionPackage?
)

enum class AccountStatus { ACTIVE, SUSPENDED, PENDING_VERIFICATION, CLOSED }
