package com.zainiq.assistant.domain.risk

import com.zainiq.assistant.core.model.Money
import com.zainiq.assistant.domain.tools.RiskLevel
import javax.inject.Inject
import javax.inject.Singleton

/**
 * build spec §27 — deterministic rules only, no fake ML claims. Every rule
 * below is documented so [RiskAssessment.reasons] can always point at the
 * exact factor that fired — the same "no unsupported claims" discipline the
 * spec asks for from the Security Score (§21) and Phishing Detector (§22).
 * An interface for a future learned model is left as [FraudSignalModel]
 * so this can be extended without an API break, but nothing here pretends
 * to be ML today.
 */
data class RiskAssessment(
    val level: RiskLevel,
    val reasons: List<String>,
    val recommendedAction: String,
    val assessedAtEpochMillis: Long
)

data class TransactionRiskInput(
    val amount: Money,
    val isNewPayee: Boolean,
    val isNewDevice: Boolean,
    val recentFailedAttempts: Int,
    val customerAuthenticatedRecently: Boolean
)

/** Seam for a future learned model — unused by [FraudRiskEngine] in Phase 1. */
interface FraudSignalModel {
    suspend fun score(input: TransactionRiskInput): Float
}

@Singleton
class FraudRiskEngine @Inject constructor() {

    fun assess(input: TransactionRiskInput, now: Long = System.currentTimeMillis()): RiskAssessment {
        val reasons = mutableListOf<String>()
        var level = RiskLevel.LOW

        if (input.amount.majorUnitsValue >= HIGH_VALUE_THRESHOLD_DINARS) {
            reasons += "مبلغ العملية مرتفع"
            level = level.escalate(RiskLevel.MEDIUM)
        }
        if (input.isNewPayee) {
            reasons += "الطرف المستفيد جديد"
            level = level.escalate(RiskLevel.MEDIUM)
        }
        if (input.isNewDevice) {
            reasons += "الجهاز غير معروف مسبقاً"
            level = level.escalate(RiskLevel.HIGH)
        }
        if (input.recentFailedAttempts >= FAILED_ATTEMPTS_THRESHOLD) {
            reasons += "عدة محاولات فاشلة مؤخراً"
            level = level.escalate(RiskLevel.CRITICAL)
        }
        if (!input.customerAuthenticatedRecently) {
            reasons += "لم يتم التحقق من هوية المستخدم مؤخراً"
            level = level.escalate(RiskLevel.HIGH)
        }

        if (reasons.isEmpty()) reasons += "لا توجد مؤشرات خطر"

        return RiskAssessment(
            level = level,
            reasons = reasons,
            recommendedAction = level.recommendedAction(),
            assessedAtEpochMillis = now
        )
    }

    private fun RiskLevel.escalate(to: RiskLevel): RiskLevel =
        if (to.ordinal > this.ordinal) to else this

    private fun RiskLevel.recommendedAction(): String = when (this) {
        RiskLevel.LOW -> "المتابعة بشكل طبيعي"
        RiskLevel.MEDIUM -> "طلب تأكيد من المستخدم"
        RiskLevel.HIGH -> "طلب تأكيد عبر البصمة"
        RiskLevel.CRITICAL -> "إيقاف العملية وتحويلها لموظف أمان"
    }

    companion object {
        private const val HIGH_VALUE_THRESHOLD_DINARS = 250_000L
        private const val FAILED_ATTEMPTS_THRESHOLD = 3
    }
}
