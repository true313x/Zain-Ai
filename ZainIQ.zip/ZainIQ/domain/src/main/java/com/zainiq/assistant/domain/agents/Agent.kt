package com.zainiq.assistant.domain.agents

import com.zainiq.assistant.domain.tools.RiskLevel

/**
 * One Agent per capability area (Telecom, Internet, Offers, Zain Cash,
 * Security, Support — build spec §9/§61). An Agent decides *what*
 * needs to happen for a recognized intent — usually "call this Tool with
 * this input" — but never executes a Tool itself and never talks to a real
 * backend directly; that separation is what lets [AgentOrchestrator] apply
 * [com.zainiq.assistant.domain.policies.PolicyEngine] uniformly to every
 * agent's output.
 */
interface Agent {
    val id: String
    val displayName: String
    fun canHandle(intent: RecognizedIntent): Boolean
    suspend fun handle(intent: RecognizedIntent, context: AgentContext): AgentResult
}

data class AgentContext(
    val conversationId: String,
    val customerId: String?,
    val isAuthenticated: Boolean,
    val locale: String
)

sealed interface AgentResult {
    /** Agent wants a Tool invoked; AgentOrchestrator resolves + authorizes it. */
    data class ToolInvocation(val toolName: String, val input: Map<String, Any?>) : AgentResult

    /** Policy requires the user to confirm before [pendingTool] actually runs. */
    data class RequiresConfirmation(
        val message: String,
        val pendingTool: ToolInvocation,
        val requiresBiometric: Boolean = false
    ) : AgentResult

    /** A plain conversational reply — no tool call needed. */
    data class Reply(val text: String) : AgentResult

    /** build spec §34 — Human Handoff, with full context so nothing repeats. */
    data class Escalate(val reason: String, val summary: String) : AgentResult
}

/** Thrown by nothing — documents the risk each Agent's tool calls can carry,
 *  mirrored by build spec §46's LOW/MEDIUM/HIGH tool classification. */
data class AgentCapabilityDescriptor(
    val agentId: String,
    val maxRiskLevel: RiskLevel
)
