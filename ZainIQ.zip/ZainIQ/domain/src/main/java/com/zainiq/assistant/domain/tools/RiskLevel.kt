package com.zainiq.assistant.domain.tools

/** Shared across Tool, PolicyEngine and FraudRiskEngine (build spec §46). */
enum class RiskLevel { LOW, MEDIUM, HIGH, CRITICAL }
