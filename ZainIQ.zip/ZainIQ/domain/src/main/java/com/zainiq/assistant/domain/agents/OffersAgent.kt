package com.zainiq.assistant.domain.agents

import javax.inject.Inject

/**
 * build spec §12/§18 — "أريد باقة نت" → Search → Filter → Compare → Explain
 * → Ask confirmation. Free-text intent recognition can tell *that* the user
 * wants a package, but not reliably *which* offerId without real entity
 * extraction (out of scope for the keyword-table fallback — see
 * LocalLLMProvider's doc comment). So this agent's job for a chat/voice
 * request is the first half — surface real offers — and the actual
 * subscribe+confirm action happens on the dedicated Offers screen, which
 * runs the exact same `subscribe_package` Tool through the same
 * [com.zainiq.assistant.domain.policies.PolicyEngine] (see
 * feature:offers.OffersViewModel), not a different, looser path.
 */
class OffersAgent @Inject constructor() : Agent {

    override val id: String = "offers-agent"
    override val displayName: String = "وكيل العروض"

    override fun canHandle(intent: RecognizedIntent): Boolean =
        intent.type == AgentIntentType.SUBSCRIBE

    override suspend fun handle(intent: RecognizedIntent, context: AgentContext): AgentResult =
        AgentResult.ToolInvocation(toolName = "get_offers", input = emptyMap())
}
