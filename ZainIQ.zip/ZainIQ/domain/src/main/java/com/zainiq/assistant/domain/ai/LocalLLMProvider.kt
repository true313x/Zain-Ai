package com.zainiq.assistant.domain.ai

import com.zainiq.assistant.domain.agents.AgentIntentType
import com.zainiq.assistant.domain.agents.RecognizedIntent
import javax.inject.Inject
import javax.inject.Singleton

/**
 * build spec §7 — target 300M-700M parameters, INT8/INT4 quantized,
 * optimized for Iraqi Arabic / Arabic / English telecom & security intents.
 *
 * The real on-device model (runtime choice deferred to Phase 2/3 — ONNX
 * Runtime Mobile / TFLite / MLC / llama.cpp-style, per "do not assume one
 * model is perfect") is NOT implemented yet: [isReady] honestly returns
 * `false` for that reason and will keep doing so until real inference is
 * wired in — nothing downstream should branch on "is the on-device model
 * loaded" based on whether [recognizeIntent] happens to return a sensible
 * answer.
 *
 * [recognizeIntent] itself, however, is *not* a stub anymore: it runs the
 * exact keyword→intent table from build spec §53's Dataset Interface
 * examples ("النت ما يشتغل" → internet_problem, "شكد باقيلي نت" →
 * check_usage, etc.) as a deterministic, offline, zero-dependency fallback.
 * This is explicitly the kind of "basic intent recognition" §29 (Offline
 * AI) asks for regardless of whether a trained model is ever loaded — it's
 * a legitimate permanent fallback path, not just a placeholder to delete.
 * It will always be inferior to the real trained model on paraphrases,
 * slang, or anything not in the table; confidence is capped accordingly so
 * callers can tell a keyword hit from real model confidence once one exists.
 */
@Singleton
class LocalLLMProvider @Inject constructor() : LLMProvider {

    override fun isReady(): Boolean = false

    override suspend fun recognizeIntent(text: String, locale: String): RecognizedIntent {
        val normalized = text.trim()
        val match = KEYWORD_TABLE.firstOrNull { (keywords, _) ->
            keywords.any { normalized.contains(it) }
        }

        return RecognizedIntent(
            type = match?.second ?: AgentIntentType.UNKNOWN,
            confidence = if (match != null) KEYWORD_MATCH_CONFIDENCE else 0f,
            rawText = text,
            locale = locale
        )
    }

    override suspend fun generateReply(prompt: String, context: List<String>): String {
        return "ما عندي معلومات كافية، أقدر أحولك إلى موظف." // build spec §44 — AI Guardrails
    }

    companion object {
        private const val KEYWORD_MATCH_CONFIDENCE = 0.55f

        // build spec §53 — kept as (keyword-list, intent) pairs, checked in
        // order, first match wins. Order matters: more specific phrases
        // before general ones (e.g. "الغِ" before a bare package mention).
        private val KEYWORD_TABLE: List<Pair<List<String>, AgentIntentType>> = listOf(
            listOf("النت ما يشتغل", "ما يشتغل النت", "الإنترنت بطيء", "النت بطيء", "مافي نت") to AgentIntentType.INTERNET_PROBLEM,
            listOf("شكد باقيلي نت", "باقي نت", "شكد الباقي", "استهلاكي") to AgentIntentType.CHECK_USAGE,
            listOf("رصيدي", "شكد رصيدي", "الرصيد") to AgentIntentType.CHECK_BALANCE,
            listOf("باقتي", "شنو باقتي", "معلومات الباقة") to AgentIntentType.CHECK_PACKAGE,
            listOf("أريد باقة", "اشترك", "باقة نت", "باقة جديدة") to AgentIntentType.SUBSCRIBE,
            listOf("الغِ الباقة", "الغاء الباقة", "كنسل الباقة") to AgentIntentType.CANCEL_PACKAGE,
            listOf("أريد أشحن", "اشحن رصيد", "تعبئة رصيد") to AgentIntentType.RECHARGE,
            listOf("زين كاش") to AgentIntentType.ZAIN_CASH,
            listOf("هذا الرابط آمن", "الرابط آمن", "فحص الرابط") to AgentIntentType.PHISHING,
            listOf("رسالة مشبوهة", "رسالة احتيال", "SMS مشبوه") to AgentIntentType.SMS_SCAM,
            listOf("فحص الجهاز", "أمان الجهاز", "درجة الأمان") to AgentIntentType.SECURITY_CHECK,
            listOf("أريد موظف", "موظف حقيقي", "تحويل لموظف") to AgentIntentType.SUPPORT
        )
    }
}
