package com.zainiq.assistant.domain.tools

import com.zainiq.assistant.core.common.AppResult

/**
 * build spec §45 — Tool Registry. Every capability the AI can invoke
 * (get_balance, diagnose_internet, create_order, scan_url, …) implements
 * this. Tools never talk to the LLM and the LLM never calls a Tool
 * directly — [com.zainiq.assistant.domain.agents.AgentOrchestrator] routes
 * between them via [com.zainiq.assistant.domain.policies.PolicyEngine], so
 * every invocation is authorized and traceable (build spec §62: UNDERSTAND
 * → REASON → CHECK → AUTHORIZE → ACT → VERIFY → EXPLAIN).
 *
 * input/output are untyped maps at this layer deliberately — each concrete
 * tool documents its own schema in [description]; a stricter typed schema
 * per tool is a natural Phase 3+ refinement once real tools exist, but
 * shouldn't block the registry/policy plumbing landing now.
 */
interface Tool {
    val name: String
    val description: String
    val riskLevel: RiskLevel
    val requiresConfirmation: Boolean
    suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>>
}
