package com.zainiq.assistant.domain.entities

/** build spec §15 "Bill payment" — matches the real Zain Cash "دفع
 *  الفواتير" flow: pick a biller, enter that biller's bill number, pay. */
data class Biller(
    val billerId: String,
    val name: String,
    val requiresBillNumber: Boolean = true
)

data class SavedBill(
    val billId: String,
    val billerId: String,
    val billNumber: String,
    val label: String?
)
