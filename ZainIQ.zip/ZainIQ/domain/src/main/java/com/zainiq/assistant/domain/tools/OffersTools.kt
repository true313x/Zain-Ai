package com.zainiq.assistant.domain.tools

import com.zainiq.assistant.core.common.AppError
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.core.common.map
import com.zainiq.assistant.domain.repositories.ZainRepository
import javax.inject.Inject

/** build spec §12/§13/§46 — browsing offers is read-only (LOW); actually
 *  subscribing changes a real subscription and a real bill, so it's MEDIUM
 *  ("subscription changes, service activation" — spec's explicit MEDIUM
 *  list) and [PolicyEngine] will require the user to confirm before this
 *  ever runs. Every offer returned traces back to [ZainRepository.getOffers]
 *  — see MockZainRepository's doc comment: never invented here either. */

class GetOffersTool @Inject constructor(
    private val zainRepository: ZainRepository
) : Tool {
    override val name = "get_offers"
    override val description = "Lists currently available packages/offers."
    override val riskLevel = RiskLevel.LOW
    override val requiresConfirmation = false

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> =
        zainRepository.getOffers().map { offers ->
            mapOf(
                "offers" to offers.map { offer ->
                    mapOf(
                        "offerId" to offer.offerId,
                        "title" to offer.title,
                        "priceMinorUnits" to offer.price.minorUnits,
                        "currency" to offer.price.currency.isoCode,
                        "dataAllowanceMb" to offer.dataAllowanceMb,
                        "durationDays" to offer.durationDays
                    )
                }
            )
        }
}

class SubscribePackageTool @Inject constructor(
    private val zainRepository: ZainRepository
) : Tool {
    override val name = "subscribe_package"
    override val description = "Subscribes the customer to the given offerId. Changes a real subscription — confirm first."
    override val riskLevel = RiskLevel.MEDIUM
    override val requiresConfirmation = true

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val customerId = input["customerId"] as? String
            ?: return AppResult.Error(AppError.ValidationError("customerId is required", field = "customerId"))
        val offerId = input["offerId"] as? String
            ?: return AppResult.Error(AppError.ValidationError("offerId is required", field = "offerId"))

        return zainRepository.subscribeToOffer(customerId, offerId).map {
            mapOf("subscribed" to true, "offerId" to offerId)
        }
    }
}
