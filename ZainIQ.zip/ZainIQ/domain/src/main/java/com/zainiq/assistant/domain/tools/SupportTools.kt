package com.zainiq.assistant.domain.tools

import com.zainiq.assistant.core.common.AppError
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.core.common.map
import com.zainiq.assistant.domain.entities.EscalationContext
import com.zainiq.assistant.domain.entities.TicketPriority
import com.zainiq.assistant.domain.repositories.SupportRepository
import javax.inject.Inject

/** build spec §33-§35, §45 — none of these move money or change account
 *  state: creating a ticket or handing off to a human is LOW risk. */

class CreateTicketTool @Inject constructor(
    private val supportRepository: SupportRepository
) : Tool {
    override val name = "create_ticket"
    override val description = "Opens a support ticket with a category and summary."
    override val riskLevel = RiskLevel.LOW
    override val requiresConfirmation = false

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val customerId = input["customerId"] as? String
            ?: return AppResult.Error(AppError.ValidationError("customerId is required", field = "customerId"))
        val summary = input["summary"] as? String
        if (summary.isNullOrBlank()) {
            return AppResult.Error(AppError.ValidationError("summary is required", field = "summary"))
        }
        val category = input["category"] as? String ?: "general"
        return supportRepository.createTicket(customerId, category, summary).map { ticket ->
            mapOf("ticketId" to ticket.ticketId, "ticketNumber" to ticket.ticketNumber, "status" to ticket.status.name)
        }
    }
}

class GetTicketTool @Inject constructor(
    private val supportRepository: SupportRepository
) : Tool {
    override val name = "get_ticket"
    override val description = "Returns a ticket's status and latest timeline entry."
    override val riskLevel = RiskLevel.LOW
    override val requiresConfirmation = false

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val ticketId = input["ticketId"] as? String
            ?: return AppResult.Error(AppError.ValidationError("ticketId is required", field = "ticketId"))
        return supportRepository.getTicket(ticketId).map { ticket ->
            mapOf(
                "ticketNumber" to ticket.ticketNumber,
                "status" to ticket.status.name,
                "lastUpdate" to ticket.timeline.lastOrNull()?.text
            )
        }
    }
}

class EscalateToHumanTool @Inject constructor(
    private val supportRepository: SupportRepository
) : Tool {
    override val name = "escalate_to_human"
    override val description = "Hands the conversation to a human agent with full context so the customer doesn't repeat themselves."
    override val riskLevel = RiskLevel.LOW
    override val requiresConfirmation = false

    @Suppress("UNCHECKED_CAST")
    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val customerId = input["customerId"] as? String
            ?: return AppResult.Error(AppError.ValidationError("customerId is required", field = "customerId"))
        val summary = (input["issueSummary"] as? String).orEmpty().ifBlank { "طلب تحويل لموظف" }

        val context = EscalationContext(
            customerId = customerId,
            issueSummary = summary,
            diagnosticsPerformed = (input["diagnosticsPerformed"] as? List<String>).orEmpty(),
            actionsAttempted = (input["actionsAttempted"] as? List<String>).orEmpty(),
            errorsEncountered = (input["errorsEncountered"] as? List<String>).orEmpty(),
            recommendedNextAction = (input["recommendedNextAction"] as? String) ?: "التواصل مع العميل ومتابعة الطلب",
            priority = TicketPriority.NORMAL,
            createdAtEpochMillis = System.currentTimeMillis()
        )
        return supportRepository.escalateToHuman(context).map { ticket ->
            mapOf("ticketNumber" to ticket.ticketNumber, "status" to ticket.status.name)
        }
    }
}
