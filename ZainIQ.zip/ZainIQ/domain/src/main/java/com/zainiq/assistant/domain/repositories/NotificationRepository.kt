package com.zainiq.assistant.domain.repositories

import com.zainiq.assistant.domain.entities.AppNotification
import kotlinx.coroutines.flow.Flow

/** build spec §36 — Notification Center. */
interface NotificationRepository {
    fun observeNotifications(customerId: String): Flow<List<AppNotification>>
    suspend fun markRead(notificationId: String)
    suspend fun markAllRead(customerId: String)
}
