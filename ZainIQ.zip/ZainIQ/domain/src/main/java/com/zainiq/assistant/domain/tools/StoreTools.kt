package com.zainiq.assistant.domain.tools

import com.zainiq.assistant.core.common.AppError
import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.core.common.map
import com.zainiq.assistant.domain.repositories.ZainCashRepository
import javax.inject.Inject

/** build spec §15 — paying a bill or buying a prepaid card both move real
 *  money out of the wallet, so both are HIGH risk like recharge/transfer —
 *  same confirmation + biometric gate, no special-casing. */

class PayBillTool @Inject constructor(
    private val zainCashRepository: ZainCashRepository
) : Tool {
    override val name = "pay_bill"
    override val description = "Pays a biller's bill (e.g. electricity) for a given bill number and amount."
    override val riskLevel = RiskLevel.HIGH
    override val requiresConfirmation = true

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val customerId = input["customerId"] as? String
            ?: return AppResult.Error(AppError.ValidationError("customerId is required", field = "customerId"))
        val billerId = input["billerId"] as? String
            ?: return AppResult.Error(AppError.ValidationError("billerId is required", field = "billerId"))
        val amountMinorUnits = (input["amountMinorUnits"] as? Number)?.toLong()
            ?: return AppResult.Error(AppError.ValidationError("amountMinorUnits is required", field = "amountMinorUnits"))

        return zainCashRepository.payBill(customerId, billerId, amountMinorUnits).map { tx ->
            mapOf("transactionId" to tx.transactionId, "status" to tx.status.name)
        }
    }
}

class PurchaseCardTool @Inject constructor(
    private val zainCashRepository: ZainCashRepository
) : Tool {
    override val name = "purchase_card"
    override val description = "Buys a digital/prepaid card (internet, telecom, games, entertainment) from the wallet."
    override val riskLevel = RiskLevel.HIGH
    override val requiresConfirmation = true

    override suspend fun execute(input: Map<String, Any?>): AppResult<Map<String, Any?>> {
        val customerId = input["customerId"] as? String
            ?: return AppResult.Error(AppError.ValidationError("customerId is required", field = "customerId"))
        val cardId = input["cardId"] as? String
            ?: return AppResult.Error(AppError.ValidationError("cardId is required", field = "cardId"))

        return zainCashRepository.purchaseCard(customerId, cardId).map { tx ->
            mapOf("transactionId" to tx.transactionId, "status" to tx.status.name)
        }
    }
}
