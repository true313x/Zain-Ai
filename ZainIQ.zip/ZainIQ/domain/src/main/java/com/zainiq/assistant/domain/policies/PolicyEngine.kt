package com.zainiq.assistant.domain.policies

import com.zainiq.assistant.domain.agents.AgentContext
import com.zainiq.assistant.domain.tools.RiskLevel
import com.zainiq.assistant.domain.tools.Tool
import javax.inject.Inject
import javax.inject.Singleton

/**
 * build spec §8/§9/§46 — the single place that decides whether a tool call
 * is allowed to run, and what has to happen before it does. Neither the LLM
 * nor an Agent can skip this: [com.zainiq.assistant.domain.agents.AgentOrchestrator]
 * always routes a [Tool] invocation through here first.
 *
 *   Intent → Tool Selection → PolicyEngine → Authorization → Tool → API
 *   (sensitive tools additionally require: Risk Assessment → User
 *   Confirmation → Biometric/OTP → Execution → Verification)
 */
data class PolicyDecision(
    val isAuthorized: Boolean,
    val requiresConfirmation: Boolean,
    val requiresBiometric: Boolean = false,
    val confirmationPrompt: String? = null,
    val denialReason: String? = null
)

@Singleton
class PolicyEngine @Inject constructor() {

    fun evaluate(tool: Tool, context: AgentContext): PolicyDecision {
        if (tool.riskLevel != RiskLevel.LOW && !context.isAuthenticated) {
            return PolicyDecision(
                isAuthorized = false,
                requiresConfirmation = false,
                denialReason = "auth_required"
            )
        }

        return when (tool.riskLevel) {
            RiskLevel.LOW -> PolicyDecision(isAuthorized = true, requiresConfirmation = false)

            RiskLevel.MEDIUM -> PolicyDecision(
                isAuthorized = true,
                requiresConfirmation = true,
                confirmationPrompt = "هل تريد المتابعة بهذه العملية؟"
            )

            RiskLevel.HIGH, RiskLevel.CRITICAL -> PolicyDecision(
                isAuthorized = true,
                requiresConfirmation = true,
                requiresBiometric = true,
                confirmationPrompt = "هذه عملية حساسة. أكّد عبر البصمة للمتابعة."
            )
        }
    }
}
