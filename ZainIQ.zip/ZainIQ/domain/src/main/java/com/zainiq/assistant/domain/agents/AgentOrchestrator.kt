package com.zainiq.assistant.domain.agents

import com.zainiq.assistant.domain.policies.PolicyEngine
import com.zainiq.assistant.domain.tools.ToolRegistry
import javax.inject.Inject
import javax.inject.Singleton

/**
 * build spec §6/§61 — the box labeled "AGENT ORCHESTRATOR" sitting between
 * the AI layer and the Tool Registry:
 *
 *   Android → AI Interface → Local AI Engine → Agent Orchestrator
 *           → Tool Registry → Policy Engine → Backend/API layer
 *
 * Agents are registered here (constructor-injected as a `Set<@JvmSuppressWildcards
 * Agent>` via Hilt's multibinding once real agents exist in Phase 3+); an
 * empty list is a legitimate Phase 1 state — [process] then always escalates,
 * which is the correct, honest behavior for "no agent implemented yet" rather
 * than silently doing nothing.
 */
@Singleton
class AgentOrchestrator @Inject constructor(
    private val agents: Set<@JvmSuppressWildcards Agent>,
    private val toolRegistry: ToolRegistry,
    private val policyEngine: PolicyEngine
) {

    suspend fun process(intent: RecognizedIntent, context: AgentContext): AgentResult {
        val agent = agents.firstOrNull { it.canHandle(intent) }
            ?: return AgentResult.Escalate(
                reason = "no_agent_available",
                summary = "لم يتوفر وكيل مناسب لمعالجة هذا الطلب بعد (النية: ${intent.type})."
            )

        return when (val result = agent.handle(intent, context)) {
            is AgentResult.ToolInvocation -> authorizeAndRoute(result, context)
            else -> result
        }
    }

    private fun authorizeAndRoute(invocation: AgentResult.ToolInvocation, context: AgentContext): AgentResult {
        val tool = toolRegistry.get(invocation.toolName)
            ?: return AgentResult.Escalate(
                reason = "tool_not_found",
                summary = "الأداة المطلوبة (${invocation.toolName}) غير مسجّلة."
            )

        val decision = policyEngine.evaluate(tool, context)

        return when {
            !decision.isAuthorized -> AgentResult.Escalate(
                reason = decision.denialReason ?: "unauthorized",
                summary = "لا يمكن تنفيذ هذه العملية حالياً."
            )
            decision.requiresConfirmation -> AgentResult.RequiresConfirmation(
                message = decision.confirmationPrompt ?: "هل تريد المتابعة؟",
                pendingTool = invocation,
                requiresBiometric = decision.requiresBiometric
            )
            else -> invocation // caller (ViewModel) executes tool.execute(...) directly
        }
    }
}
