package com.zainiq.assistant.domain.agents

import javax.inject.Inject

/**
 * build spec §10 — Internet Diagnostic Agent. The first concrete [Agent] in
 * the app; everything above it (LocalLLMProvider's keyword table,
 * AgentOrchestrator, PolicyEngine, ToolRegistry) was built in Phase 1
 * specifically so wiring a real agent in required touching nothing but
 * this file, [com.zainiq.assistant.domain.tools.DiagnoseInternetTool], and
 * one `@Binds @IntoSet` pair in :data.
 */
class InternetAgent @Inject constructor() : Agent {

    override val id: String = "internet-agent"
    override val displayName: String = "وكيل الإنترنت"

    override fun canHandle(intent: RecognizedIntent): Boolean =
        intent.type == AgentIntentType.INTERNET_PROBLEM

    override suspend fun handle(intent: RecognizedIntent, context: AgentContext): AgentResult {
        val customerId = context.customerId
            ?: return AgentResult.Escalate("no_customer_context", "تعذّر تحديد هوية العميل.")

        return AgentResult.ToolInvocation(
            toolName = "diagnose_internet",
            input = mapOf("customerId" to customerId)
        )
    }
}
