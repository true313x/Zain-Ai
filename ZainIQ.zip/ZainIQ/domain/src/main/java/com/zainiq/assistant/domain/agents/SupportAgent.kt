package com.zainiq.assistant.domain.agents

import javax.inject.Inject

/**
 * build spec §33/§34/§55 Scenario 9 ("أريد موظف" → Human escalation). The
 * handoff context is only as rich as what [AgentContext] carries today —
 * a conversation-trail of diagnostics/actions already run isn't tracked
 * yet, so those lists go through empty rather than being invented. The
 * summary is the user's own words, verbatim.
 */
class SupportAgent @Inject constructor() : Agent {

    override val id: String = "support-agent"
    override val displayName: String = "وكيل الدعم"

    override fun canHandle(intent: RecognizedIntent): Boolean = intent.type == AgentIntentType.SUPPORT

    override suspend fun handle(intent: RecognizedIntent, context: AgentContext): AgentResult {
        val customerId = context.customerId
            ?: return AgentResult.Escalate("no_customer_context", "تعذّر تحديد هوية العميل.")

        return AgentResult.ToolInvocation(
            toolName = "escalate_to_human",
            input = mapOf("customerId" to customerId, "issueSummary" to intent.rawText)
        )
    }
}
