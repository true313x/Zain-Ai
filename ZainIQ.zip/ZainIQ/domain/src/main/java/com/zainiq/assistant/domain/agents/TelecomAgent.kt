package com.zainiq.assistant.domain.agents

import javax.inject.Inject

/** build spec §9.1 — Telecom Agent: account status, balance, usage, package. */
class TelecomAgent @Inject constructor() : Agent {

    override val id: String = "telecom-agent"
    override val displayName: String = "وكيل الاتصالات"

    override fun canHandle(intent: RecognizedIntent): Boolean = intent.type in HANDLED_INTENTS

    override suspend fun handle(intent: RecognizedIntent, context: AgentContext): AgentResult {
        val customerId = context.customerId
            ?: return AgentResult.Escalate("no_customer_context", "تعذّر تحديد هوية العميل.")

        val toolName = when (intent.type) {
            AgentIntentType.CHECK_BALANCE -> "get_balance"
            AgentIntentType.CHECK_USAGE -> "get_usage"
            AgentIntentType.CHECK_PACKAGE -> "get_package"
            else -> return AgentResult.Escalate("unsupported_intent", "هذا الطلب خارج نطاق وكيل الاتصالات.")
        }

        return AgentResult.ToolInvocation(toolName = toolName, input = mapOf("customerId" to customerId))
    }

    private companion object {
        val HANDLED_INTENTS = setOf(
            AgentIntentType.CHECK_BALANCE,
            AgentIntentType.CHECK_USAGE,
            AgentIntentType.CHECK_PACKAGE
        )
    }
}
