package com.zainiq.assistant.domain.repositories

import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.domain.entities.EscalationContext
import com.zainiq.assistant.domain.entities.Ticket
import com.zainiq.assistant.domain.entities.TicketPriority
import kotlinx.coroutines.flow.Flow

/** build spec §33-§36 — Support, Human Handoff, Tickets. */
interface SupportRepository {
    fun observeTickets(customerId: String): Flow<List<Ticket>>
    suspend fun getTicket(ticketId: String): AppResult<Ticket>
    suspend fun createTicket(
        customerId: String,
        category: String,
        summary: String,
        priority: TicketPriority = TicketPriority.NORMAL
    ): AppResult<Ticket>
    suspend fun escalateToHuman(context: EscalationContext): AppResult<Ticket>
}
