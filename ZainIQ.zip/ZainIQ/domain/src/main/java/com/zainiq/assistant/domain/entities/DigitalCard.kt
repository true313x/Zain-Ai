package com.zainiq.assistant.domain.entities

import com.zainiq.assistant.core.model.Money

/** build spec §15 — the "بطاقات الكترونية" (electronic cards) section of
 *  Zain Cash's Store: prepaid cards for internet/telecom/games/entertainment
 *  providers, paid for from the wallet. Digital codes only — this project
 *  has no physical-goods e-commerce (an earlier Orderii integration was
 *  dropped from scope). */
enum class CardCategory { ALL, INTERNET, TELECOM, GAMES, ENTERTAINMENT }

data class DigitalCard(
    val cardId: String,
    val providerName: String,
    val category: CardCategory,
    val price: Money,
    val isDemoData: Boolean = true
)
