package com.zainiq.assistant.domain.repositories

import com.zainiq.assistant.core.common.AppResult
import com.zainiq.assistant.domain.tools.RiskLevel

/** build spec §20-§26 — Cybersecurity Center. */
interface SecurityRepository {
    suspend fun scanUrl(url: String): AppResult<UrlScanResult>
    suspend fun analyzeSms(sender: String?, body: String): AppResult<SmsAnalysisResult>
    suspend fun scanDevice(): AppResult<DeviceSecurityReport>
    suspend fun analyzeAppRisk(packageName: String): AppResult<AppRiskResult>
}

data class UrlScanResult(val url: String, val riskLevel: RiskLevel, val reasons: List<String>)
data class SmsAnalysisResult(val riskLevel: RiskLevel, val reasons: List<String>, val recommendation: String)
data class DeviceSecurityReport(
    val score: Int, // 0-100, see build spec §21 — always derived from named factors
    val riskLevel: RiskLevel,
    val factors: List<SecurityScoreFactor>,
    val recommendations: List<String>,
    val lastScanEpochMillis: Long
)
data class SecurityScoreFactor(val label: String, val points: Int)
data class AppRiskResult(val packageName: String, val riskLevel: RiskLevel, val reasons: List<String>)
